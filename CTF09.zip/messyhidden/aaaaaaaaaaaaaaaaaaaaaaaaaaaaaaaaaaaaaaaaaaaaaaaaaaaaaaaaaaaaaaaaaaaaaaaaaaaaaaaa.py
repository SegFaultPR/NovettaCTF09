class ccccabbaefadfffedfdbdccefdaeadffbaedaaf:
	fcbcbbffecbcdbacafafadbadccdafeededdbbf={0: b'78fbf168145ec7b70a3e5e8908d6b55ed0b78e7',
	
	
	1: b'8cd326d77de60924d4d5bf9e64d73881354d6b8',
	
	2: b'c74af08be11555361461ef2efe5e394af45c652', 
	
	
	 3: b'89c02cc235f345f4f580978ff2e4fb8bbe94957',
	
	 4: b'447639aff63ec5c9c55a5286ae8ab2ec6b254cc',5: b'bd200f9069096b118a9cccd43736256c3fffa64',  
	
	  6: b'ac7f92382d665c3ea09bf74350659c9ba64c39c',
	 7: b'2be3f42dfdd0e51cef9e2750709bff8d01eb01d',  
	 
	8: b'7f18145cf54ebb988cd36949aa3b7b66eb36268',
	
	9: b'1fd4fd6b9861fd27a0de90a78914a28523ad5c0', 
	 
	 10: b'54d71b2615f60a405f289150438d134db391fbb',
	 
	
	
	
	
	
	11: b'70db3ca2e46be21ce38ed7192869b78c1e568df',
	     
	
	 12: b'f6beef95bb8bf97fac066d67b1cec7effbc671a',
	 13: b'9c15b57d931553d3b56bc524348c85eb26b2f63', 
	
	
	
	
	
	 14: b'faa4d6accc054ff9a4860f668a0c2a5271b938e',
	 
	
	 
	
	
	
	15: b'b4a0949c6102ce1bb00d7c01640dbce6f839d3a',
	
	
	
	16: b'c4775665fde5b3e6e855a9c52ee7559b88a21b2',  
	
	   
	  17: b'80271ec93d2a1113c44278736c7a38cacd390e8', 18: b'7c6cde41d34eb27c1640e9eea8d1cbf327bd5e9',
	
	19: b'fac3079f6e32d79e95b8b4413210c62d7a09580',
	 
	
	 
	20: b'a74044b6643fe0de1f39ebde5f52023bce530bf',21: b'518e54916035e186756fecad1e3d976e9bef41c', 22: b'8577302c1b8eac4beca26f3898b4ee38630ace9', 
	
	
	  23: b'd12efea859fa65872268b8bb4435a06e4046545',     24: b'ea0f6f35868c898586db073c8d2ba9160303454', 
	
	 
	 
	25: b'e0e517ff05b4c40301e1fb33396e21df4de475d', 
	26: b'caefa5dd0aee3c5084ad93546dcdbd4140bf5cd',
	 
	  
	 27: b'e59097c2ec4776bf9f9ac227fcad53b0d5ff9cd',
	
	   
	28: b'082a6a581063399e91843282feb3725076fdfef',
	 
	  
	29: b'e8e3a7051fff626d646ca816659f6ed58b90128', 
	
	
	 
	
	
	
	 30: b'2bfb9985ffc2a66023b3d81b3dbc9f7708087c2',
	   
	31: b'af2df0d71b61b399f84ebaa9b56cff001ebfa74', 
	  
	 
	  32: b'724cdc814746919f78bd403431f0d570a002796',
	 
	 33: b'c2266d118c94a64b1e7ecf9d917231da777dfd3',
	 
	 
	
	
	
	 34: b'2714cea6cb37fa09bdb6df8fb34ea1b2afee31b', 
	
	  
	 35: b'f63eb03019333aacfe64706c83015cf65c7300c',
	36: b'76aaa9ce8d02b9ea41f9084a7888ffe05a5898c', 
	 37: b'775566ab91f9b30e5eac2d1c2c7fb14707e5f07',
	 
	38: b'5cdbc7fa392fc923b6843bb87c796f67b435d96', 39: b'92cdf9d81e435c7d220a6663ac5652b24dc6a9b',
	
	 
	
	  
	40: b'741a2c0a93e31abc2fe61342e8ff4ce50f6d1bb',
	
	 
	41: b'995d492519c16678dc45496ea8d0eacfeffcb2e',
	
	
	
	 
	
	 42: b'f8efac484b3eb99dae6bd0b2322700611e36392',
	 
	   43: b'4b356aebe664e3f0841290b403a0aaa58822974',
	  
	
	44: b'215dae40ad28ecf8f066cfa4f72ee03848e57e8',
	
	  
	
	  45: b'ae11b57f25fb3f128307d78e696730f940ac542',  46: b'1f7690a799b72115a37426742a0f02f822d33f6',  
	 
	   
	 47: b'5f70983e6cf12a4de1b629a81aa32b055ec8c5b', 
	 48: b'3f1c53d747df92bd471a3aae26782fbc1d902df',49: b'd90dc19ba4bb8496165f8f9c6858528a1e4333e',  
	
	  
	50: b'18b7fd993d36f0ea0cc4f339eb863bf7578cb87',   
	 
	  51: b'56a91b6c38e80495ba952a6ab43bbcbe72c3296',
	       
	 52: b'b3fffae7e8335ab74dd3a082aa5528cdc681a13',   53: b'795ada754ac9c407a26c4ead804749068026a72',
	
	
	 
	
	 54: b'8c9ad1c3aaff82fcb31d380014dbe3daca94067',  
	
	
	
	
	
	 55: b'3e23fd4cec3d646e0f783e3a32deb56d79e9682',  
	
	
	 56: b'8cffc6dd53360c969df0a6b2290840a7670c932',
	   
	
	 57: b'46557d4642b5f3c4fc130ac31fbace4ba014c1b',
	
	 
	
	   
	58: b'd765239a3abfec6c7500b7be7c392273c1bfeca',  59: b'7557fea88b58525c6349ae9c69f1291f9d08dc7',
	
	
	
	
	
	  
	60: b'49bb7daf4acc7d3cc84185eaccef97830c3a02c',
	  
	61: b'8e2b7715f8b38ef8f0e7da3569b54824b1c295d',   
	
	 
	
	
	
	62: b'02d63df2c74e3b5372215d2c726e86774465cfe',
	   
	
	  63: b'08049b1be6eb710032a247cc06ba4fdfe0e721e', 
	
	
	 64: b'87bb189aadfb28bdcc77239855a5ca0588c8b08',
	65: b'b14452d9b375cb25c155ec16524855b0fd384ef',
	
	 66: b'bacecd0777eae3b128544bd23135a173220e4d0',  
	
	 
	67: b'2083a5098813318f57e228c21b6260a74ada40e', 
	  68: b'fc1e586fc1216c265f4ff720f07b0ade95ff4cb',  69: b'4d4024a45181624db8ab1328d148d7975ed9509',70: b'd4d486337d6b1a5a0eba58855d748b4b1d38229', 
	71: b'748ef1f61fb4224ba9c7d3135dfdea909d8d711',
	
	
	
	 
	
	
	
	72: b'6454ce01ecb66222ed0fea6c565a4e38df156c3',73: b'2342ffb8a49c1ebca80843e7e72e0956cf37e72',     
	
	 74: b'6894861e60aca215716d6e45f79d2cf8256299a',
	75: b'3143d48aa5a94c79095231305742593da89697d', 
	
	
	
	   76: b'09c7b3a344fa5e4deecfa45ff96ec49f80482bc',
	
	77: b'21bc0aae2c1fc5934fabe7af3603ee0ef42e963',
	 
	
	 78: b'df38aafa056e2d281b8ed701596c28169e0422d',
	
	
	
	79: b'2b36450064318592413ad54fd2e8136d6931442',
	 
	
	
	80: b'8b6c0cb46c1629d98c5e5a22e343e085d20e0a0',  
	
	 
	 
	81: b'd63f1538a215afe60358a586594f02592c1fcbf', 82: b'd6c8e4dfa760c157b0d32566a88c769f0d6d876',  83: b'536a606d9aff266e9fc60150041863fc707a308',    
	 
	 84: b'd64a073557b2bfadd820391f65c6e23883e9d06', 
	85: b'6baa5b37c80e68ef6b85af3d2258e67229c306e',
	
	
	
	 
	 
	
	
	86: b'4f11759241df8a79aec8bac2e936f80c477671e',
	 
	 87: b'cf0dcf9af0ba50836deb5d608af750195597b92',
	  
	88: b'0236a44e8bfc62944fd2d542e1f324719f65099',
	89: b'c2abf971ff122ce3eb82db8acf252c20626261a',
	90: b'8a84ad86558ddeb17a4d19c5110cc6e536c3104', 
	91: b'523a7eaad727130a84df1f118b83502a3eb2fea',  
	
	
	
	    92: b'def22f5ec2792b1f7550eefb0e5dda094f78cfb', 
	 
	  93: b'cd3c78bab8caa41a8994a45984066ff4b213044', 
	 
	 94: b'acb888ef2e5934fdb897eb47eaae4f90afd5bc4',
	
	
	95: b'46ec845d8566b5a362258fca0a214220e0cf851',     
	
	 
	 96: b'1f60506b2d10aa0ea4bee8170ceb8b4dfa0e4b9',
	
	  
	  97: b'f56261e524369d8ea598548cad8f6b6daf6760c', 
	 98: b'b03915cba256ba83d843c821eac6e5402fbced1',99: b'caa30d3764dd44125a795b737e7f5f3f6c1eae3',
	
	b'cfbddbbaabccacfacbcaebcdabeefebdbcdffea': 38}