class cdcfacabcdcbecacbaedeceaaaeeddbaacffbeb:
	afdbbcfeefaadaffeaacbaabffbffecaffabebc={0: b'27b0d3ef3bf91c81ceb219d3c6c659e87e6a740',
	 
	
	
	 
	
	1: b'e21dddaf31812b95a8501fb2e17e2af6e3372be',   
	  2: b'fc4695d6871e0b8d19e36882bfb057c5da0c03e',
	
	 3: b'cb6e287e102bb8b5e17641413fc4f54b6ff5509',
	 4: b'fb6642eae2450a0c46ea9041d9081d902635792', 
	
	
	
	
	 5: b'8ed4f21f57d1b0bd2c0c3ba468dbaab150ed407',
	
	
	
	 
	 
	6: b'13eb7138f8c275dab75730c719d1a103b3d4817', 
	 
	   
	 
	7: b'3e46b51c9f77c3ffcd8fbb160fdbc32fda86175', 8: b'c9808e7780768d379066b0b11c2b5318a8a7341',
	
	
	
	  
	
	  9: b'2e4e487c446fa1117c2616f56f105879191ea9a',10: b'f4bc4aeecdaaf34af734a200a94bcdfca272f3d',
	
	
	    
	11: b'565690763547b939a7b2350cdc643a29141ca36',
	12: b'47d8c1cfcd1db2db3bb599a8a416538fd3de2f1',  
	 
	 
	 
	13: b'3126ca63fae6921adc2aa721cd8ba01081311b1', 
	
	 
	 14: b'95c7bd93287810d18fc60157efc0b367dbeeee6',
	
	 15: b'0738a68937bb0dbde42f66fd9a3e0a1a6ea91e2',16: b'7cc8d22e2a70fa4051693a4acfcaaa3601d3e35',  
	
	
	
	  17: b'a498f2979ab378ca67cd2fc8b65f8d5fb3a5119',
	
	 
	 
	 18: b'4350e2225432fd29d5195964fbb968545fd0699',  
	
	 
	 
	19: b'2ed43793ce64108bfce046be31f8fd49886ef76',  20: b'a82f5ecd94fea989a1a45b5445ca2c1a1f433fd',   
	 21: b'22e101056defbe04dff7066090533b119d2aabf',  
	
	 
	
	 
	22: b'f9b86881c582b0023faa963932db002078442de',
	
	
	 
	 23: b'b669d210b49c30056e4e1caf6efb7127f20f18f',
	24: b'fd5b28f03e8d8a2841ae5aca3cc3279ffb0a2be',  
	  
	
	 
	25: b'5a786bacea001be3fc1e953d6349fcefd353fe8', 
	
	  
	 26: b'a03eca8ef79b3df077f40889d8fa6aff698dcac',
	
	27: b'ee13393af222fbfa785eb5dd2223db8a2cc70d5', 
	
	   
	
	28: b'69fc2b184494852a8db519e535600490ceda617', 
	
	
	
	
	
	 
	 29: b'8b4ce90e032d3585e4a399bf71bc921fd69ee07',
	
	 
	
	  
	 30: b'98e6d6365e24d536a3d67cf60298761f51d6d0c',  31: b'33bf6234db8273f0ae400aea1f57790f570fdc4',32: b'85b767da712893600b6ff926b504f5c11ea9e2f', 
	33: b'7b3f15ebc9125852415d1cc3903fffc414e8f39', 
	
	
	 
	
	
	34: b'acf9347c6b8ff14742117967363943c131c3e2b',
	
	 
	  
	 35: b'b3edd7a95170bbdca6724e99b565496d63df625',
	 
	
	
	 
	  36: b'd57b00b9ffc1c32634b68f2d9767a433f5c392e',
	 
	
	37: b'81224aadc8797f304cfffe647e6670aee0fe124', 38: b'eeadd0c728220f223c32d95a7f81151f58ea26a',
	
	39: b'5ecab9a102d070cb02e08c3afa0a256b58d2a3e',  
	
	 40: b'7e424ffb0ac1b68e753f4b036688e79a8b3857b',  
	41: b'37b1f880927f4c7560d520c50a1599f79a5e647',  
	       42: b'123f27d2aefc6618e465fb80d686a409896875d', 
	 
	43: b'789faf15792ac9d1931a370239bd0b13b80b4ff',
	
	
	
	
	44: b'484dfd3c99b52252d57d3df084a06771f68e4f5', 45: b'1f6e7365d4871a1b9b8db802000f7eac59f59a2',46: b'db81688c7433181279e679172e4face084f0585',
	 
	   
	 
	47: b'462a8a93f8b0b159d7b7dceb5e70f83537d83a2', 
	
	
	48: b'64c99d4abd8bbee724b73a83f443f45da5fdd22',
	
	 
	
	 
	49: b'd4fb9d7bed4556d4a41c1645ba31c1d32a2b392',
	
	
	 50: b'4675d13be8b00291b18ba6c6fdfdf004ff18166',
	 
	
	
	
	 51: b'f27fe2ca709fcd4c7577e4530d38908c95d2f4b', 52: b'3fd4ff86be25a34437bc233a479406410afda2f',
	
	53: b'7b25b3d83d3d7687048dc80890e8262bf6fa1eb',    
	 
	
	 
	54: b'c7326e32fa7217494246e38843545bd69f9f091',  55: b'3d79bc12aa4af7ae26b22f127f77ca186976127', 
	  
	
	56: b'56ae4d73d33db41e58a6a694675f4d5adddc467',  
	
	 
	
	
	57: b'db859c650a530c10e919149e153eea79cc1eca8',
	    58: b'1eb02e5f2c7664ca5bbcf3a925ce5d1948368ff',
	
	  
	
	59: b'361d1320b5d780ba6d0787fb40b605b5a8177cf',60: b'd8769b3af83433f3558167c6fbd1aff4cd5fbcb',61: b'3a91868a66118f2501e5279c72672411ca7ae4b',
	
	 
	
	
	 
	62: b'd5849c9464a8c84eb85d6a5059199b6e9abb50e', 
	63: b'07e73939698e29725b5ccecfc51b1ef48f9915e',
	 
	64: b'f3158c7ed2fffedf3e1b19be8bb0db49cdffd7e',  
	  
	65: b'e2295adbdeabbb36e4d0c38d35c9ae2ce6cfb5a',
	 
	   66: b'f26d78d97086b8e5e7490a88df9f7b35d198156',
	 
	 
	67: b'63d79e1504cbfeb60922e8d785cdc1186b8e864', 68: b'5b3522dcda905b9dc4b4cb7e83556e018cce62d', 
	
	  69: b'fd147926228f2f5207272197372d5073235ec20', 
	
	
	   70: b'3d3cfd7a698584a0f509a6a5ae3c128e8b2696a', 71: b'53d6fee3b112e77d0d80547a61ee6d1bb6c8cfa', 72: b'6f21841ec71d259a86e696810de52e02189ab9c',    
	
	  73: b'38baada4bbe05b7172eded04e95408ab7cb929d',
	
	 
	74: b'83c9ce140e2f3c075c1f2bc88fc28ec737e7b46',
	
	
	 
	  75: b'38ef43fd3e4eeda28dc3f4ae33d5d181ff6754c',
	 76: b'ef28ec2575d2fc7cd84ae66440cafae01140f93',
	77: b'efebaa75025c02d003bca1bee2675578927012e', 78: b'd1dd6b0873b98fb19b4a7eefe3f69102c64c34b',
	 
	79: b'fdb02965f44179ee33dae805f2e851d3dc295d2',
	80: b'ce5b8ccdddfc8f7195bb25ead97beea9252c6d4', 
	   
	81: b'4ff5262cf22e4fa07a847ddf6e80f854bb6a77a', 
	
	82: b'2cd2286cadf16fe20e7921b67899ca01d73ceeb',
	
	
	 
	83: b'c718366993a9ae020eb0070a4068abf47c98ce6',
	    84: b'118a63af3859d53b0cf16fb08362b517684a2c7', 
	 85: b'7a9c95dee4c10181b7a5f0c4ba4c201eeeccbc2',
	
	
	 
	86: b'b4d07f866bd94442a9006522d4bd3ceb56f09b9',
	    
	  
	
	87: b'f004630fbb4894078e63c44c89052cba5d58c53',   
	
	
	
	88: b'699a76aec1f2bcead4df1372a737f2cac3438f7', 
	
	  
	89: b'efccf3e9cb1204b68e7ebeb41c7c2f17d57564c',90: b'375a2a5c4314703d886303fdf75483c63a1d87e',
	   
	
	
	91: b'15ac75c0d593ae01774910d22120ebf3e9d535b',    
	 
	92: b'b1758709d659f8d56d29107e62c0f185bd41e4e',93: b'e217139b4e6859e2e7bae2293bff59ef11a5217', 
	 94: b'f1e3849aa460b7f6514aec91573e09a831107b9',
	
	
	95: b'6f947469f8abd08dff293cc92d2d84b4c510772',
	 
	 96: b'8938fd7a8bc76e7a015e929ffa8539d317d20cb', 
	
	97: b'0d2113c8f9859bf5d99541a49a6c1238f3d705c',
	
	
	 
	98: b'63c00bde2c4c13c931a70fbb6d562d66c7dc6f7',
	 
	 
	99: b'912afc76e498a9d80c04aa6b163be2762eecab3',
	
	   
	  
	 b'cadaffbfceadeabcaeefccbbebacbfafaacbbfc': 21}