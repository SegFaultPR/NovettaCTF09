class cbbbcdadcdadddbfddebcedcdecdbebbcbbcdfe:
	cbafcfeddcbadecadfadeebebdacbdcafdefcbb={0: b'1e6ccd16a22629951f479bf2b9eb5b18212de13',
	 1: b'e955332f8ed3bd4c2726d1a8f1927ac47f18f69',
	
	
	
	2: b'50960b4f55a0e63f8d66df84fc9bfb8e16396b2',    3: b'18ad5422fd44d155e5f4cdaa7c4e8f5d6a60759', 
	
	 4: b'0c173dca9b0a38d8f68af3279b61a1f00f0e278', 
	
	
	 
	
	 
	 5: b'25c809be82bdfa57afbceb71ded7f49e73604cf',
	   6: b'6e4998338962a2b28be4f23bf35cd581efa40dd',        
	
	7: b'1e60daf9605a1ae8282c80aa49cd310a285a569',
	  
	8: b'8de88a522b22e16ea5469450633f9f5ef541f03',
	
	 
	
	
	  9: b'2011b06d94f65277fb422742de129be54e9ec83',10: b'e2281f193b746cd4b1e35a86ff05bfc81985959', 
	11: b'2470892227a624cf2efc2c4a528296080e66e94',12: b'ee1e8c33528c9141874bffac1c63fc9fc327e9e',
	 
	
	 
	
	 
	 13: b'adadf1130e6e65c2fd6a98b2bf69166c37e4f68',  14: b'9793e38f9f086beba63439c2da83d6e70af9a75', 
	  
	 
	 
	15: b'acc31159e0f3d88fc2a357d0f79705ce841a744',
	 16: b'c24c6ca2577d94e1b6d35b2bf0e732b2dae6c10',
	  
	
	
	 
	
	 17: b'8bcb7251878ec4b733484190a0b4590aaf5b79c',
	   
	 18: b'f277e4f9dab131e2ec040913c74985f07eafc65',  
	 
	19: b'67e0d047201005eccd39ed8d574d489adcf87cf',20: b'701aa6c65a03bed4ba9d7466b44f449d567ef52', 
	
	21: b'c9ee032929214b32e374b1eeb5daa95eb04bf96',22: b'ddfa5237695db7a4d8a85148435f517d660be8d',23: b'0aec8468d87852a25ef3b48a3ab4ec4560beb6f', 
	
	 
	 
	 
	24: b'3bb308127aecbe46f05603bf0164848404f5777', 
	25: b'5ef609002d6fc540bfd8f3a9adeca5e74fe102a', 26: b'86347df33da6de39e15626106623a7c81ad664c', 
	27: b'9ff4daef90316e6d5055e50a02b77f3486b221d',
	
	
	28: b'8da21b4d8bbaddd1dfe663c81caf2f25992dc26',
	
	29: b'f90e9c04e98d15820ee05a1505500d533af022b',  
	
	30: b'6495b196015c374cb2ed766c7c327e79fc770e9',
	
	 
	
	 
	
	
	 31: b'bfe12cad991b428ddb5884dffc4a7aa93b9cdd3', 
	 
	
	
	
	 
	32: b'5dd87fdd00bd325ac17059fe7443d3f611b4512',
	
	  
	 
	
	
	33: b'c83d29bbd3b2507606559e88c65963cb766100b',
	  
	34: b'18cb06f88cf4c0b1ebc637de2fe69b06ecd302f',35: b'6dc171220e27b1a38cec7fb5c4b7051a0ad7fcf',
	
	  
	
	 
	  36: b'b9e784434de3964ef1b6831fbbff032c31baa9c', 
	
	 
	 37: b'51777bb1da4580a04f916153ed0fd6fe3c21eb9',
	
	38: b'223ef632d89f087a64c8220dee398f1cf6840a8',  
	39: b'92d0f6ac9037ffa2d529577dd4b2af5fa0f3df2',
	40: b'1e7889b7ef2d01e669679aeef2f256e976e6983',
	   
	41: b'e218b73e423eccb445fd080f9d10431485e83dc',   
	 
	 
	42: b'21730c956acc043618590861197bd43ae7a1840', 43: b'7146bff5dfcca72374160851bcf724ae6491390',   44: b'c18e6494b3f52f874454d8fae6127260e86c5fc', 45: b'eb164a55d2c3290797bad971548762b99a06424',  
	
	
	46: b'01c0b387f940b9cb95eeefdd8c50c7f8f04b98a',    
	
	   
	47: b'5b1e07c70697c531c60365186ed3fb71b7fe81e',
	
	
	  48: b'1cc773640e21ecfc3a2a77b51364e0ce6151a03', 
	 
	49: b'ec0dfb3c07a688e098a17fc3d1980fbcbb353fc', 
	
	
	 
	
	 50: b'f8aa86125775497c68a2bda68da1f7c51ce71cc',
	
	
	 
	 
	
	51: b'eb51f86fac7b2022feedfcc640ab0609bb853bf',
	
	
	52: b'359fdbc165e5d6bc874e717f8a4a6e71e9a069f',
	  
	 
	
	  53: b'c720db69e3de77dbc80d39a9ce6be02df7c3dde',
	  
	  54: b'cc6237d53a71ed8cc3b06a31a789faaf713d82d',
	
	
	
	
	  
	
	 55: b'14021e75c496884129ba29746291f11ac1c1ce1',  
	 
	
	 56: b'2b09f7dcaa51cdfe9a3583df723a63258895787', 
	     57: b'3e219200b77ddd6de97039774173b5a5757844c',  
	 
	
	 
	  58: b'9231a72bcd79464b2d21cb3861aad5cc8decda0',  
	
	
	 59: b'f8ac55b053a45e01be25d8a7d1489383ff718fb',  60: b'fddee7ab94089ba753c0e91c68ae8fb8599f261',
	   
	 
	61: b'592f294eb41a5bddd68f7e28f737561d6988579',62: b'47d2481f36869011ed4acd919a1da67c4f2b372', 
	63: b'031812efdb7c92674325bc8363a4adda91c1e65',
	
	 
	64: b'acc73bdc5691832232e21c24ce265305e0f7d02',
	 
	  
	
	 
	65: b'8aac3bffb2b9524f14555e9ee9787675255ffb5',   
	 66: b'2728cecd615d1d1054f693cd0f87a52fa9dfdf9',
	 
	 67: b'ad83f1345e3fe48eb9ab9d1fcc3561fb1013e40', 
	
	
	 68: b'3d1052dec7514d83ced6e33debc4bd53e1da051',
	
	
	  
	 
	
	
	69: b'732c7bff15419379e8abb95f658bea6fb61391d',
	70: b'7117929c7f02da106b492484b9ae5f3046dc09d',
	
	    71: b'e6d64415034f0c52ebfa268d3afe0383383b938',72: b'ac2f5c83971ee6fd5c5c250219ca8337b8c4436',
	  73: b'57b8f3970db4f97b54e37417a246fccb282efb2', 
	
	
	
	
	 74: b'f09daf314fbd7581a9b20321f08c5678396e173', 
	 
	75: b'bdf69fdcd645d809c48223ddeb4599736513a7d',
	
	 
	 
	
	
	
	76: b'140d0f05bd32fef0179f19bf89aae6b8cd5be01',  
	  
	 
	
	77: b'ff9e8a7b92338f06381d896e2fcbc1eff0b345f',
	 
	  
	
	78: b'dea42b8e32d5702c7e97fb211be21de30111a26',
	
	
	    
	79: b'0688bbb24865df7c24320287a98046b08b5ecf7',
	 
	
	80: b'67375b0664b2a14baec899614979b9a75b06eca',
	81: b'3ec396e54ebf5a4ce0f9b641c88eaa0c670299d',  82: b'2ad3f44498376f588b5a9833ed35faf8a25afa1',
	 83: b'858ddfac46b4635669fd691a9dc6b55617d528c',
	
	
	84: b'801698387ce02931714daf09db3ec63f70ae3ec', 
	
	
	
	 
	  85: b'ddfa8c8998e58584b7759ba95826b4686a56e41', 
	 
	 
	
	
	
	86: b'9cf1364d4eacbc9bd1ee1729f0e7faebeeac3b7',    
	
	 
	  87: b'7068b0808f4b30cafe8f3f90d25e3ee0c401f0a',
	  
	
	
	88: b'a67590cd8c0766331ba2d81b5e53397c7b8cf53',
	 89: b'9f4436489df4cffcfb439d25ca736aa74cc54aa',
	
	 90: b'6f1c6f6521ce9a3d23d1ea6d9a2dd8c3d790373',
	
	    
	91: b'f80438a2e4836478bed180abfff4d34f686e8d1',     
	
	  
	92: b'32d3e1046c262771ee101dc6018a1b555b48a02',  
	
	
	  93: b'cd8fd5263f0034107ba019ec96387dce9132092', 
	   
	94: b'f088780ceb2be3e2899a1896f2b197495b2b407',
	
	   95: b'79bcdc3dacf5fa1503cac1ca569b028b82077c9',
	  
	  96: b'f9c4e4e4f8c83b7db42660bd1503e9ef87e471e',  97: b'a166f0819e16b2bc75e22e6eb06132ede507589',
	  
	98: b'32b9ca0493aa0b182b521975f05a3ad53351b1d', 
	 
	
	
	99: b'91e48a91b8d396c7e823ac6afc7fe6ce7332b69',  
	
	 
	  
	 b'afaceadcbebeadefcedefcfaafacccccdfffafc': 66}