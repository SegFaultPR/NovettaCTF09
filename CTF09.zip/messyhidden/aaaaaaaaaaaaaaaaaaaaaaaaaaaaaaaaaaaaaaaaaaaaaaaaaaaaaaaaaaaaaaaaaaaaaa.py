class eeadcdbecbdfdeeebeddedeffcebeedbdabacba:
	adddafbbffdcacbecdcfceafdbbaddaaededfbb={0: b'ed4d80ec9766c4785294f11be08f558b2fa078e',
	
	
	
	
	  
	1: b'ee582eeacb89876516e0f27457777d3c9968d90',
	
	 
	   
	
	2: b'bf5d123520896ba048c14556dd3ed8dae98b906',
	 
	
	3: b'13211e83520258c7c6fc861207de56272d2e0f3', 
	  
	
	
	   4: b'5c9d2c9d52e3237b63f7ddcf7f7002319832f6a',
	5: b'f55a5712f631a6dac6b8335f171f0cc0a6bd812',
	
	6: b'4b897533342ed27fc9f695d939adb2b8d08fe2c',
	
	
	  
	
	
	 
	7: b'cb823e4010e0e8d0545c45ee6e589aa4e9c083f',
	 
	8: b'6316d741248b26cbc59c416b02d94f73102139e',
	
	  9: b'fa889188968d1c4204789d4374c9bc668c11292', 
	
	
	
	  10: b'a2e5d49647f64ec2080a8685dda265e776d1eda',
	  
	
	 
	
	11: b'9c141af0de059cd7585b90b9d4128910764eddd', 
	  
	 
	
	
	12: b'a05b7b70b33ffab23ba9ce622987d2a82b34437',13: b'12f18a9576eb6cc4c8c3885e0993ad475874b37',  14: b'91ed7a309493bd124c55a803a06d92421e7e966',
	
	
	
	 
	 15: b'55439e0879fd71faf5ef286275243ebfba51972',16: b'1c78727c46527d17451dad6be030d4e45a8aef2',
	
	 
	  17: b'd97de498b86429cdd5171edc41df0b9937084fc',
	
	     
	
	 18: b'4b58f3b94fe4b3dc2ac68626e9ad63f8b702c98',  19: b'48bc7aa2bc80474fb132073b29f236292c1c8d5', 20: b'ad9a28bd8a343fedc1c0ea6e80a00e53f5cb73a',21: b'6b2446b6c6e69cf5e1bdf2562a84e89e78ae24a',
	
	 
	 
	   
	22: b'706aceff0c42d8a63e083ecdba78c79800e46c8',  23: b'47f7e7e30744a08327eb66d6c65635d08af5201',
	 
	 
	  24: b'b4e8263849425a0f25380d10ac523a891898ea1',      
	 
	25: b'ad66d048be7ea2903e2451b73925d8e09f80e97',
	 
	 
	26: b'c758451abcd27510930e0ce635855aa75d170d2',
	  27: b'86657bae64a1b03e1938ffb83d03e1f8a1f41ad',
	 
	28: b'9413e7fb0e0c1bda81984336069e89f12c762d9', 
	
	  
	
	29: b'1f7eeebec07d583df12842f109ff3e05ca024bb',
	
	 
	
	
	
	
	
	30: b'3a9ee008d88d9a8bb0529c0506f0563dd70149c',31: b'd9e31bb90ef43469c6a9823088f8b49ea91c5c8',   
	
	32: b'3601138b221f660cd68c05a1e79de3c6401fac4',
	   
	 33: b'3e30a4f01b92ec2cf202f2797518fd6b832820b',
	34: b'1bffb5bbdcf99fcf34f6407b2f4bd77e99ae00a',  
	
	 35: b'e2550444ced18e6adbeb06147bd9ef988c832a0',  
	 
	
	 36: b'afc758c00fd2e210a8fae37abedea5d1f6a1d88',    37: b'60d75baff038dde9511966829d297be065d7e3f',
	
	
	 
	
	
	38: b'f46b3fd3cd04b85c7c9658d44f5929dfac00112',
	  
	
	
	
	39: b'f690965fab8b44fbd47b0df0660f19101b088c4',
	  
	40: b'8928bc09cda2c2c2fb719e4b23e6ca4811e7885', 
	 
	
	  
	 41: b'ef851195270cb3722200f64b170208a6484636a',  
	    
	42: b'1c756720a309d8dbdf32c56deed8592231146d9',
	
	
	 
	43: b'7903b9b68650f159765367e59d1d8b5db215058',
	 
	
	 
	
	
	  44: b'14cfcd6e739728e9a89948d260e22cbc9a0430c',
	 45: b'becb6c3aa269a07981411657e07a4bf01e626e1', 
	  46: b'0aa70989c317f84d18743ed86d00bc478ea8830',
	  
	
	   
	47: b'6437b24ed59756d395f087d1fd0720ea69ae29d',
	48: b'9d6f6574dfbf28f1aadef0a4ffe25839c90e887', 
	 
	
	
	
	   49: b'63d3fc5cf1d499c0032215711aa7dce779c96d7', 
	50: b'ef25d8a0e5b0ea2bcb936d91841c8c35bf1efbb',
	 51: b'ec03a44dea67d92df42d9b24247199cbf114301', 
	
	 
	
	 
	 52: b'5a8856fa37210adfbe82991f6414e287a827907',
	 
	 
	
	53: b'13e53a59fa39b9f1bed2d306ae7d9f55f414631', 54: b'171988e83720c6d9b38bb0bce5b6c59cb5f5661',  
	
	 
	
	55: b'64730c44a0c49a8f35e706d749f349e63693fe8',   
	
	
	    56: b'd5158d0333415d978a4afea8684e6ac88966416',  57: b'8a0569974f966929bfdb6547e33044700a98073', 
	
	
	 
	 58: b'541d1198d8d8c6ff76527dc0ffe04e2e13960eb',59: b'2a73d166dc0857ae7ba0883408b480eebd527c0',     
	 60: b'7a1bddd84754afc5f0b9ce66333bf6bda1df8ac',   
	
	
	
	
	
	61: b'8c05ec63fdeff9206f827514c25788ac2a6d48f', 
	 
	
	62: b'14109aea36584f516761618d1b4e66f4cfe8796', 
	
	63: b'918644b312d516a41e9d76481bc9274fcdbf56d',
	
	
	
	
	
	  64: b'ef5cc7d92e67f1a0170e53f5af67d370f41aee5',65: b'331f2c6d874e10618b85a3337a4f01a7c37f99b',  
	 
	
	66: b'0a55bef65c4392a2d53159162989cc2ac931d97',
	    
	
	
	
	 67: b'7c83531f4f6d1aa9e232d75c42a72ea7a83d95c', 
	     
	
	
	68: b'ead553698a59334d480cf35aeb72b632cf2aae5',   
	
	  69: b'b613a2f223b6d5e7326c7c7c47dd930e808baad',  70: b'5fe64b8ae05cd0830d1efbbab9bcf1ab42ae569', 
	
	
	 
	
	
	71: b'6ef783bb86649eb4055c6beaff886ba724bf891', 
	 
	
	
	 
	72: b'7a586540fe8b785c35f033d08d9713fdeacf67b',
	  
	73: b'7edc3ba94cf04556c30f83b854f789d015e76af',
	    74: b'dc82969073ab8abf39fb2295f73bff2566261c9', 
	 
	 75: b'5960b5ed92d5adbba31018a2c59c34c859530b8', 76: b'7998b2bb353e3ad8789b689278359db2e549195',  
	  
	
	
	 77: b'3d072f0ce6a79a1373eac27be4dbf9cf87463c7',   
	 
	
	
	
	78: b'77ac65515f114a9562420693abe2a6f870eabbd', 
	79: b'22d4c2a701b260a2ca39307dda671a4a6b78fd0', 80: b'4e0f88ec1e6ec40145e8ebeb13a3c7231ec2809',    
	 
	 81: b'd2fe60c1bcb4a513808cdead409bd6e05199926',
	
	   
	82: b'294400cfb52d181f61f0ebfd780c8d0fef98cae', 
	 
	
	 83: b'62a9cdd552501c6b9538e36d621af6c45cfb2f2',
	   84: b'e477d602c2afc904c2f6bcc1b55d83dc77e1500',    
	  
	85: b'8c0cdbf8344a06e11cc82d5fac6d536505fada3',
	
	  
	 
	86: b'7e61e8faebb8ef51e9db8559936fa590990ee97',
	
	  
	   
	
	87: b'1621961c1efc1c90c9df217ad97dfb273f219ce',
	 
	88: b'3957d6bdbc19ec7aac8792a0fd78d794d7f4b62',
	  89: b'e17cd81f88d1785b8307b11793aa5200655c05c',  
	 
	 
	
	 
	90: b'c9dfe5cf8703cddd514e7dee5ecefe6a2767126', 
	 
	 91: b'b5729856e41db0532dbed7b80386d2ea13a5c24',
	
	
	
	
	   
	 92: b'5f65718fc581466132888cb0613401f38a9d62e',
	
	  93: b'd3791ae70eef0c2554f93adafec813a5fc339b7', 
	
	
	  
	
	
	
	94: b'ee0269bf8216d3f1a60a516802cf16d23d4621c',   
	
	 
	 95: b'334c695baaeff30ce3a8f0a9d1c63baca3f4407', 96: b'89935c25f8c0d8b7ef413e68aa7d5b6c661178d',
	  
	
	
	97: b'da05a2249af1a465dd04f4f1ca4c160557500f2',  
	    
	
	98: b'26eb8e98bf163aa0762e7519664bf6d8d6fac11',  
	99: b'1bf0623597cd8bb2d7dead0a07514b384f25071',
	  
	 
	b'feeacfebdfecfccaaeaccbceabaebfbbfceccfa': 90}