class ecabcfccadebfddcdbdfbadeefefdcaaeafecdb:
	dbcaddeccfeabacbeadbfcaccecabcccebeceff={0: b'fb2f362f01a1da30170ca8c8cdc8043d60fab62',1: b'f5a5b4299297fb83e68d24c5945433c44745a27',
	 
	  
	 
	
	2: b'70e23e6609a81bf6e040c72d4428d8fd46a9a4e',
	
	
	
	  
	3: b'eeceb5fa729653469f0036cb74326a47eaa520a',   
	
	   
	 4: b'eb5c2c5be002906327be4911721ebb54112875a', 5: b'd582584208725a263a55c000d4f4ffaf0462145',
	 6: b'deabbc03a7877f581ddc8880b20cddb0fe2f4fd',
	 
	     
	7: b'6cd15e07f7c7f37757886a7bc756ea06c9bd82d',8: b'8b24f85a0d6be5dfde6c4f0fd90ff4144bde7e2', 
	
	
	
	
	 9: b'66aebcf30576557cf3d1221d219dc9525f382ae',10: b'304c3b36dfadec1f9a22d4469c9e325d9e2a61b', 
	 
	 
	 
	 11: b'db8e47d15fb3b72d405b0ae823c164373ea19e0',
	  
	12: b'62d0a3e2e5d3e9c6d1fa88df939309204ded397',       
	  13: b'e9f1f54c99330a7c3e062441fc3f998c18e54cc',     14: b'a8b928875825174a1e9d77115555ca8b652efb3', 
	
	
	 
	15: b'e3c462a53f00f32cdfe6819004427a9dfdc246b', 
	 16: b'0e695e8affff96826d11a137a6af0b44e4b45cb',  
	 
	17: b'c54bf84d31029f451281c9178202d5a296345ad',18: b'dd1b7b951bbbc05e4491ccff0c480b60e992100',
	
	  
	 19: b'0f688943543357c6ddf8d125bbb67780b0b005d',  
	20: b'3f3b27900abfd0a10265f27de54b68d65493bc4',
	 
	
	
	
	   
	21: b'0464d20a8818b4ee771a97245b6fe150939d142',
	 
	
	
	22: b'0248cc81dbd386f7843508eecdb562e3f79a9eb',
	 
	 
	 
	  
	23: b'7204688eacf6ea4d24e8ce7d9db702d1fd9419e', 
	
	 
	
	
	
	 
	24: b'203be25facbe319a9671386ef86d67018a4f2a8', 
	
	  
	  25: b'0ddd50e253da46a5489165a8045d1b86e4f50f3',
	
	 
	
	
	26: b'f86b64b5916bbdba46f60b2a1e5d032f06507c5',
	  
	 
	 
	 27: b'9af44e451bac99b2c037acfcf6f6fb60c74a15c',
	 
	28: b'911f1ecf61ac558f353dc51d1d0b03c5102871e',
	  
	
	 29: b'13db116f32965857cd4a92af37002cadb86b05a',
	30: b'b1643301fc6174a631e4eab2de03479a020e355',
	  
	 
	   
	31: b'e1a4103ffdcef4f6fb41fd55dfb6e709a7c7a7e',
	
	 
	
	
	 32: b'3430485ae9992e6d4b98af006971b0d720f8942',  
	
	 
	
	  
	33: b'4b00f14c9bd4180f7a699d78bedfc0f123829ab', 
	
	
	
	
	  34: b'320c833c22f042c26aaada703b0adfdf9f1165d',  
	 35: b'340cef16255c55cdc9f9ba3e6c3e163915ebbb4', 
	
	
	
	36: b'b0e5308647f4c2a2859a9a19519fa014a595062',
	 37: b'd801a00ce5697e47616e86cde4bb66880e44fa6',    
	 38: b'c8e249cef3688fb9fd30c932d4819f36fc6b2d5', 
	
	 39: b'dc366b58337fc5959b2298a39bbb7b714fb998f',
	
	 
	
	  40: b'f8aedab582eba57f0f59082073187c26faee067', 41: b'b20d0f55c930052499434b4ac4d9f6b39ece70d', 
	
	42: b'be56dcec65d8cdb62381177928ef4ccd83a9a5a',
	 43: b'43e27581335f3932d22c3df4714cc85e2612f0f',
	  
	
	
	44: b'4fdf51ed26c3faa7e37d2b953f5667d4b4b2dc7',
	
	
	 
	
	 
	45: b'012ce5012a71bbd670796c2f4f13ed80b7b4bee',   
	
	
	 46: b'271d3539f38204237b85c4ecf325bf251978169', 
	 
	47: b'ec396f320dcf0c87ae2024022cc98d1f883d565',
	48: b'75654e1c031274e670e274970d9b98599368d94',
	49: b'1508ca6b19751ca39d3d17575d553d5f7b1f832',
	
	 50: b'c68524def2566a7f43031b4b0d5095f5913803f',
	  
	
	    51: b'e057d36a0ac3e6251e41c6e06e5ab38df89a3c9',   
	 52: b'd8a55891fdea5c58a8ee44d5ff42ae8de4ed0bc',
	
	
	   53: b'df828bf7fb88b5548b9806adde42c960dc63604',
	
	
	
	
	
	54: b'957ecaf9a70ebf6c05d928cb8b6db7e5a49cdb2',  
	55: b'80ca808e5cb8c71c7b1afebdf2480dd626414dc',  
	
	
	 
	
	56: b'1fa61136b795a282d23d387b8eb4fe172cc472a', 
	
	 
	
	   
	57: b'd53cf08acde399afadbf454245249f4510d0d20',58: b'44d07ee424d8b22f25598214da3646685234f80',   
	
	 
	
	59: b'3a060565ed3bd70d5c40761a164069362f021cd',
	
	60: b'24afc5e437f76d35efae64ec32772de768dbc98',
	 
	  61: b'2ed818c7de58f1ba51812269e54ff051a97f050',
	
	 
	 62: b'b08b8476eeab05881b62a69e3d1c3ca42cfd7bf', 
	  
	
	
	 
	
	63: b'8b44596929884569771c13ed0927827bbb831e2', 
	 
	64: b'eca0d0b25e9c03466763c8f139bf3f5f3ff9b77', 
	
	
	
	
	  65: b'7954eeb89df7c7e442fd5a592af739250f8547f',
	66: b'6fb52569eace36fa095d0e1f69ef0a4b38b513a',     
	
	
	
	67: b'bafbc6a61dc4525c0b68230a94882a5757e989a',  
	 
	 68: b'31afae17622cf857c5240f2ebe519f679c88cf2',
	    
	
	 
	69: b'5ce00f46cd7e35d37140ec9df9bcf3328563d6e',
	  70: b'8fca704f81c143acbea02406c9b1c40ed6b2e04',    
	71: b'124572526699ed26e49885407b8edd4720674df',   72: b'30751ad66db8ad4d24a33855eb095e40c2e0781',
	
	
	      73: b'd72a5038c5541d783a511d7715d30c6dbf76679',
	  
	
	 
	
	
	74: b'c9cce6177ef6e7f18ab79e2cb90b69a0c9b7a9b',
	
	
	  
	
	
	
	 75: b'0f861839cae30c03d37ac3db9cd02eb4cd1d0d2',  
	
	 
	
	
	 76: b'e70f3cf98a9ad5b31766d847b48b36e1a131f65', 
	
	 
	  
	77: b'94565ef9db7caf1a81543aed4d24a3367d7f0f2',78: b'9c5010fccc7652211ff805f43bc69bd10f4a159',  
	 
	 79: b'894b37c1d5e4ce21374495f9c5e0deac38ae35b',
	   
	80: b'e4655c40464babde057cb5d46480771fb3b5eb2',81: b'1e17ae5f05210c675e40603ba6dbf1eb9d3d7b3',
	
	
	
	   
	82: b'bafec2815202b1ba65e21d2982589b36c4e3a60', 
	83: b'd80becc079256ad0c7b01f9635eb242924a1c7d', 
	 
	84: b'58149f50482c6e385beaa781462a2ff55c66fa3',   
	   
	 
	85: b'eb7111e35d5e5da12920bb5987ea0e755b7000c',
	
	 86: b'f3864ba1c57b39411e8e7d802e6df8b7c8c52ca',
	 
	    
	
	 87: b'cbe0b0a940972262a0566fe4afe8856ebe126a8', 
	 
	
	88: b'310084aff860c82cd87ccf63a31d17b09a7f5fc',  
	
	
	   89: b'09f695ceec8674fc98bc701fbb533fda3220522',90: b'32450c706c9aa8c8c86d7bccfb8be5cfaf35bb6',
	 
	
	 91: b'4190d991722e693ac20a079afd18ab88b099f05',  92: b'e7d46392cb0acc8647ace2c69cfbe28561e6459',
	
	
	
	
	
	 
	
	 93: b'4d32ad51f30f8011c3e68374851aa1540028acf',    
	 94: b'8daed9b7b5054d71d80bf5d1e2eac0a02820a08',   
	95: b'4320cd3f283297ce4e506dff29f28cd06832bf7',   
	
	
	
	96: b'cd52b2991cb96d908c4fb9a5ab62f56bd49fa8e', 97: b'c39bed8c87da988a1da5c5bff9aff0263578a0b',   98: b'eb94e1a2ae50182ab02489f182f76db1ceb9caf',    
	  
	
	99: b'97cf9fca877f99280d933b53d5330bb9433675d', 
	b'bebeedccdddbaffdebacbaaecfaffbabffddbdc': 94}