class feefbdcabcfabacfddacbdcfaededdcefdeffdd:
	aaabbfabacdafbeceeebedbfcbadefefdfbdefc={0: b'c6a4686c8afa61fe06eb0db530fbc3cde3dc519',
	1: b'b3c737ddfa16df7517dbbf3c5038893ab6e1fc3',
	  
	
	
	
	
	2: b'96a7aff94deca748fd4441588bcbc957fb456f8',
	3: b'002d3863808914a4ada0d3ed981daece00430bd',4: b'c4749215fa113fe49d0dbc4c19707f7a84b3f1f', 
	5: b'e098b8f7215e57b13d6ece98bfdc856371764f0', 
	
	
	
	 6: b'7142e59094652ae1381cb91c4805da875ea04e2',   
	
	
	
	  
	7: b'731af7c2ae2005dfa74b2a5fdd8e43016e6d195',
	   
	  
	
	
	8: b'5e036e36b43eb7b4c956436ea9a6a9944c7ab71',
	9: b'484992505cabaecf1b5e1c4566c920f8abfc5b1',  
	
	 
	10: b'd4841ee20568eb3fcf5f6676fefec1283bcf569',11: b'6a2f90a90757eadfb42a6ef60b5d37534a43e25',
	12: b'dfcc3fc1abeb870a15d5face28acb189deb56fe',
	13: b'8fc0963ed5926f45bd1aa5ed7e55af10b6d62d3', 14: b'135e5bee05203cf9c268c4e3720e3a1e0ca8600',   
	
	
	
	 15: b'55021757d1542ee5a17a1838bf456a22174e031',
	
	
	
	 
	 16: b'ed1f3783dfd6f4b732fa2fe8452360fec9292b3', 
	  
	
	 
	 17: b'c771569d9ac15e194cabd3d5846b9ae5f558fe9',
	
	
	   
	18: b'c85bb22a3df77b101ecd7d1122338f8bc247df7',
	  
	 
	19: b'63712488aeaf40851d3bcdb4f5c90c787626971',
	
	
	20: b'7209f2e86ca981b5e2eba822b6162e31e78c489', 
	
	   
	  
	21: b'8636d8307b5be7ef09c9ddab5a0a106216447ab', 
	
	
	  
	
	22: b'1f596fd5103188c3a2b7a4c7747a43ed2423c6e', 
	   
	
	
	 
	23: b'371c117001e80090e7483948db41ca963e58a9b',
	
	
	
	
	   
	24: b'3d53a503941330d2242157758abb5e810e97fd3',25: b'f4066c803c75bf3136cb4e6abe944e21d31a9bf',
	 
	
	
	  
	26: b'4d9abe59b575ce65c7c47be870ae8c29f82ec0d', 27: b'88e522bef761d4beba2eda8d624b58db3ab3c2b',
	   
	
	
	
	
	
	28: b'f83d07c1aa409db0363169790a3a94867903fde',
	
	
	
	
	29: b'29e5bb18b2f585b283301bb2872991fc91cc6cd',
	 
	
	 30: b'ae6bbcd15e0b11c6ac7c2dd1c14e5439eef53d1',
	 
	31: b'fb21f5227a47347ba323b70b9dd62c3d7d3ac62',
	
	
	 
	 
	
	
	32: b'76c9218de0ebb2765466dc2bfa7a668534bfb4a',33: b'd1173f0d1820848252fc857adff1caf11b488b4', 
	34: b'a28f28fece911c62a62e95d3bf785719258acf4',
	35: b'1ce24e956608807c240d23a6c64119696258842',  
	  
	 
	
	 36: b'304be126ff732dafe6cbe030e56a67ee81a1b0f',
	
	   
	 37: b'4e143c428be71e8d3620f683176ac42f6bf4d02', 
	 
	
	
	 
	 
	38: b'63b570080fd69b5c5e8411e6b332dfb99e55d95', 
	
	
	 
	39: b'852a4ef541825bfca14c88336abbe024851dae2',40: b'1f749b733f511aa3f29be09c9f11ed160ec6549',  
	
	 
	  41: b'28f405a06e7c7b2a0c609a142b7c1aa81d69749',
	
	
	 
	
	
	42: b'51bded5cea857dc0e6dd3f8666607a6978b1250', 
	   
	
	 
	
	43: b'67dc286458e808da81b6711c76786d9718b0202',44: b'7735371fb878cf15b1f5f636f8b6d5db0c693d6', 
	 
	
	 
	
	45: b'2099d653c4be23b034be2156f4462e1c8e3707d',46: b'4ccb56026eefd9ff2dbb6a041cd6948027c8e85',
	  47: b'98bc483e2b8c55811485d1ff47fb686b0138876',
	   
	
	48: b'fff489af2fb74709a7e0affda2db3cf1c6d576c',  
	 49: b'd6e32e91954faf90f3e3211f597cdf9453106af',
	
	
	 
	
	
	 50: b'15f831c866e546b8d8cd3b4d2795519a8080540',
	    51: b'cc0f95733bef6126e513005ab19ac211371bd2b', 52: b'4d00288088fd3ae28831c04a09d50ba666e7e77',
	  53: b'9e0fbe2cad53c635ffb221a50b03e40a73d0095',
	  
	54: b'a0dc9e73e2761daf56d6323d42c3ecebe5585ad', 55: b'48fc8aa93d0f3f693eafcb17c0c24d20a0693ae',  
	
	
	
	
	 56: b'ae05593b88627c025968f60b96c4d08bb80c5f5',
	   57: b'36b7d9d9f37ea13394a55b73ab60f9c300417e2', 
	  58: b'25cc471727d43ad2c35e9539e3f2581f42e1259',
	 
	
	
	    59: b'4685f94aa5c7e8352f1923581ecbe55050ff4de',
	 
	
	 
	
	60: b'071b61f8c2044ffd8de08960637fb23003c505c',
	
	61: b'9d90f90f2bb61824f2791c3a4815cc20659d4ef',
	 
	  
	
	
	62: b'f9b51fcc1db76496b1c4e20302d96056f957608',63: b'886dcc601e535f937893b0247bcf07c44194217',
	
	 
	   
	
	64: b'9c23e74fe10b14b6da67901ddbebbb9a5b49bc7',
	 
	65: b'0878f6dc33bb5a6fc3149c819f46de4bd2d4630', 66: b'062a7eb9d1df00d861aaaee15017e1388a1a556',
	  
	  
	
	
	
	67: b'2918bc55c80b3821bf4aafdeb82b4a9da5e5336',
	 
	 68: b'ef6af4d05202c4698388ff4c08f54b516586b97', 
	      
	69: b'c6d934bc7baf1f8d4cfcb1ec0716222fcba3011',
	 
	
	
	  
	
	70: b'139a3b58e639d50827ab1fb4c5b868d83acfd8a',   
	
	
	
	
	 71: b'99008a279594c9cb08654c085aa6c9ea90d175f',
	 
	 
	
	72: b'4e1a8f1a6fb3023f25ad1f22de71bee6b51833e', 
	 
	 73: b'187088bc6a961f4c51c1ed878dfbeda71c7ab7b',
	 
	
	
	74: b'4c2611d3b83f1a25d048e73b612a4af992c7089',
	 75: b'1b5b28ee8a891168bd03641648093fcbd7a82ea',
	 
	
	76: b'bce89f6d95f93171145d1ffdeb512559439bda1', 
	 77: b'2ac68f121709b55b7147f425f6a216050e44982',
	
	78: b'a19afaa30e8fdd4f234de023d867b72b2d05cb1', 
	  79: b'a45ee38181a7dbfc388cdf274636dbe853bf551', 80: b'750bda841117768f99e061bcc7d24b4bec33f03', 
	    
	
	 81: b'40e42edc166a6c033e12e67efed9cc6f94465ad', 
	  
	    82: b'dcbefeb1132ef64d3f914d7b742e43bd5e442f9',
	
	83: b'a7f417c303520a578bb6a932a5128d9538e3db0',
	
	 
	 84: b'5b96276829859a188b43cdb74ba241a13b5233b', 
	 
	
	  
	
	 85: b'14d49ebe0c0ffc437a4ae0745e83e777baaf4ba',
	
	
	 
	 
	  
	86: b'bcce783af905572a904a0aecfe3d59d03abd471',
	87: b'007564497e69eee46278b7756d84cd4b8eb54ff',
	
	88: b'd4fd2e535a960a1493afa93778f11f813c22b38', 
	
	
	
	89: b'956e8c6600935fb7257f3b2421c11fb922ea17b',
	  
	  
	 
	 90: b'9b72c66e78416c51ee98c2646e25a70178d14e4', 
	  
	
	  91: b'45f1e8fd29456468cb2a95e5c7c9954cea0ff1c',92: b'13604c053edf07d7d60d09fe85dbe7ea458dfc9',
	  
	93: b'12b3d2657b39249fa333a7edd8364ef05c7066c',
	94: b'cb40113224ac4272c04c7551c031aa9b28c5e4c', 
	 95: b'c64f183fbd1fbc3670a317bffb2a903257d739a',96: b'687a8c42ed5b95b7fd08d68e41cdf461531d95d', 97: b'e943322137b6fbe3b46c726b30d3f29dfdeef9b',  
	
	
	
	
	 
	98: b'c217d816c192d5535c65748392fda8f54b90872', 
	  99: b'e5ff3cec9a46a762ea78d8e1d5f5331a562a474',
	 
	
	
	b'acefadceaffaaefbfbcafcbeeefecafdcfeccab': 54}