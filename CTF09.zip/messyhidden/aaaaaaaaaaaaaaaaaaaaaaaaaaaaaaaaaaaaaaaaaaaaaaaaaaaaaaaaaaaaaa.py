class ebbfbeaddddfaeebcccfeceaabcabbbdcfebbaf:
	aeaaddaccaeacaedfcdfbaacfacebecfcbceedc={0: b'a711f1910c44c18cd5234d8f6873995fdeeb1b6',
	
	 
	
	 
	
	 1: b'0910022e22531f629321edb80ab773f33699147',
	
	 
	  
	2: b'c285df2b33906ce16959e0ed02a635ca4081e5f',
	
	 3: b'73499d65295093ed3df8abecacb2dbc6b5933db',
	 
	 
	4: b'ededb65ce1f60e9f7e872a7db55fe8fd4822fe1',   
	 
	5: b'a138cbc7825bd241a9f5551f060b508df12085a',
	
	
	  
	
	
	 6: b'0a12f35a2c8d24099e5aad08037b417125789cc', 7: b'2e19b6cc8034c2887010f41a801f27a3fc6f80e',
	   
	 
	  
	8: b'803ae2551cc7fea4cceb8bd2ce8915d4b12dc65', 
	
	
	
	 
	9: b'ff1f66f0f14887e756cfe7314ef4032dd501490',10: b'd80f1f19ea804295b1886b2c0e2d2350eb048bf',11: b'617fc1cfb00bd6e6f53241d7045cf29ef4ef82d',
	  
	    
	
	12: b'd82ca9099c798239f1cbbac9e546adac2ddbc3d',
	
	
	
	
	
	 
	13: b'95daf745d02068ea7cf47feea23f27e92212e5f',
	
	
	 
	   
	14: b'ac40a7fd0726186cfa783b85be6cec5ae1221ac',
	  
	
	 
	15: b'ea14b70e63a4f7c51346f9fc0793ef333b8cfa9',
	
	
	
	16: b'e238f5208b0b78b4d31c5fb629ba2f4629b8223',
	17: b'c7a1767009dcc96b43521bb000cf38c2b4c43c5', 18: b'132e8886af2833b3635e99f1c50a83fa0b0026f', 19: b'28f98edadc901acb5ccfc102090760858775abb',
	 
	
	 
	20: b'fa7895ff3960ca6312289de6ff2e1ebc09d5328',
	
	  
	 
	
	21: b'1ddd6fa4b7c798759b359de4fc114b3cca68c4e',
	 
	 22: b'8fc39acbd725a0fb81ddd3bfa3a83b4ded090d1',
	   
	  
	
	23: b'eefef228166c1424d86a90aa83441a3722b51ab',
	
	
	   
	 24: b'30024f61b2003341dfb2a858606a08d44448db4',25: b'30a5017b2d05a21f5b5c0f0d2bfb67aa9edf729',
	 
	
	
	
	26: b'8eb81d5b332a298c274c952ed22148e086ca28d', 
	   
	
	 27: b'e05e83d912a16bda130a6e02bf3340d653271ae', 
	
	
	
	  28: b'39d3a4eaa585283db61ac170066e83ebd3e264f',
	 
	
	   29: b'd6928af4bc43e8009e65f02c26492c30517ac3f',
	
	   
	  
	 30: b'0c5e2d3b6527680cb75a5cb7b59ea041c6b4d8d', 
	
	
	
	
	
	31: b'ef5cb4c467af43ba455f9326a36b4eb6f16b8a9',
	
	
	
	32: b'928741316d959415617a6274865abb3f8a7cf3b',
	    
	
	
	33: b'88bb6e43451a37973627607f993ebf61736f208',
	   
	
	 
	 
	34: b'cb43fc9b20b252d63582eb6ef9e34a82f74b80e', 35: b'805c37c372e28fc2329275e68391b0648fe3581', 
	 
	
	   36: b'7437b2e0c0a30807cd8dbaa60135a0dddab389f', 
	
	37: b'0fbcad2cac23c3462d6b0554e771ebd55ae9f9d', 
	  
	
	
	38: b'6d7ccd4953901b0d057c23aa9c9b4eb783dba9d',   
	 
	  
	39: b'e6eeffb95b515dc11a83e2c5551e9a7a78c0c38',  
	
	
	40: b'c8bb09c7937291cc705ba99a035e18f8ea900b5', 41: b'988dd917f493cf6cdaf27000e5c2a4a5191b20e',   
	   
	42: b'859ded70ed4095340ab5735984718770f5df3f0',  
	 
	  43: b'1eb1677321f28d1dbb9f77bb742ae242f570e9d',  
	
	 
	
	44: b'7100b8b4e5daed57cb970274453fe66ab9cac82', 
	
	45: b'5892d9dcacecc8d2a754f4eaa0e014ab4056c72',  
	   46: b'248c795c28172082df4f54c7b6336d371056390',
	     47: b'b19e682fe94a78f9422e8aa26fce3770d984664',
	
	 
	
	  48: b'72bc4fa2ef189f96fdffd3dc59a62d18c9f73bc',   
	 
	 49: b'246f9bcee8f6acade88b5a6179754addddedb1d',  
	 50: b'67f57089d93436fcfada85140636f18d9f0566f', 
	
	      51: b'e92a6fa9dae34c76552cf5e1e656dce1203b82a',
	52: b'35fee201a1d052e2159d46c8bf6ec5de4259588',
	 
	  
	53: b'f9032e9ac238a5ecfa29e9dc7677b2d7bd7710f',
	54: b'765f82e57d9631efcf10a9433e10991015ea3df',
	  
	  55: b'95c561795c99d3851d39c909f44bf548b62461a',
	  
	
	56: b'4a89e35fee35bddb3364c46cd5bf55336d6bfac', 
	  
	
	
	  57: b'1fdce99340d1a7c47b94f3bbdc6e5357f0c2aac', 
	
	  58: b'183ff1cb5d9517eb93b5af3ce2778fe821d27bb', 
	 59: b'c2fd22e4c1424224e2cd60bd520b438b90cd390', 
	  
	60: b'1200ab4239cd23b48b8c1325d5fcfaa48d11be1',  
	 
	 
	   61: b'd670a7aa9f6c973e859795e285be6326d7023df',62: b'9ac753745cf29aa9979df3a6be63223a86bf2e4',  
	 
	
	
	 63: b'89d70bc7822f5664e4be70da441fab5ae6e8b48',
	
	64: b'd5c3a1e09d82964671981bf5cd3a302f4fe0fa3',  
	 
	
	 
	 65: b'a31f0115ab26f5a3d22b3c65684b0cc84b6d64f',
	  
	
	 
	66: b'a05b2564cafdf566bd261d590687602dc6491a5',   
	
	 
	 67: b'382d73adb7784ea4e4cb520f60b1e08b267116e',
	  
	  
	 
	68: b'f1d80cc8ed88c7dbbe868aeacef73aa0c0a76b1', 
	  
	  
	 69: b'dca1cac449ae58b95c55ffb803f6c2640beff0c', 
	
	 
	70: b'f24865f0f76446ac4afbddbb891e232453637ab',71: b'3395cd592152e467d58d2c6216e2122b3ef8c42', 
	
	   
	72: b'9b132b3ecf6f074eb51fbc9517fba39dbda93ff',  
	
	 
	
	
	
	73: b'26d91e422c6b392ed778fa0db26838e57fe21b7', 
	
	  
	 
	74: b'1db3af8d6fef22b3d5486ee93b872f8d51ce851',   
	  75: b'86d8ff9f23b8df27e0356a72858dc72f1308d87',76: b'799c2ec1389f2bc93cef13640ef76eb535ed211', 77: b'a40b455f7410b6b616693b416b95deca4a534f3',
	 78: b'a693e5aeb6aeaeec803a123aa2e721448b0a955',  
	
	
	 
	79: b'49d10e1ef383ccf0c2a90c7fee71f547cc2d994',   80: b'bd9ad38d6653eae0eebc6989b2497944aa50462',    81: b'7c0168c96d72c4f5ce74407f343b9a95e8a1d47',    82: b'06b6a94c6931b6202ad9e30f7459053646611b4', 83: b'94f8994ec1f2269872da0c8ca0c6df64ca2fedc',    84: b'1005493c1e921e4414eb0d9efc80d2376fc5ab4',     
	
	 
	85: b'9f06433ce1b345f92a6a5502708f79578463591',
	   
	86: b'2d45d0b00a90d2e692222ea4053154e86281d83',
	 
	   
	 87: b'68ea23697141217255d035184549d50a353c010',  
	 
	 
	88: b'a9525ebd7cb3999ebff7c2d65c6f78afc3b9ef0',
	
	89: b'cc559c9e70522abe03f68329e9d9e7f15c48dc5', 
	
	
	      90: b'c35ad87131fa7056058b08f4a95e9b291c78e45', 
	 
	
	
	
	 
	91: b'c80255f1acf4315e7ba381412269d2142452109',
	
	92: b'f36ce829bc9f985e12e340ef6119a1ca2cb3097',
	
	  
	
	 93: b'86cf801a5e3a584e233cac580fdb2f24775cc8f',
	94: b'5e870a5d5f35c6549b80990ccdd9ba8b4b4d445',
	95: b'393017056b6824ab6afeb63c978226eb9664141',  
	 
	 
	96: b'a3a18e8d24e77b9007ec9759afcab3089953701', 
	 
	 
	97: b'42c99284014b489a68b7731948a1ffb1e706433',
	   98: b'4eb14c00ab00e66c72d08198e44c67087feda8a',
	
	  
	 99: b'5973d6412440d1a51521f13d4c3b788fb0d07b0', 100: b'75373ee9be3e33108ddb562f6675760b0b6b1e1',   
	   b'cdcbccbffbbaedceeaecbcdcabcaccaeedeffad': 100}