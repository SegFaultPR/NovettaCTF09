class ecfdedebedecfeabcaaebbbeafeaccadffbacad:
	bacdeafbffaeffcefceabbfffbacefbaabecebf={0: b'0857fae8de1d8fc4dac26668edfaa030faaf259',
	  
	
	
	1: b'fb71a08e7a617e97c7887aaf2178d84b943e80c', 
	  
	2: b'8f1716ea3c8367deba5dea99d497d4a53714461',
	
	
	
	   
	3: b'735f4458721541c933d158e7e68ce95631e1d80',4: b'8b00998d4defa9411afb7bb95e63fb3cd4d9086',   5: b'7f6475fa335d58e0009e348f8044e81cf5d1dfe',
	 6: b'e6e661d6a00414bc1a93430191f8a5e4ed4e482',  
	 
	
	 7: b'9368e80cab0a0e77e7bec7aa749ff029e712095',
	
	
	8: b'e67d14378ae78b152e52a738de7f0ad7b73c446',
	
	
	
	
	9: b'75f05e2812c914d5932d59fad3aa612db7a6801',  
	
	   
	
	10: b'bae922f368169c508de95dd18e6e323adff794a',
	
	
	 11: b'b4639b6f273ad4f3160c01997069013286f5df8',
	 
	
	
	 
	 12: b'79a7cf9a356e69372f005124bb1b5707c959274',
	
	  
	  13: b'718cfe36467918a71344dcb126fdf2d3f625101', 
	   14: b'94a0d98ad146e3a68281ef4d1ee7827d03a1105', 
	
	
	
	
	
	
	
	15: b'197f058b5e0fd78f44989cb3feb7444492b4c42',
	
	 
	 
	
	
	
	 16: b'e346b32bdc6dcdbad108af00c1854ed8fbf6e53',
	  
	17: b'03c95667303303a31988c5504cb1e48b9c868be',
	
	
	
	  
	
	18: b'5215a2b716b6544016f36daaeeefe1eca4499ec', 
	 
	
	
	
	19: b'aec54152cfd98782be58f7b121c020000c5aca8',  
	
	
	
	
	   20: b'33609a03e6d46adfcc60905882e956b36abb749',
	   21: b'77120a6bcb5f3ae7a1aad230ebb0506d1024852', 
	        22: b'3b178a0b36adc0e1c6471cfc523e114f280affd',
	  
	23: b'23ab2069be57677ef544524cf263d525e70e148', 
	  24: b'89a92804245ae4209a5b85a00d7a1600c485e7a',    
	
	
	
	 25: b'cb3dee4fb761e8b0bb5f5c96033fc6ea679c282',
	 
	
	
	26: b'ecdf21539ee8fde4bbcae9dee2456c2bf54d81b', 
	
	27: b'a19b6f495266571d5d37f5e93c263fa719ca978',28: b'f7cc85f2f58edbc768dcee7804045fd843dc0a7',
	
	 29: b'11fc957b600b086bc3a6d61debb4fe833df782f',   
	  
	
	
	
	30: b'856ff658525aea156529924040dd9ae7be30f2a',
	
	
	
	
	
	  31: b'598da17be2e571867cc11f85974049d56173969',
	
	 
	
	
	   
	32: b'2466f03d97c588ca41113a6b4d55415546046cc', 
	
	 33: b'97c23d19eed0c1fe97a8b49f14b82948aee85b7',
	  
	34: b'a35f0158707be92bb4cac6ce5263d8b9259c0ee',35: b'8cb2350ac29a13334a49e19bad4810b440cc1de',
	 
	
	36: b'd805ade61bb929a5e4136fb7aef7c14154b39dd',
	
	
	 
	 
	 37: b'6101293f37ee16a2c744f300857af397545e400',38: b'2e36a006da5b5317cd00ae5a6b8847a5e0d8d5c', 
	
	
	
	  39: b'a69ba18e1bdda1d1ed3f9cfb1d2eecf88fbeac7',
	 
	 40: b'f5b8e906e2feb60fd86c450ea4fc0207ac7929c',
	 
	 
	41: b'809de626ef692d5640b68c97c66308789921470',
	
	42: b'18969d255da9f02ef8cab9d52c5bfbc375730ea',
	  
	
	
	
	 43: b'a8cec6355eac7a7626435c88549ab2a1b82d172',
	  
	
	 
	44: b'a76002bed7f418683e4948691e9922a2c41cf25',    45: b'41433528763ba9c66790753011c932567831861', 
	  46: b'98f1ab85323c1d738b66e9efd0e61f53a68dd53',47: b'112a5fb36e55e4d78ecfce842bfb874211b8c24',
	
	 
	
	  
	48: b'ffaad8b983d62301b8e5da3a6de62cfb17474b1',
	 49: b'b00b104d9c33b42fcf76bcede665148fa74bd3b',  
	
	 
	 
	 50: b'3d75723f77bc545f1df0ec26684e3232d6f9c5d',
	 
	 
	
	  51: b'a30fed0992bd18c50dc6923a4692cec76a3eb3f',52: b'c0887169213d824ef34f54cec966bf2d2e213c8', 
	
	
	 
	 53: b'aa669faf9ee626804e6da69a46de4b92cb5ec1e',   
	54: b'd318d574386dd3f8bc7c88a36049dbe4b661fc2',
	 
	55: b'794934516d3a92947ae3871a53a67538ec1bb68',  
	
	 
	
	
	
	
	56: b'abe9eb629652c979a65560ee5a69f24cbfc6eb9',
	
	
	
	
	
	
	57: b'dda26b93c1c8c881bba80e69af469eed9ea17a4',
	
	
	58: b'49539f9e84955a032679b76f988ca70fe43758a',
	
	 
	
	 59: b'8d06a45120e5d017d445ef5a9c69910466478d9', 
	
	
	
	
	
	60: b'32564df98844ea14e45f3988b15b5a66d04b05c',  
	
	
	61: b'cadec84f9480d1062f0a02f752bf95038c8958a',
	    
	 
	62: b'99b5a7e7c41ff040191825497c178462d7dc937',  
	
	 
	
	
	
	63: b'406bb58d952eeced3356f70a3d657a46ebb8f00',
	   
	 64: b'64b252848c73f551c8c7e9611c41366e6d69e33',  
	65: b'ed3af03ae5a5c9718ddb8c02416e3bf5cce7d5b', 
	
	     66: b'd5e89ed5e0d25290bb474f346e00b8de439c3a6',67: b'970727714fb0be1f231abbcede50d02d85cb298',  68: b'3635fa2fff7e25229b2cd800099fce2c0a3f6c9',  
	
	
	 69: b'cd23d1449a38187725153f05d50a943c944a6fc',70: b'9253404ac5bff55f4d9eb038e99de8d8fd79d62',  
	    71: b'353a85a4c9f28ae21decb8ff129cb552c59d7ff',   
	 
	 
	72: b'2a3506e7789532088a1543f7e1869771f7d40ca',
	
	 
	73: b'5dc23f209d95f73c8f3c19d4bff1c5de903ba2e',74: b'303ddd23022da97cd5f4d6d9ec7fb8775452a38',75: b'94db4a3e4d92c2c68d0663073547e5d0d739f88', 
	
	76: b'8bf571f1f9760f97474b16cb9da6d34c06d2c70', 
	 77: b'c9ce91ba561121fe05f4747de29651e62357bd3',
	 
	
	78: b'e2f3af30b5470f0986afe6cad3fb91f4080b2f1', 
	   
	 
	79: b'11f9776c4482708f3b81b57a664aee1576a841c',   80: b'06a2a36f78f139dc9d8fbc0fd9916ae2d4f4fc7',
	 
	
	   
	
	
	81: b'b87cdd10d56d2b17ba648771243b676ad670058',  
	 
	
	
	82: b'b0ff78159ee1e0ba0def1ba9c023cc963d42a55', 83: b'c5429dcf4c0741f6f7ea27b44da469d6fa9f272',   84: b'b16675a7a0e95851111da1b67aac87b05fb7421', 
	 
	
	85: b'65d56f309155e88990efc6e24f7db04c544b5aa',86: b'ee408830bb4188ddbfff328b5086d0d9ebea7ae',   
	87: b'cf4c2fc77bd33c2c915c233beca4ba260b392b5',
	 
	  
	
	  
	88: b'0cdbb0b6ecb32614f9edbb45fdbc09d66f3e5fa', 
	
	
	   
	  89: b'aa369868e2b7b244f1569d0dc787c5021e5aa2d',
	
	
	
	
	     90: b'd1befa7500c3cf7ff6edf5ab49e7c24c1518b4d',
	        91: b'1d8603b97180e2bb98058470fb7faba1a29d73a',
	92: b'c7f7ae88806c22174efbb7d6478ac1f62f166c8',
	
	  
	93: b'77bb056c5be444ec87c5d959e9e441c4c485d82', 
	 
	94: b'0b0bbd9cdc2c53517f06a5b77614bc8c50c9bbd', 
	
	
	 
	 
	95: b'eb855bdede8324365f1d35cd3ac7df30f6e14bd',
	 96: b'5a2b2bc7735a6ad3c3d9435d704b02544eae5a0',
	    
	  97: b'24a3d3efab66b7b985f6b3203b0bfa5a1effbb6', 
	  
	  98: b'78879da994d7cdb3efa5471509ca166894a8f29',
	  
	
	
	99: b'76cc3dc9875967561089176bb9ad4bb999a6619', 
	
	
	
	 
	
	  b'bfcaddbfeadfbffededecbcaccbbdcacfecafcf': 48}