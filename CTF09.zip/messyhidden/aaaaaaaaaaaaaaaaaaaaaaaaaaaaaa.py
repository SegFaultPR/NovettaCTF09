class aacedeecfbeddaecafeddfdcfbfcaecccaaebfa:
	affbeaddedebafadaeeaeeeabfdeaabfddfadef={0: b'a0edde92020236decedd40fea7cd6563c2bf5ff',
	
	
	
	 
	 1: b'e2d8ac0937ce3cdc11e194bff469ed3c4f1c1f6',    
	
	2: b'e44c77fe7be3e19463c89dc7702c79a3b6add35',
	   
	
	
	 3: b'8746cd68584ec8b925f0890207493e3f05f691d',
	
	  
	
	 4: b'd367eb67e1b73790e37a044620c561f1b0af40a',
	
	 5: b'41bac6f31eb15a1d7643c51fe8b60fa10186abe',
	 
	  
	 
	
	 6: b'32368aea316cb30b67036cc0ccd321554d9229a', 7: b'b6056f3158b37a865b2419fef8e78e089c8f6c1',
	 
	  8: b'8b692b2aa35f9fb31bed99e9a5d9ab9a28cd0e7',9: b'890f3b29b82c872ee2d7d4cee430aebe8702505',10: b'9b0da32da41292ce8a2f913b03f6155cdbbd543',
	
	 
	  11: b'f53c2609b71f65561e79cdfc8e7c8618bdd93c3',12: b'4271050470a859616a757800d6ceb5d37376e42',    
	 
	 
	 13: b'd82c2a5fcdbc417f95c04581e565f1324492261',
	
	  14: b'ecd40076a7943d63a3326025cd126218e84c855',
	   
	15: b'aad5674b6795e22df1bde72bed614d7a85b521a',
	
	 
	
	 
	16: b'5ca4686b96edfc2a00b3b4fcd5faf290b11bd41',
	
	
	
	  
	17: b'bbc552cb6a29f5f33eca3a699f9ffed5ae54f1f',  
	 
	
	 
	
	
	18: b'11adbea0e9d8e609281c3b35233ec108e2f126a',
	  19: b'd49c7629fce11948df066b922b7ab5e4b46b643', 
	
	
	
	20: b'508e801671b23e18d70a65540bdaacaa36a6cf2',
	
	
	 
	 
	
	21: b'aa59713efeb3bfdabc3c1e78ac5a0541a042f54',
	22: b'1c129a51e00877c4260d194d14ea0ef3d4282eb',
	
	
	 
	
	 23: b'7525fa9ea37dc117da1a2efaa3846627da08e0c',
	
	24: b'033924c0078fae6380c5329e2c356ea4d910fbd',
	
	 25: b'1a93ac7ec1c53e794e13fea995ad5fb1f083cc3', 
	
	
	 
	26: b'b5e5c1c2700aacc36bbecbfaf87816288877797',
	
	 
	27: b'76a1ddb612a386443b57081c09695ffa8f7ffb9',  
	
	
	 
	28: b'db69fff63ffe3163b53fe6b46b28dbf3c659270',
	 
	
	  29: b'1b5515715eb3e1b50a40b6205ee7d2a9a519772',
	    
	 30: b'e37f6a651a44f4f507d5b4e6f5d5c34f7553fb2', 31: b'af1c9c4443df0cc060e578474761040d2dda4ce',   32: b'495fcf65f8885ea602711eaafb90c768c79de4d',
	  
	
	
	33: b'e397d377fb4bfc5b7923380ddf744b6dcbb4e4e',    
	 
	
	
	
	34: b'868289b77339dd688fee3e3a89b290ec22b5d95', 35: b'513f6363e89d2f4fe5d881b00593342070c9423', 
	
	 
	 
	
	
	 36: b'e4adbfd1d92e785a95d513df98319dbbcde02b4', 
	37: b'b5f9df27d6347e0c33eb78b009df8a008e1686a',
	 
	    
	
	
	38: b'd85c532d3dbc865f1c18bdf7a8f686b081b8cf8',
	 
	 
	
	 
	 
	39: b'6a707aefb624d65ebbf828b4c096b4a05575217',40: b'1cb0d61dfd0cfd28c2a26d07dee51edc55bca69',
	
	41: b'94b8fa2b934c2909c2810b24aebea90cd774e5b', 
	 
	 42: b'07a023dc96e073921dac47e60b9fabb3feff2fb',  
	  43: b'bbc40053146795aa684949d856ed44e70fc9eea',
	  
	
	 
	
	 44: b'68c921ed427bc2098ce9dc2db2c0b210a502fcf',
	 
	
	45: b'e1094f286d8b5659449adcf3c02e4034f065f75',
	 
	
	 46: b'ba3b62c1ae3491714e433cef043352c66141762',
	 
	
	  
	 
	
	47: b'f51e4ab9bd56403ccfb0ecba8547705d5ff2a29',
	
	48: b'e3c3232fa75c8fa2e45a5d5b8aa9cf9d593e3b8', 
	  
	49: b'4c49af3c7fd3f69ae32c6cf6d9d4d784626bd16',
	  
	  
	 50: b'2d6c0ca4a8c3b9b4d2c09827a30a776ecc136bf',
	
	
	
	
	   
	51: b'0131e5c8f7f1b916277ceb338d0d45e4ac0bc6c',
	
	
	
	
	
	
	52: b'd53891a875922cb01b53c34b247927cdf0ec49a',
	
	53: b'c979cae36d21045a786ae56f4dd69739340feac',54: b'8ff941e6ac5f419d280e0e3dcde90ead663c53b',  
	55: b'a09c658d02a4cd80d2381e524355a90207528ba',
	
	
	 56: b'f7ec0a69965e43b613aec28d90199abf3727f4c', 
	 57: b'87ae3064558bad9287fff63966667d924378066', 
	 
	58: b'eedc9d8f27325d98a20ee528a761bdf07399701',   
	  59: b'427222598c06c13dafdc47b6bd44dd47554a98a', 
	60: b'd91f6c36cb4fd3b627a3b4cd4c6de83b99a27c5',
	61: b'18d392b1894314ccfc19fd2b17f653134079189',
	 
	 
	
	 62: b'70d5f32653a7005ede2487f0a0f6703b7a47eb6', 
	63: b'2225d7705671b777f5e3dfe0a4cd6516dc29c4c', 
	
	
	 64: b'17ee3a8149abfccb5803dc79d20f637f5433be7',65: b'5d31b96a598acfeef89d83552398812dc8dac50', 
	66: b'c9ed8d4d58f7e915d24158c1aaa6e6f47e7d8cf',   
	
	 
	
	67: b'2ba47cac383049ba7ab7a28bdcd081987db3d3c', 68: b'5694884b513bc6903fa81cb427822869b5366a2',
	
	   
	69: b'df1172a03d1a51b87f5c105a95dabfdaaf0cfe2', 
	 
	
	  70: b'f7234dbcfec8605d867b96cacd87a6dae03c7c5',   71: b'403d7af756a5e0ab8286793ad02f8ab68aa9ed4',    
	
	
	72: b'1de5eb628116c81e02c2deed6f326ab1a2798c4', 
	 73: b'b1ab12901c87589a7def6fc416ed5f141db86e8', 
	
	 
	
	 
	  74: b'c9d7a6cc6d4dca4a7dc5eace7840648af779bf5',
	
	75: b'f21cbe9cec3d5b59f53d3323095be96b323aaee',
	  
	  
	  76: b'570e3499cb6a6066104862548ca4e97f25b8fcd',
	   
	 
	77: b'5099f74bef68369b241a2ddf7317792790aba2c',78: b'374ed95aae374de65a9c8cbb70e94085b16f280',
	 79: b'62e7e9518bb10004921557eabc178a1b2a87d0c', 
	
	
	
	 
	 80: b'5e8c9dc158cf9336f8ba3b910ca44744b08e136',
	  
	
	
	 81: b'1e5208592e4af88feb669c23517eb8c4203e292',  
	 
	
	
	82: b'b0ee3094bee3c1445e5d8beecba561cbb8953ae', 
	 
	83: b'2c4ec6befaa8f2dc269bbb5e17fb6e411bb9326', 84: b'375896aee359effc1bd611e9ee755e0e74c7085',
	  
	
	85: b'6d8488c632bdb48d7dc27e01fc7dc344c3c72cc',
	
	
	 
	
	
	86: b'7dbc78d933f65014c7378493e43fb7a0fb6b51e',
	 87: b'89060ed9608dcc3361948f7ddce890531fe2088',
	
	
	
	    88: b'52d10031659368ec5d07fef8f8a0c23661e927b', 
	  89: b'c2b77ac2071addfd6374834b867741a08b660e0', 
	90: b'72d4ba5a43d9d992f2836635ea0ec5cda01ca2b', 
	   
	
	  
	91: b'e3e7eeb45d1ad19a5dafa898ddaf9a6fd2057f1',  
	
	
	   
	92: b'f2929643f99997b834fb2b0618a0a0e84d9cc9d',
	93: b'fd54cb9fd45b95dd61c5198219393a40a3775d1',        94: b'e126689770ab0e9c1ed974c041bf6119defe939',
	 
	   
	
	95: b'5e1b39ab03a95096f4d821a60be6a69c1a5f843',
	
	
	 
	  
	
	96: b'989885b7bfe68e24fd4045590646547efc535df',     
	  
	97: b'50c1a35779517780646e77e7cac3ca69ff902be',98: b'e9b8e9b74c28132d888238b7b0330ccdc14baec',
	
	
	
	 99: b'ebc0308837781f25bdb209eabf02f2af2aac5ca', 
	
	  
	  
	b'cbcbcaafdaddcdeddafeabeaecaabefadfeddce': 48}