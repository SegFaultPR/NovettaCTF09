class dfefcdfcadfaafbaffcafdfbafbaccffdfbebde:
	fccdaebaedcaafefacecbccbabdabbbceabffcd={0: b'c15b77c71c340946a88262be9663fd3fc1faaeb',
	 
	 
	 
	1: b'6a67ff9bb7bb1760235bb90874aa652cb8f6905', 
	
	
	
	  
	2: b'daa0f54e09d17f2f3cb1920cf099d2e8272bda9', 
	 
	   
	 3: b'4877943d3c23b943a17b052570236bd46d54d02', 
	    4: b'ddf1c22e0276d475d8dacf98f1f3cba1473c441',5: b'f48802dbe4f20aafa3c081e80af47ed23c22dd0',
	6: b'63ae299cdd6023cbb7d0d3ba9ccec13af18df70', 
	
	7: b'52d6e2b885efb8fd6cd2e97154e3ad2515946c9',
	    
	 
	8: b'9f45abb1187e05059ea9c9510fee9df04f14b5d',   
	9: b'c501ee29b77db3f39215288b555c1c03a05c59e', 10: b'f1f1dd4b5e8a285e9be45192ca7460d115d3204',
	
	 
	11: b'0e07e0beeb5fcc5be38981b82356f9f12e9ddba',  
	
	 12: b'ebc04bfbe20de1a60a74d93ea9afe5290ad19c4',
	 
	   
	
	13: b'e968dd30851e79e0e65bd92cf8f4be9fb3577b8',
	 
	  
	
	14: b'73d4ce625bcd046f924274a868d1171e024ba94', 
	
	
	
	    
	15: b'a90bd4422b14e5b033f15f062e5b6a7d9ca5d4a', 
	
	  
	
	
	
	
	16: b'9684865e8917f7a5a70fe4261c6ac600b026228',
	 
	  17: b'fe027765dd605bdd30a5cad5b7d1df08e5c6e37', 
	 
	18: b'8acc86a1200489b03062383c533daf222eb8268', 
	
	  
	
	19: b'935da035f67f1c3708405c0081b7f0376c15662',
	  20: b'8741f7e4b2bec765146fc1354b76f3b2132a3ab',
	 
	
	  
	
	
	21: b'c9821b8faa689ad9970e19c3d163e0b3faf5a11', 
	  
	   22: b'5582ce06b122d2c6a2e9d984139b566ab484d0e',
	    23: b'1c08f2d7921f32b71c720730a7fb7232e9be201', 24: b'51c3b340593a870c5ad6a9404cd98591fd6a1eb', 
	   
	
	
	
	25: b'de8ada0f8ac90bc661015717fdb9fb639609794',
	  
	
	 
	
	26: b'616b7476e81f0a3655606e5f7723703970592e2',
	
	
	
	    27: b'5f3101764a66308927be05a4177e6eb04600ac7',28: b'1e9547a91819d77672d6c6b8a04d84da2247eab', 
	   
	
	
	29: b'e0846273607392c952aa541082b8b2c4e9da0d5',
	  30: b'7c57a02390882d92b83422cf8aefe25f51016b5',
	 
	
	
	 
	 
	 31: b'252aafcc825622e704c406650f0c3a8668adbca',
	   
	   
	32: b'7a80c71c1c24211da577bdbb1e31b61ec7e09f1',33: b'd3d9bb0334e12df2973fe48e64c0f1e6cc3e21f',  
	  
	 
	 
	34: b'2c1169c7947c077d73f4693ee8497655a69559f',
	 
	  
	35: b'ca546c706de8237103ae46f35bd6c6e47571ddc', 36: b'2c88ca6a2057237a10c0f2f543dcd7395b3fb24',
	 
	 
	    37: b'e8b91de435761f403fae909f2ee5c6fc10477c3',
	
	
	
	38: b'eff87757b077fd04d6746788b837d9186ce093a',
	
	
	
	39: b'4acebd1cc77b06cc5d2c5a058dc3b482e9faa49',
	   
	40: b'c9ea7312fce87ede712777438a26b78564e0887',
	    
	
	
	 41: b'e1c7bb79eb47c069cebc5f8db1fff7e014e9c74', 
	 
	
	
	 
	
	
	42: b'9c9ed6b67662c7776fd16e3c5f40cc9fffc9c19',
	 43: b'6dd2d11e5246df4df395739bb55f2218d3ab99a',       
	  44: b'3e133fd197d9cf7eba208624cd0184b623ffad8',45: b'2d17c1dd2be5c641623ef5c2361835c590e3704',
	
	
	 
	 46: b'14e3fb6c91c5f711c36ed78aad4c692066c193b',
	
	
	  
	 
	 47: b'f5e38a80b6764c148c7c4046c677ebad04186d4',   48: b'6737601433dc1012c2df308efe852277f67a726',
	
	
	   49: b'9406e024f0248ca1390dc2fcb62cb4f57f931aa', 
	   
	
	50: b'bff9750244fbefdad7caa667e1b66ffe54c01a5', 
	 
	
	 
	
	
	51: b'a509b785ff30aa89ebcf9c319066f896fc2492d',   
	 
	
	 
	
	52: b'f2578fb6a415af447a6e17e18b01a8676c1f784',53: b'3dc3c2d90c383cd317820f9eda1686b40e32da3',  54: b'7509463523eb1340d913da15d1f4b36444146ff',
	
	
	55: b'4861e02d238c5cea28448b435f7f67f16b5fd1d',
	 56: b'ffd2f62d56d3e28e0d3d8e04857da2a4e4f1920',
	 
	
	 
	 
	
	57: b'3093ed8e1c7bff661ce3a2ebbe45cd58a0fb691',58: b'3a245aac972b1647ac8b771794dd81ae234b689',   
	59: b'ed5153d2ac28c93680873c6b78bcb02a5eb9891',  60: b'4bad6278e1d9b5ab48bc93a9f1c1e8c6798ab2d', 61: b'e30ccb76f5cd10fd6ef17a05cd110c5ef6286a8',
	62: b'9f677eeb96712cc3e45c5d20b5537db3be40173',63: b'dd532a1b5315e8b0f80107cc5f2cbc822aa6d4c',
	 
	
	64: b'a9f991d97c504cab42279dac4a03ae47d143b33',
	
	
	
	65: b'6de2496c21f0f02aebf3c74fcc8f398cae0c0e7',    
	   
	
	66: b'cd0ba29e42b0cdf001f7097af4148597a47adb0', 
	  
	67: b'2a889d5343d3985604e16af6bba84f481d0c64a',
	 
	 
	
	
	 
	68: b'fa6f162cbad27155b7bf510da60b198f9d949f0',
	 69: b'eca886fdbc65f386664ea60cfc1e17525482c86',  
	  70: b'840f8af9ede72a550e8de0b0c81ca407e6bcfa9',
	 
	 
	 
	
	71: b'99845212560ed2730615a6e528db4f103341a93',   72: b'b10fb8c75c2e3d1eb37369401f673bace1ad3ea',  
	 
	 
	
	73: b'800b44bb7a8b24311b7affc854863fc1d023db8',   74: b'dbd08af52c6725e51de8c8ffc2e95d351ff4be3',
	 
	 75: b'7988f7105d3989957a549bf923e1b324aa9572b',
	
	   
	
	76: b'a00af483af2531b289b9e3e9ee175d4e266e6d3',77: b'1b403a85360010a2955ae914124ed7c50e979f2', 
	 
	  
	  78: b'8e369122ffb86306ac802a218a1c712b31a33ef', 
	 
	
	   79: b'579b967459a7d6492f7b79f2a5a2c2a82c7dd91', 
	
	 80: b'9daa5e0258906424f5ec8123e057cf4142dab7a',
	
	
	
	 81: b'44ec72ff030e3c24778c5922b5ee2b1d886c2c4', 82: b'aad078ce8612e97d3f9a31077513670ac6e59e9',
	
	   
	 83: b'ad49401dc9c5a4b64e9c9bd51c56898bbcaddb1',
	 
	
	
	 
	
	
	
	84: b'09f77f29491e6872526166db33666cf671168db',   85: b'0e79d5b45091b5aec41e66bea139b4d42ab6a52',   
	
	
	
	
	 86: b'fbcb019777def47238b1c3bd886535728a61f0a',
	
	
	
	87: b'092681ca3eae399564df3b53924c24c94a5aa75',   
	
	  
	88: b'714fdb0c91d80b339b102e4261e2e07f6597114',
	  
	89: b'8fe24c4a5c591f0efddb618498cf7da10de2845',
	 
	 
	
	 
	 90: b'e0631ecffc360a4bc1bf0e1e99e2d1916c6ae16',
	
	
	 
	91: b'0b3a3537c26ac8ca15d8f8ffe52b8abe65da4c4',
	
	
	 
	
	
	  
	92: b'68d3da15377e48e60dffc9645e30ce25a574aa1',
	93: b'7a9e722fa46bdec1a6cc0411ae764fa16cd650e',  94: b'0a56bf5b276a2139ffc4cbd5654f8823a4a456c',
	
	
	95: b'9d59081f58f0d8ee45f56894b07839496c3b75f', 
	96: b'0c6405b194d796607683bce6480fd0a44f0e14e',
	
	  
	
	97: b'bbc583822b7afaba5ef38090b460a77ce544c80',
	
	
	
	
	 98: b'0a1e25dd0e55560208d4905eba8d734a2174e5b',
	  
	99: b'68931cca88521e13163641f5faf1b557a88dbcd',
	b'cdaecabcdfbeeffddddaddfcdedfcdcaffeaeec': 42}