class abcbffcbccabbaecfaaceaffebcccafedbacecf:
	dfbecafaadfcecffabdeecbbfaaadaffdeedadb={0: b'00492618d079e1921b7b2db79f05d6b7a66f139', 
	
	 
	   
	
	1: b'893d651c481b1ae4a6dce5160375ec1fb883b8b',
	
	
	 2: b'6216161d3bc60b0dc9a5e84eb48a7ca54f23acf',   
	 3: b'2710b993e593f5d4e4bbf05d3188cda29639317',
	
	
	  4: b'2d3c505a6ec3bf90bd39f31fa036aaa2e8d5b97',     5: b'6796417559094aac7dade417c883761a38671b5',6: b'7a7d8701c058cb60a32aea23d4e8ae04ce3f7e6',  
	  
	
	
	7: b'fb0e56f91da7c455b1166c36744ee9307c5a0b9',
	 
	 
	
	
	
	
	 8: b'5525df5ea20c6d80365f49c06163f0e8d99507a', 
	
	   
	
	 9: b'f9790dcd491112c7f2cb141deeedaa16df1cc88',
	
	 
	
	 10: b'dafb736a62fff2543be1626f6170c2461a74b42', 
	 11: b'c7243620f7b140c3f97553bdb1cbce6fc7e5976',
	
	
	
	
	  
	
	12: b'3aacb51fb6839d9c9b7daabfc5e8249dc242ee9',
	13: b'92c8bcff289e089d00eb3100c735dae79a56993',
	
	 
	 
	
	 14: b'7779fde6ff553ab0083fdfd45369b673bc77425',
	 
	    15: b'e69672215ac8cae662e5b1d20f9dcab6744508f', 
	 
	 
	 
	16: b'f7f9f79a49a77425de98ae0c17b7ca9c5fcef68', 
	 
	
	  
	
	17: b'3ac0dedc689a3d79ed359240da1504f03c7ffdc',     
	  
	
	18: b'30892fa11cc84395c2122ec7dee64e29d49838b',  
	 
	  
	19: b'1d527b30b8f7dd3f06493d4e69f1f6d9152a4c6', 
	  
	
	20: b'3fb00bbbf1749357fb039b9212f52d9b71ac2c2',
	  21: b'7aeaa8d6010c01be1b94b6da40ba622e41f07f7',
	  22: b'b0979c7916b64714f0d324a40ae4c321ff8c0f9',23: b'0299ccc8d61d8b03300b69bfa6c05d62f14e291', 
	
	
	
	
	 
	  24: b'71b0e1277b38e51c039155c533f1eb33f9c5809', 
	
	25: b'386b856823b4caeacd121aea8217188c101c8e3',
	
	
	 
	
	
	26: b'4e605e1405eca40c4a2872c7a989d0eb40dd265',27: b'd4f568626c883e43038666980abe6ebef144612',
	     
	 28: b'8df886078687fdb512e04882081077dadcd56ff',  
	
	
	 
	
	 29: b'4a37be50c2465efc89c12ed29c2816ad43d13cc',   
	    
	30: b'5ce62a59430e69614583f8c4ea38855ed5bb18f',31: b'c6b211e5d94789aa1c50c6f52816ccbda68953d', 
	  
	32: b'aa43ff37dbed5575d01098550ae4d21e7e7b6fd',
	 
	
	
	
	
	33: b'b0ec99b837e0a4f63cc922e878639b470da3cc4', 
	 
	
	
	34: b'708992c6538bababc188bc357c5261ed5fa9a40',
	
	
	35: b'9107a9357fd23974b4bfa4861a00fdc7212cc4a',
	 36: b'ef46934af4ab2b35d424855c56814212934d752',
	
	  
	
	37: b'd06894a3796fdb4fe67e3aca2b8c2498431dfe9',
	 
	
	
	
	
	 
	38: b'8adfa297028b4a59a92ec4eec83fcb15e0f9aed',  
	39: b'30da1479dd1bc13d79dfbdafe0b05f9b954229e',
	   
	
	
	 40: b'ffcc610901bb81ed2e0590c53ecad7e6951a809',  
	 
	
	
	
	41: b'11558cf763215ef968d55bb8ed3b77957f05bad', 
	  
	 
	 42: b'8f419bf684028e064afb0474fc6b4d4834dfb10', 
	
	 
	
	43: b'591718e47f26f1196568826860969e1df700824',
	 
	
	
	  44: b'd7222d5f38d90f04d550efd985ae809ab1ed7e1', 
	 
	45: b'19b644395a4c64a62d8e35e664a0c17d5617293',
	 
	   
	 46: b'80f9847ebf3f9b4f94b23456851ef6cee1548f8',
	  47: b'0158f133a50f494b9aa116ef0734e3c262f7a83',
	
	
	  48: b'd1dd7019667f3df9256736131304cd98f1724b2',
	   
	 49: b'ce88de08b512b39a4db4100a7458f8205873a68',
	
	
	
	 
	   50: b'73c47f35bd8a3b271d2bf0d30c8e6411cb8853b',
	  
	
	51: b'60d24eb0cb7418e23e9a533b523708565e59ec5', 52: b'b21e988acc2d146d0df4cf7bc4a2e07d7387fea',   53: b'8359e27b06eceffbc95a5e5ebe8e14d056ce7f0', 
	
	   
	 
	54: b'2c72e3c0c3cbea9e2ccc4f36606b20ef42ea34b', 
	  
	 
	55: b'949f5c2d18af7b60627c5dda82a974978e43ce8',
	 
	
	56: b'73b63f1ff15107baa28ce8fc1a272ba465e0a10',57: b'c6efe411383d5e09053fc0af9c48bb6b2440c23', 
	
	 58: b'c15feb3e7555a86b0324ae47199ae5529653e32',
	   
	 
	   59: b'b524c393ff71c80e644914d5efd605449dc6aef',
	 
	60: b'573d84c1d9fc319ac1c700fee27e24444ef4236', 61: b'5ece1e5f0df5cc8215ae4f76dd56dbc7cdec49e',
	
	
	 
	
	62: b'cc466f2bc64e101aa9af1ca8382cd229e9bbd37',
	63: b'33aedcbd0dd8a717189d48fb8c622ba86c1fbe9',
	  
	  64: b'132d2727b4dd89ee11f2badbe13485ae13631ba',   
	65: b'2e17cde70364d588bf8f35bbf2872a0603b254d',
	  
	 66: b'f7034fa9b7243dcaaa4e6464573de3d2b6b6c92', 
	 67: b'6594ee4f1c775c1733dd6827098f91340cd0285',
	
	 68: b'225ff2610ff8982107e7ceeae1e3e803140f68d',69: b'd7da5677e46fc25e2bc40a2a0bc27f1163b2672',  
	
	 
	    70: b'0bfce75d6b1857b3b1066880858b265ca9779d2', 
	  
	
	
	
	71: b'841eeed54c5659f84d5d6dec390f07dd22f6c81',
	
	 
	  72: b'343d5d091d9fedd480418137de25a794bc5aec7',
	 
	   
	
	73: b'd574b99aa02242557fee3851d57e606395d51a8',
	 74: b'bd5312e8d48d386af282ca51a8aed6d12022a0e',   75: b'03a6ac7962466e748cda8bb766e00c401fbc413',   
	
	    76: b'3c4e193da1d66e5ab3ee8e3108280c2efe80905', 
	
	 
	
	
	 
	77: b'26527533449c2739ac4e2cbe47fc4e2cce43fbe', 
	   
	78: b'cba7485f0d7d6781cf8836f3c0303efab074f12', 
	
	  
	79: b'5bfd6aa3e4f7b80d687846e13c861b45a5735c2',   
	
	
	  80: b'4964ff4bcad9b6e2a18f7cb05083fc48bc59665',
	
	   
	
	
	81: b'8feb544af4db64d874c3e6921e4742da3b3619e', 
	  
	 
	
	 82: b'31ceeb930f41703a54a23afafb638c3ad0ae785', 
	  
	
	
	83: b'a89cce7a8bc18c502ca72e761d5ad895e54e79f',    84: b'5ae3bd46c7ad24f9a6546fd26874dc5ecdda75c',
	
	85: b'70126ba660467529fb7e333ee1d0b4de2c06d51',
	  
	86: b'8245e1f20d0273ef7fb432756570e6c9a25a5bd', 
	
	87: b'cc6257c77b525bbf39ebecd1b66a17bb5c57202', 88: b'43f20b2e200d72607661ba1b81c5e0396738eae', 89: b'ee338dda70cd1e5e696f86e31c2ee8d28fb7905',
	 90: b'5277308d7736a0860de5635ae97acdfbf788690',   
	
	
	 
	
	
	91: b'7c5e63185aa2806dc9e0ccaab837d8be6e63586', 
	
	 
	  
	
	 92: b'83b0acd97811ecd457be2125fd101441e295925',
	
	
	  
	  93: b'b04f48216ca1d9f476d161e56b84182f4b51cd5',94: b'7bbdcfee5c5770d0db868b64c984b03492d1f4a',
	95: b'ce5480242a605ae7a5dc118f40e194625888f67',
	
	  96: b'3b7ac4342e6d984adeba1167bf1e5ea680831e4', 
	
	97: b'6c2266d7c252b93354f3e65e8029d057f8c9a1f',
	
	  
	 98: b'fdf4d7fd55197d87b6e2e429b61d88f048517d6',  
	
	    99: b'bfce28aeace7a8558474c2d53941e1749a74b27', 
	
	 b'dccfeacdbeaabbffdcfbeccccabceeaeefcadba': 5}