class edbceadacfdabbedbefdffddaaaaecedcddffae:
	efbfaeababcadbecbefadbedaebedafbaffccfd={0: b'c1ed5b122c4654930752d44c9ee8f845c1c4b21',  1: b'7c78c3a2141a0153f1adbad623d4097bca1b287',
	      
	 
	2: b'81cda5d711e4c0b3e744b06ce4888fff6a77934',  
	  3: b'4357da90130f42f7099ebae57c45ee45c122362', 4: b'c9b062a2ab37710181cf8d57a359d74d4d5fb58',   
	5: b'8395b69b44aadddcbb4a594c014a5049f6e43fc',
	 6: b'80af0227569859e4804d27ca3965a7903c80e78',
	 
	
	 
	 7: b'da835366fe5e363986b0da6b6ffb9b892531098',  
	 
	
	
	 8: b'e6fd093dce62dbf9d0e37823bcd99a45a31fa14',  9: b'7ab4693b60eda9eda8743d7a64cd59e3aa7064b', 
	 
	10: b'fa9c48d7bc01da3bdd55bc01ccb9eaa8f316c2b',
	
	  
	 11: b'7dbdfa09c1a454f342dbda8b38d8a6607cffae4', 
	
	  
	12: b'ac8618630eeac63c58286eebff64c44ec2d95b9',
	 
	13: b'999c7714f68455824b74d9e219eb5b92911da6f',
	
	
	
	14: b'128542416b5bc77fd5669552c16b4ba750d3606',
	
	
	 
	    
	15: b'ef88c32536533929ab9811145406b092f177a3d',
	
	
	  16: b'de3cee7dd7a29b1fe2556e86f9c1df6e71f6ba0',
	
	
	   
	
	17: b'314269e7ff71bef7e5914edb61e30d0c2a0496a',   18: b'c410ff5112c0a16d2f43085a81bf8fae309c852',
	
	 
	19: b'fd197cd39a9033c448ebf07e730cf553811f3f3',20: b'7dda9e38d5487ab6daf73d3a6c2bf29fd6c7a61', 
	 
	
	
	 
	  21: b'9843ecd2cfc6f13fccd70da50e1ebe0a3f79c37',
	
	
	
	22: b'b8bdc80f87e3413ab239e1ba7684ead1677fc9f', 23: b'59ab5a631c9674f75adace76b21c205cca50be4', 
	
	
	  
	
	  24: b'b0230a0fc4395638fbd89b221b9d328e30fa814',25: b'7a4b38e045ba1e9a043b2a382dd276541689e27',
	     26: b'64cbe7cbc53f235a57e3a215f28407308607285',
	
	27: b'7bf2fdc001573b1b734380e895781ace4ce031a', 
	 
	  
	
	  28: b'20f6c7b7cfa5459903a4eef20ad35f074690bad',  
	
	  
	
	29: b'dfc8619c7341f97d6fd521108eb5d64ec1f35e7',      
	   30: b'6ebc0c0846320292800748c56a6e2fbc7c221cb',
	  
	   31: b'f1ea1f9542613962ea2cd802cb4be6dbfdcb8fc', 
	
	
	
	32: b'865cfea21eb89c8424c88a80d7b5686388cf2af',   
	
	 
	
	
	
	33: b'71acd35ecdce509f895e1b771c95ba3d80b174d', 
	
	  
	
	34: b'156b2e17207dad39ce49c8e1079393e26712f80',  
	
	
	35: b'148c3b13fee9ae7fda5215161c8dad784f7c57e', 
	
	   
	
	36: b'202adad6e01a6d81ddaef3b691abc6222e0237e',  
	  
	37: b'e36f4f450c5f544cd2aea53cbeba37ecd0a169b',   
	    38: b'c6800e0ade629a52f4bfebfdf8ba281eb3414d2', 
	
	
	 
	 39: b'735123b89e478a1f1c0b3c5e66e44cc11ccaede', 
	
	  
	 
	 40: b'47859248b200efdc072453eeab2ab2658e51958', 
	 
	41: b'e86e679c55a9a59aa45d5994b9f51e3a2e2ec0c',
	      
	
	42: b'63c40ab128a668c81627f131c6a7aec6c37d5a3',
	
	 
	 43: b'1b0077f8e768b163908b9f273ea7901b8787b70',
	    
	44: b'be4987015152c430182eda35b6f39c6fa446cf2', 
	 
	 
	45: b'a54a6b13a25f7ccba0004b72f850b3db6e77504', 
	 
	46: b'69e2093feebda4b46ff887110aa495d632a8481',  
	
	
	 47: b'fd495a5607fe318e27a4fc43fd04a2c8e7563be',
	
	     
	 48: b'66629edb0849fa1132e0f8c33b763d9a48dd194',
	 
	49: b'c403903c0c1946b30fd754283e07a218eba057e',
	 
	
	
	
	
	50: b'8625e0fd365b18aed0059dd9773c22f68931f19',51: b'e302fa8d6617c3d1d3a9829eae1dc3171cc6e7a',
	  
	  
	
	
	52: b'b3f2bf8e5a49c04f58a779d5b14a6f979bf341a', 
	  
	
	
	53: b'196f3109674ff3cccd49941fc04652d78e35b4b', 54: b'462a07f6827be66713ad965bf48763ec0f78b69', 
	
	
	 
	  
	55: b'4be22e17644c97a17580f3ea89d0ad85c296455',
	 56: b'acc2cb717afae771d55b28d08b05d59792b86a9',
	  57: b'5265e4e415b01639bff5a99f972e1ad612c230a', 
	
	
	  
	
	
	 58: b'bc98f35f1b813042508b5d62047b7b60e974470', 
	
	 
	 59: b'0bc36378c82f99d07ebfc9ee1ff5d4d6e2f9a11',
	 
	
	
	
	60: b'aaab981318ae64368e9ebccd3e6d8cd50ed0e6d',   
	 61: b'a0e8cdc4bcef4cf244e3f0f85a5c4c00353fa16', 
	
	    
	62: b'a0c286b611e18859575317a13e746b6c0a59039',
	63: b'a093f183f655b73fac87367b993041f41c19e66',  
	 
	
	
	   64: b'ff4170e536db8d1c698cfb7b2feb4aa287bdffd',  
	 
	  65: b'537c3ebe1fe0cdf3862d6dd2cc7fbf07bfb4569',
	
	
	
	
	66: b'8f491db272ccdea3031813ebf2f96dda3ccdfd3',
	
	 67: b'8d0e944a76e24f635039393677276b6336e4632',
	
	
	68: b'81bb97f40b0376133df1f7cf82af1130d3f72cc',
	     69: b'581b105e30620a9ee4a00709e776dab8e4d2994',
	70: b'2da8eaff9781e74ef4b36fad9a419045be54027', 
	71: b'651b5cad8774aff206355ebd2de404526b7216a',  
	   72: b'4badfd91bfe57df9d2f26629ff4c694c49ad6f9', 
	
	
	  
	
	  73: b'87238741e63327dead49811086a2202fae0c0ab',
	 
	74: b'd6bdafd914c3cf0f716c5b71b012d6c3356b1cb',
	
	
	
	  
	75: b'4eb56835ec01144d02c91881b793717135223a5',  
	76: b'a77a93b599c8bce4ab4c8fd00df5a7d2fdf0eb2',  
	  77: b'390646ee96c61e5ef7ef6323f961b9adc945739', 
	 
	  
	78: b'2593911c60ec97f28a7519983ac665f21ea48d5', 
	
	  
	
	
	79: b'c72db6061622cdc62db5c1a7489fdb9f5d8bab0',80: b'd547d95af77aa45792b55b2b757af179988135a',81: b'86044fe1eba8c39594eaf24a58e21b9f0dad040',
	
	   82: b'9dfc49335fd3c5689f316b791ce4b1067e063df',
	 83: b'26dc97ae8ea4ab048af6a58e4b5aea9ab1b9185',
	       
	84: b'0d0d6d7de7aecc8c92eefa00c829ac21e1cebe6',
	
	 
	 85: b'828425f678e9d99197558ea8447b8a0833a62be',
	 
	86: b'5b290d2aab7e04a87c2a53e1852406a6da0747f', 87: b'a436c985a8fa016880a0bbbeda6e047f1fa9434',
	  
	 88: b'd46b7f68a9e87eee1ce63bad0d9fce50ac43e72',
	89: b'8560738db3447e29f6cca66639d56abd33ec4fd',
	 
	90: b'64c6e468f46c4955e53d66edbed7a0a51c45747',
	  
	
	 
	
	91: b'3564c5993bd4dc43a3d1fa7a1d30075b3de4798',     
	
	  92: b'a82dfad09d9829bf47d68483da0697f48f57eac', 93: b'0b1132787a0ba34299d88112143f68e8d19b4d1',
	 
	
	 
	 
	
	 94: b'3f07324498cd157188cf8f700d502ed971fec2d',
	
	95: b'6d7cda1280d2d8a99c688748a4f24f0e7d8e32d', 
	
	 
	96: b'a458ae58325c1443ee52b688a73258a97036576', 
	 
	
	
	 97: b'813a2385fadb2a24153e8d147273593d6ff2bb3',
	98: b'd0d6537af0a3ffada5c9e0854156c489f8da5b9',
	99: b'009e3d5a8cb15ee18346ce73d719f583000e7a3',
	 
	
	b'caaeffadbedebedfccdcfbbfeadbfaccddcbfcf': 14}