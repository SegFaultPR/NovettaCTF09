class fdccebdfdebefaedbdaebecbcfbceaafbebaecd:
	cbaaecbadfadacbbabecebddebdefcbedbecbbb={0: b'67338124d27afe246fdf871d28d70c7f74af016',
	
	  
	
	  
	1: b'4653670e8758fa3473637e5d3c69665df174f68',
	 2: b'8d23ac6723dfb45535936df6e6031947f85dcf5',  
	3: b'9dcb245896ca68d16c292cc644efce7c0479209',
	
	
	 
	  
	 4: b'1da6893c12b7654b2d1652fe5721c5f0094cce8',
	    5: b'ed906fad8aca4a69116eff9af4649c199e8654e',
	
	   
	6: b'042305039d36da9c8b77641807ced7af7e749c4',
	
	
	
	
	
	 7: b'a6876c7eb25769a10a8b5637ac1ba7fe930d591', 
	
	   
	8: b'7ba7736b353ad550805d44af0a2f868bd7b5aa7',
	 
	9: b'6519195c28e96f81f6a592881d2db8df202c791', 
	
	  
	 
	  10: b'4ce694e0157c126019fb252e4c4e662c5b8f399', 
	 
	 11: b'afd3c0508d2da1ff4e85b668a44b007686ee2e9',        
	12: b'33707c7e909c36f62a4e04ead1d19eb1d24db4d',
	
	 
	  
	 
	
	13: b'6a497bcbbf62af5ee97cffe3b7208cf84e388b3',  
	  14: b'6f5bc9e1cd07024e318feaec85e57fa853d7f6c',
	
	
	
	15: b'75b02354cc100f8a90df6617646be1e777a754c',
	
	 
	   
	
	 16: b'54e4684b0357af0630ff1a46678dacc00a57c2c', 
	  17: b'bd009b5bc67d4bec6583b3f2eac78f0ed008302', 
	  
	  
	
	18: b'ccfaa0efc0c13e4a1c3f3be3301eebcc31ac972',
	  
	
	   19: b'0e20d6f10f6d0d9701e9086b6b61cc3e5034583',
	 20: b'47338fb4ec46fa9b8f372a79d6e5dbbf52a834f',  
	
	
	
	
	21: b'f2557c928bf0d635711d54cb1ac49b07ac418af',
	 
	  
	 22: b'0d2c66ce758f36bb4688b828a5d4871e07a0388',
	
	  23: b'2b335ca8d1f7f480c36d56f618d5c54c68fab41',
	
	    
	24: b'187ac75a0e550ca5cd1c89cd887fc4763e689a8', 25: b'd42b34c429e2386ec49472d8420f0062a457385',
	    26: b'e821a1f67d30d3dde1b7a98fccb9138889d078d',
	27: b'a70a17389b1579f56928fc89b83da90368830b8',
	
	
	 
	
	
	
	28: b'e20bf7bd8e3a470e091dc1490d80840924cc04c',
	
	 
	 
	  29: b'b3a54e0804639eb7857d836d55a5ae740e41229', 
	   
	  30: b'5b3ae9461aabc9e767e41e2d9506f687bb97453',
	
	  31: b'6293157496d7748725e10eef13da62abff126f7', 
	
	
	  
	32: b'9e0e19a179c95973e08aebf0fde8219adfaa200', 
	
	 
	
	  33: b'f9b9e2421b514d689f27b0d10464cb5cf1c19a5',
	34: b'4341250149bdab994d5cde9e5dd1b99270cf968',
	35: b'83921acd2898392f91e2b9654143b938691da90',
	  
	
	
	 36: b'bab09184e86a08bbbded47bb58ab6a39a2cafaf', 
	37: b'ed62ad5fa851e5e64eeab193cd7cd561e729c65',   
	 
	 
	  38: b'd0beb44ce0075cd12c494c6773d4e7b4a9ca323',
	 39: b'fad38d3f08bd201a07688d15bb3c310eddb4c6b',
	
	
	 
	40: b'4748e071f5fcf294179821fb8bf09231f9bbb67',
	
	  
	41: b'580b61f5585f77b50f77eb4e6f20a6a073bf60b', 
	 42: b'69e60aff6dffb123496db4229b94cf17b47cd13',
	     
	
	 43: b'79e526bd123b0409a52785df5f749dea9b967eb',
	  
	44: b'88bce29909bd9b650641fbc8036bcf117c8ec29',
	
	
	 45: b'ae1b4cfbdd583ba5a286633d2e6742cb8aa0456', 
	  
	
	  46: b'd02b47459da9b518400dc1445741ba982f28025',
	
	  
	  
	
	47: b'4b5bb372c82f20744af27519658539b936a0a6f',  
	     
	48: b'fae8c07c0e02530f75bafc37a79cbaff2c44c90',
	    
	 
	49: b'da57e84fe69f8d65cda2a74cc59abd09965ab97',  
	  50: b'7c7f313fba15a1c6cfba825e07d552c21de9ae5',51: b'13f6a193e65e7da9cd9bc412e2be976dfb93b0e',
	  52: b'1ab0bb1020eb4a0112d73b95407ed9f58d791f4', 
	
	 
	    53: b'dd88a047f032f7b7e440cba7efcc46ae2246150',54: b'2fb5c3af5227895d66e04cea2d5c542690e95e9',  
	 
	
	
	
	 
	55: b'fc75f2c54687947d47845ab9bb847278edad147',
	
	56: b'27c232219b4c37f3dae8c5752ae3a0584d5399d',
	
	
	 
	57: b'2331c73fd7cd141b22c39fdb4b5a4e2025ac928', 
	   58: b'ad410a767191f542781a2656db161790c3c896e', 59: b'd6341a2681e6ba86ff7031df65e7ba6ec2efb67', 
	
	 60: b'47132b83dba82537e29896ff58848e87a5925e4',  
	
	
	
	 61: b'028196af068389028734d1fcc673d5fd1fb91c7',  
	
	 
	62: b'37da91b75e35fd92096f0cb44cb3f9811c65eca',
	
	    
	
	 63: b'804955442f94794f1064002669dbbe35eaeced4', 
	 64: b'fd6b53f8db6717a8cdc97b077ad3866af1ed308',
	
	 
	  65: b'f3b5a330828ce8f4bc251c5f69f47558062dff6', 
	
	
	
	  66: b'51fe477e6126c347b62b22f218f77cc64660203', 
	
	
	     67: b'b0467a3b0d342b4419137f176f935105521ca1e',  
	 
	
	 
	
	68: b'56d23a973c6da5ac8537cf8d4fcd1c57aca8f24',     
	
	69: b'838f5dd7a4de914260440e7b54292e14e5b55ea',
	
	  
	70: b'bfff186ecb24f21cc432de59c5876bbca8a46b7',   
	
	71: b'dded672804d54889b885d3df648a31db0bfbd64',  
	
	
	  72: b'0874f0f80655bdff267ca6d40e8a890224634cc',
	
	
	 
	 73: b'a51c5586ff946154b407eb4e1b7c654106e1839',
	
	74: b'cc9402ad494fd1d69cb14f8db56ce12b4a3e1c4', 75: b'5f9290b53f4a61502e996137df2631c969ca6b4',
	 76: b'66313ad25cc5eb19db13e0774e58994f1f59aea', 
	 
	
	
	77: b'7597ea966cfce46158ad4e8501ec2b3e8b1b613', 
	 78: b'1f068102e8419ec7a278a5b8880213e1fc9f4dc',
	
	 
	
	
	79: b'd6812d981de26cc07d87fb08bfb03037319fe01', 
	 80: b'21d0bc2d186fae3aa72a6a6decc3f2ee97937a3',  
	   
	
	
	 81: b'9ccc7286df0100b7e7597f13eced26e30fec258', 
	 
	82: b'8a489177b57dfbffd0ee9924f25b8c53c244513', 
	
	  
	
	 
	83: b'8bab430483108dcc52a44db0299680792a6a589', 84: b'b3ee9290aa450cceeeba1dc442eca0b7f885350', 
	   
	
	 85: b'03368b640cbf6cb8c7df9f156e0483f3c9808fe',
	
	
	 
	
	  
	86: b'2e5d8dc7a42af6a6a78eb148a4d438c42c70fbe',   
	 87: b'b0da854d8bb82a7fbf7448f0695c8790f8579e0',
	
	 88: b'b7400d161fa3cc4b6a82d3e68ec3a22e222e15c',
	 89: b'a4300ea313d06b035501813cabd522263277510',90: b'3c8de6df9a3c5a9d6f8f7f27603bc87d36feabe', 
	 91: b'b84803df842fea4787bdec9c3c3071a07f77601',
	92: b'94f50aa8682c78f8e5ec3e60e59825ae772030b',   
	
	93: b'135fc44543e1a98c6efcedbb775ebb59a568daf', 
	
	
	 
	   94: b'4df8de5cedddbbb48f00d6347c93814d6c58e55',
	95: b'4ffadd2af00fefc2b1ec72ae67176b0de68e16b', 
	 
	 96: b'631f6704779f72be350666c7a102c9d71cc89e2', 97: b'9e01b29b5439e02dffdaa59a2620f01c3357cdb',
	
	
	
	  
	 
	 98: b'f8dfefa5e8fb80f88a4fdeffe8f3f8f6af744fb',
	   
	   99: b'563eec0c2d4d2ddb2a3b050e6ffef4fd1bce680',
	
	
	  
	 
	 
	b'bacefccbdffcefdbfabecabeaabccbfceffbcac': 80}