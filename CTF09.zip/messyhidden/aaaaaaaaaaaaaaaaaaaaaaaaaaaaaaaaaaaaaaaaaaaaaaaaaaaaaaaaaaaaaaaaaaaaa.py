class adbdbcddbefaaefebfffebbdfecccacddfcbefd:
	bfaeceaccfadeeabdfcabbdcfdbccdceeccbfbd={0: b'4e3259b2f37b492e58f772816ae8e01af3e9fde', 
	 
	 1: b'f07dcf99b87c1a89cba1d16c2323bf8cc49337e',      2: b'bf5170c76c1798011e3033a338387eda43652e4',  
	
	3: b'bc1ab087e68d012e80bea2fc4b53aa814326c57', 4: b'8e63f207fbfa5a63efee49f7e3aad73df38c22e',    
	
	 
	
	
	5: b'b66172774ae77240bcc6cfec3b8bf1a3f42b12a',6: b'0c84c52b8247286bb110aba479d015bd23f8cdf',
	 
	   
	7: b'79cddcfb421dd5f2f43ecfcd0a9cad1c453aa6a', 
	
	8: b'3e81d14ae7f16322ed7a68481b613bc5a6148db', 
	
	 
	9: b'7fa4919ff944c2549e2806e0162dda7fbd496a5',  
	10: b'c4aab99ad0fd240084fffa50285eec89275aa34',11: b'1e87e8c9628f211f03cf2c11808f4177dbae0ac',
	
	
	
	
	  
	 12: b'3debabab9163a1dc818a86e4ea3b0c7462d0188',  
	
	13: b'2abb90fd8589b4f8ff87af15d5d17c6a9e85cd1', 
	 
	 
	14: b'ccfcc1bb56991aaf966251379ac48f9f44dc9e0',
	15: b'1629874be64aba55cdb2d20af37d092a3dd9c12', 16: b'6bb8ca1afe182a0a8e0276ed1fbd22260c1ed9d', 
	 17: b'cf9875541612275762579dc552dacca77080858', 
	 
	 
	18: b'68180caf3d428b7fa7f49be8067fafe518d4d33',
	
	  
	
	 
	19: b'5f5567c2541e877fe3fe80bc4f388fd6253608c',20: b'de50bd5e2b4ce254f28c25fc9b17ca9110e9215',   
	
	
	 
	
	 21: b'4bf5a77cf56b248283ae9cde30193004f8f0b01',
	
	      
	 22: b'c7f71a242a16459c5783aff7872a8540f7849c5', 
	 
	 23: b'51f98a595e5d1ffd66dd4b85ff6c7b65690ddfb',
	
	24: b'598f9f32eb54af4e70de63df63da32cc951fb79',
	  25: b'e9d3a6a296ea98e1b7ba002545b10663dca37c4', 26: b'7fd7423babbceee71b7c3bc11468e04caff0b0d',   27: b'b68b710c70c59bdac626e445c0e05ede1390446',
	    
	
	 28: b'a7103582f3a8c9546a6921460c31295d2290e0b',
	 
	
	 
	
	 29: b'c862bcd8f17ff85d9c355154b24b717e67369b4', 30: b'f7f58a1ffff527b82c4d1b484031df3aaf94496',
	31: b'e4c3a227d06ba7c008bbb9b83a0b1a9ca9c155f', 
	
	
	
	 
	
	32: b'bc6c687424e4b058e9977e1f57041c519fbb6e5', 
	   
	
	 33: b'd5eef674a45e22dd7a1925d23d2b2d765345b7b',
	34: b'c4a68794329f9af7c79a2d1830dd1aa0586050d',    
	
	
	
	
	35: b'6d22b1a2e5c256b6a8a0eae91c0ca3edbcf22bf', 36: b'9967a9d8c62e17bef157b5e6ead2ee4b7cf3b7e',   
	
	
	
	
	37: b'ef96f2973227246d88525ebbc436eaf54d57a42',
	    38: b'736b88a39a08822d1edc6054384b986208e58f6', 
	 
	 
	
	  39: b'ab165fff266ff7d5adc2e74d84a2f12a5d8ad43',
	  
	40: b'298f6aff50d2bfad391b91d1926d7e7d2639260',  
	41: b'1ae65ed7c75bffcf72f5b1ea628b79b0ada95c8',
	
	
	 
	42: b'a4f676e4a31106cabea3806160dbf8d615e979e',
	
	
	 43: b'b44bfd5e8ef71b367eb0ad14558c557632894cc',
	  44: b'0a6909a21841ab433fe70e2c78e56dbdd686bdd',
	45: b'efdcf58425d21b592ffd2d97100bfc9bf525118',
	 
	      
	46: b'667d07168d24cfd790baa9919bf850bc26098fc',
	47: b'98b52c5373a3b3bcc0e24521dc16e8f80642a00',
	 48: b'ae41c993502fe1ec06ccadc31936ec1c5e0e82a',49: b'fff0c63c493913f1bacdd42226deae580fb0dc8', 
	 50: b'008a85f0a69c54e2a975b3d1869026e159e30d8',
	
	  
	  51: b'553fd70c39f62e3a23148fc951e41ec34862e0a',  
	
	 
	 52: b'42b3fd3e73c871767b8ffa970a79dc5ca8dd952',
	53: b'e5062d7c249b36dcee6c12b9455f851b2449f54',
	54: b'84bb7197778490593f1c1e20d8528804beaef74', 
	    55: b'79a3c28d579f8a0f60d43e1cc9ed9225b306f6d',
	
	
	
	    
	56: b'31eeb7208240839aee08a70bd764aefc4ca2e6d', 
	 
	
	
	 57: b'c66c5f55de22c752af86805c7e5d24fc89228cf',58: b'e3f46f69252d031a9d4637a09b8da2712595e17',
	  
	  
	 59: b'fb2652f1abf905042740ef95877f16587c2c993',  
	
	
	   60: b'7b72af533810839dd4be80145718a9dff38ca65',
	    
	  
	61: b'4fd8128be25756fabaa628d91171aa75e87d73b',62: b'4acbd8b0d62986ebf9636ec7595296e97aec9b2', 63: b'db4d3a8f38194b2ad3ee19c3ee41877f5ab9f37',
	
	  64: b'1e4b5faef7d6b433bff4db8888e9f1eb767fac2',
	
	 
	   65: b'df89aaf21f5aa843eba5a55221205f79632960d',
	
	 
	
	
	
	 
	
	66: b'70966433c659278ee71132e7351c874b58d370f', 
	
	 
	67: b'e37beb6c4618aff19cdf93dc69c5eed9aa19f96',
	
	
	 
	 
	  68: b'597b6e18f865dc073ede6ff678faa4e1adfa8ac',
	  
	
	69: b'6b58c902e9e95aa1046a65900896d993f0e4901',
	
	
	
	
	 70: b'103f0de01a76e8281088e7c96153c37aae9e041',71: b'69690ebb6d2fd1eaf909bf7f0fc143578df2128',  
	
	  
	72: b'c4067a17098dd38b7fce1aebfde872003f6068d',  
	 
	
	 73: b'3a964c70d26a225c00dc2bcd6402fdaee699b8f', 74: b'd59adf71d35a34dc2a306c7ce986bbf3343d8b6',  
	   
	75: b'b522f64ae5c368ff43563adfb20a75a4389d7fe',
	     76: b'218d87cc9bfd3e0ba7feb41d8512210d73b3aa2',77: b'a566c905491b2a177eb1b3e99c72f0c59e89df8',78: b'3c987fde6ece6f29090ed71795ab3c3da7b856e', 
	
	
	   79: b'9d117a5c165b983e5d9e039140c5f92eaeb2005',
	80: b'320a352c7b3b634cc35ddb97184766970de2f32',  
	  
	 
	81: b'2e2737638d64c5487d1cdd9112d752d371bddb8', 
	  
	
	82: b'e961f5360a0c22ad447c474221ba13954fae521',
	 
	83: b'08e45430cf2174538bd2b95a8b3356b4adb0c39',  84: b'8bc3ba54a10a4e9a65df89603f68f1b70676807',
	
	 
	
	  85: b'3c6d8cc61f85058575f9f224f686c0b6b8db4ac',86: b'57ad02342b7b4bf4c978b2ecbf42bb35b98f2be',
	
	 87: b'ff0246fb7a05c1b62b80cc41cb92654c194d8eb',88: b'c91e0455d1f7f271661603617376e3a3944f9e4',
	  
	
	
	89: b'd6a92eb1d1dc2c4138d191cc4cdca60ce8435f9',  
	90: b'cca220c1a00382fc23dc772880ec66684cfafa7',
	   
	
	 
	 91: b'619e5544f327c62148f71ca542c85cd8de8fdf1', 
	
	
	    92: b'487d8aea3fdb90c1369bfeb6222b67b1aa2ae1e',   
	 
	
	
	 93: b'9c5945a0f26aaa98112cdc9a9ac027ff5b53c8d',
	 
	
	
	 
	
	
	94: b'348bab625780c40b30f5548c1564f9ccc7f5ea8', 
	
	 
	
	 
	95: b'c7f5d2b8fea6813bf3d4eccbcd36dbe5167055c', 
	
	
	
	96: b'9562d1c04f79cd39051262085cc008dbacc31aa',
	97: b'73d4dbbd3b06151d0ef96c08536df9c611cd796',
	
	  
	98: b'c8ce32a0b12db200494e519d5bec90d78155ea1', 
	99: b'0f1254f3697a90d38dbe4912c64fd4883170642',
	b'fadeceafafcfcbadbdcaaefcabbdfdcedbabeae': 1}