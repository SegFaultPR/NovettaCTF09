class eaefdfacacdaeafccffccebeabcfaffabaefcad:
	adeecedcfbbffeadadffacffaeddcdfbbdebfdc={0: b'7cb3bb863b01b44358d7a27cd95188f48fe5133',
	
	
	 1: b'21c2658ece83560a414d3be17f1800d96cb128a',
	 
	
	  
	
	 
	2: b'cf59ca7320f308f639ffaa6aba46c52b23eec7b',
	
	
	   
	  3: b'ee8ef97fbbfbf855635dc481d15cc03011c56ae',
	
	
	 4: b'6c38537166919e5e7055d5d182a6a79e7f8352e', 
	
	5: b'26ceb49ad9902642d4b918208ae5bb794bbce1e',
	
	
	 
	
	
	
	 
	6: b'ede4af4967c565691e4df6c2772c4dd083fb31c',
	   
	 
	 
	 7: b'b138b908c1b269edf5b96e4b44352f270103aa7',
	 
	    
	 8: b'9a826e465599c49fdb692b796aaf66612679d08',
	  
	  
	9: b'086bcdb21dfb24b604edbe44f712ab6c73b7f1d',  
	
	10: b'94a45f4ae4cd73e11cbf17a83bac27a52681cda',
	
	  
	 
	11: b'0317a0c7022bdcd0f8d8f5191cbf0e96fb10a66',
	12: b'9b5fb83d566b04d44c5ae71c4771417c2642ebe',
	    
	
	
	 13: b'53d455455c9a572e4101ec6d0b0c1e67df6be7d',
	
	
	 14: b'57eb51d77e7f91c7eab8dde1c87b6478ee26061',
	   
	
	  15: b'ad8438163f0e0edfc7f4b5c79e48ee9e5a0b911',  16: b'26f9fbdadd17780d0a425f33ba0085baed42ed3', 17: b'7a2762053b4a2c98b0436ee72ec0693295ae1c7',
	    
	18: b'5e81798b71582727ab5b3434043674da712e377',
	 19: b'111f2804de80c1c33900938a5fd854a3c9e5df9',20: b'6eb938770833b430fabaddec753d2ae7f0faaf5', 
	
	21: b'd7a11c164dc6d8d4280788919a54913b78d5c70',
	
	
	
	
	
	
	 
	 22: b'4c66431d1dd285332e242386af757f75373423a',23: b'8f830708bd5853bcf7b0b326dc06ea452de12df',
	
	24: b'dd38b5af3d68b4eb42c6daf4660caccbaec560a',
	 25: b'20308fed7987817b4cd034caa9efeacde1508d1',
	
	 
	26: b'eb22298dca48a64423fbfe2c0788479cbce09b4',
	
	
	
	
	 
	27: b'abb1fa552b5be426f3fbd2fd9beb0c1387b5bbc',
	
	
	 
	28: b'd42cffa1e0624659ddddbbd2f4a168292e27c26',
	
	 
	 29: b'26641b468967216c0acffd522b7f898272a7502',
	 
	
	  
	30: b'385ff9b49ab940e8e5983975240c7faf7264a74',   
	
	 
	31: b'e835d0cb6d115a76e1dfb4eddc41c65f53bc48b',
	   32: b'77f619792e99479061df3e1b466ce1ae210c5fe',  
	
	    33: b'e7ecf4cdb42ea14e3f710f28f9c23c797c5e48d',     
	 34: b'49f086988936757c04ffef7e9434cb66cd2f402',
	 
	35: b'367c97dade04b9643b14175858f9c03faf166e1',  
	
	  36: b'7b217c885c39d432530ada01b149b4096925999',
	    
	37: b'46027f6358330f50c7845f9138b10ecb4690e74',
	38: b'fdbd107e36a8c53e1b269feb8b725b3ade3cea6',39: b'bda7872fc21257990c02ffb22964571eb681f83',    
	
	  40: b'5de155c6bc12d59c590857287666d757f58c404',     
	
	  
	41: b'cf3313410e5038ec5cee37b85ecd32b110c8e27',
	
	42: b'e360c2ad1b60ffa10a18b2368c211326206e96d',43: b'e0db97f0a2af915e304289b8961b8f51e0c72b8',      
	  44: b'4840d1f75cffb96fb2f7be1c98a086418499e08',
	
	
	     
	 45: b'0ef629275b926930e1c0a0082a801e0d972fd76', 
	
	
	  46: b'6bec7076f0bb9af6adc4d798034ae430ee2bdef',
	  
	
	 
	
	
	47: b'4e9f190be4bfc2f09f1388cb40b1aadda3274fa',
	   
	 48: b'a1aa17a21a7748a9817f541ea8bf10f1a076bda',  
	49: b'fb845c98de0e4430e834d0ab4fcf1c8ba0bc251', 
	
	 
	 
	
	
	
	50: b'b95cabd9f58a478a8697807f00117fb11b3c7af',
	
	51: b'5f295412c4ea57848caf0213cb4c0763662040b', 
	52: b'f82abdb1f229c1d60256b90043baf1f885c3e3e',
	
	53: b'b8ce5a5da33298d8916ae845bf0bf0d404e79d7',
	
	
	
	
	
	    54: b'4c69a609a7ede80deb5eb6ab5a91e9312ebaa3d',  
	
	 
	   55: b'925aedceb4d7b4bc60fd5fc3bcb9873d70de2f0',
	 
	 56: b'05cfecb8f53b0d5580358f12f3ea14c6786e4d9',  
	
	  57: b'33d9bec2270917a305f0e59e215e3f435bd4a7b',
	
	
	
	
	  58: b'4d9f5799bc5a11a830c2a23cc864ae22cfd85f2',
	
	 
	 59: b'a8ede680ad497e1391ba935ec38fcb7bae40b71',
	  
	  
	
	60: b'c5c6fb0d56c4bfb0e4b5a2163ea1fce2bd11e99', 61: b'c380b52f233e132b91adf35878ab6b5760647de', 
	
	  
	 
	 62: b'ec87a250ff24719490140c3d75db6f34df19cdf',
	63: b'f699ca526e10f7f06219b5b84fc2dce8694d23e',
	 64: b'8e9c1708cf580d9b81f57aca1e1d8a081f7ff56',
	
	 
	
	65: b'e55c7e66b1f962c597c5b79d7470931545f9cdd', 
	
	
	 
	
	66: b'b40a3fa70a552d866a83d7d9bab1d5a3e3ef694',    
	
	 
	67: b'b61bc10cb7922add9ed8e1601b9c9606f916644',
	
	   
	68: b'b0ee3cb0f51359f24df1853fc92e1051d38c97c',69: b'9660d5b53c2708c1daf00f75348684c121bbc85',70: b'5afabe86a4a431fb8469b30cd697b99bc0e2850',
	   
	71: b'7697dba363a65ea2815579b20bfe25be56d4b72', 72: b'f3df518fc4ff687c39dd1595ac470655357b0ef',
	
	   
	
	 73: b'5aa7ea6a18c32c1c4cb8119d9bbe262f4fb52cf',  
	  74: b'2f87b971c2b95db085ef804d12438486366a455', 
	
	
	
	 
	75: b'2d4635ef008a8af479c61def6dd8f81920dc163',
	
	
	
	 76: b'913ad42b28f91eb67eaca0b1d18df529e337cc2', 
	
	
	      77: b'd0442b30d5cec068d7bab56724d7f183c772307',
	  
	 
	78: b'2c44eb919bde1eb75327f6dbc662564e8159d71',79: b'b7aef280b921b59ee402587a06c917488ead47e',
	 
	      80: b'6657de5eb83c1262bc150f750b8457fcc033eb7', 
	
	
	
	 
	
	81: b'3e594b790667d48e4ac2d832996a3c05844f705',
	 
	  
	82: b'5044fae29c3b5cc95e2876ded39a23ccda784a9', 
	
	   
	83: b'4f70f3db702b97753851d419db982065e4c30a6', 
	
	 
	84: b'e1eed9a85b7f28c783a08093704d9ad66fb5b79',  85: b'c4bf038e71c28c53cab71938f08225b5dd14bed',
	  
	 86: b'54fdccc118af53c4a2f8d2107e73c97f1a4220b', 
	
	
	 87: b'fc77ac0462bd2362616b0111a6054e35b8c41bd',
	     88: b'17ae78d07876fa8867618b540e53feceaf79dee',89: b'ddbe9ad9484bf42dcd6d41497d20d16bef2131f',  
	90: b'4814c7dc71c596b285cb83b7f37c4703c6a79dd', 
	
	 
	
	91: b'06f2f8a1fc6b161254a90bc9de3b4a88fe71753', 
	 92: b'3d01bbeb6d88df1326ede76071cbfed277aa7f8',
	    
	  
	 93: b'b265eaac3b760e6f178032301a52d654dd27e59', 
	
	  
	
	
	 94: b'4378a71af923ef31b541940de8fd0694e8aaa72',95: b'e75edb384a7be58ff03c245250bce3388b2f1e8',   
	
	     96: b'b6149348f8a000aba7be69c0bcf7ef3e56592f5',
	
	
	97: b'87fd0bc5a91625c4aed37836cb3cc8384998efc',
	  
	
	98: b'8bae0dcf9a40dc33eadd0a8be971fb0801055ce', 99: b'105a1a762b87a41d8a1ac18b7f467392dd0dfeb',
	
	
	
	 b'cbbbdbefdbeffeedcdcbbdcafabfafdcdcfdaca': 4}