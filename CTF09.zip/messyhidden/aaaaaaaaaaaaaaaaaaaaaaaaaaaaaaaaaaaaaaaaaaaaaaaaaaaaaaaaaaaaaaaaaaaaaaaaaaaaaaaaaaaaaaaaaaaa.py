class afacdcfcfccdccaaddedbecafbeadbcfdcdbfea:
	deadecacfdfaebdeebcafcfedcfddefeacbdfff={0: b'd3c351e3894125cfba26c4f28bd159e1bbb904d',    
	
	
	 1: b'fec5903b14834b843d9e8d316eba39a06543499',
	     
	
	
	2: b'e10d92d9b2af442041dc6db98813e889b4f5707',
	 
	3: b'1e52d9ba54335b69890c15e9b5327134d38e3e2',
	
	
	
	
	
	
	
	
	 4: b'6eecdfac8c7bfdb7e92ebf7b4952cda7f85f181',
	   
	 
	
	
	 5: b'31e5362d9a7c4de68a043ee3cb82d48dce6ba10',   6: b'37e572cce9a3d6423586f5894ecd1d8b7e9bc2d', 
	
	 
	
	
	
	7: b'1741172cc7807578bd2e26be56b93e7575a16ba',   
	 8: b'a2b17e89b720f6341ee5658651b385362f6a889',
	 
	
	
	   9: b'3c82f1d314bb02fd9ce6d4e4427c9548c80dc45', 
	
	 10: b'8118376a8259a27c358f46345eaa9fe1ff74bcc',11: b'5dee77a959a81867c06b20d3bf452bf3b3ec19c',
	
	
	
	  12: b'9abe19e7509d4a249963c846c0de28103c801f3', 
	 
	
	
	13: b'0a5d7e3a2c0e2ccc9b6c9654f89c4e8ec72c9b3', 
	 
	  14: b'0c6336e51ebf6bc2a397a195987194c194a1ff0',
	
	   15: b'3604852451ccdddfabeee51327a325e8dea89d0',
	   16: b'4574410c8036ee318e35b7b39ff3e435ba26d19',
	 
	  
	
	 17: b'20c99fbb2a3843e987736aa753ec0501452f3e3',
	  18: b'a45723ef399e2a968d60b90cb4ac918713292e9',  
	
	19: b'5ee571ba7f8a89dd2d4b919f5852b05ce46f3b1',
	  20: b'efaad4f62f532cf3489d8f19547b5f9ee5aafad',
	 
	21: b'aae49aa793cfe14e18f094ca39f4e7469972871', 
	
	 
	  
	22: b'0299137cba657ee6c59be563ecb5bd09129b870', 
	 
	  
	
	23: b'16699c02c42486f8b8a06014d36cc9bc6299cce',
	24: b'a0fb358cf09a61f8b20eb40ac8c8106c6a0a013', 
	
	 
	
	 25: b'b8909f3a7bcaa1e7d534bbff647bf6f509d7c61', 
	
	
	
	  
	
	26: b'397b219f2f36ce29cf0346bdf7cb1249de93c4a',
	
	 
	  
	  27: b'2b6f286e9417c129ca8e4d7837ea1385c809fd0',
	
	
	 
	 
	28: b'a78a69c460a894398e927fe38315d8039c3b418',
	  
	   
	 29: b'206c0bf57d22079d1aed07ff2e7ccc6b8ddf806',  30: b'331494709b31f4b06db593ff6ac81bd3ccc1078', 
	 
	
	
	  31: b'79e8fe6da49bd13e72ce05f1cb1d46eeb695bd2',   
	 
	
	32: b'c4165a09d37c3e020c8187af907756ea1c361f6', 
	
	
	  33: b'f636a17f1466a49b0b40ea168cc671270bb3ee6',
	 
	 34: b'19a6e86337bf755d992cd78dc7fb61e0f058e1b',
	 
	
	
	   
	 35: b'a6fedcc3bf127a6547ea449626cc59a589d10a2',  
	 
	   
	
	36: b'740049f6f2ac8394169e659bf66facb4581e703',37: b'c3ddf27dd248c3e721a3088b1d54b6685d5fb5c', 
	
	 
	
	38: b'ac4f9c547193b161b26dc91474690606f96f775',
	   
	39: b'160f8175daf7fa3bdf237edb3017496dbf71c2e',40: b'4ab656ff72e1f50f08c7b5e4b02452f0d04aa67', 
	41: b'6b24e1ba04ef9bfd1e94bcecdc76c2c8c7ce9cb',42: b'222def24b55392bb6350d448b3d3871cbfc52ab',    
	
	 
	
	
	43: b'b60999742521f4c89f94cc5407b35b65b88a428',
	
	
	
	
	 
	
	
	44: b'189aa9c237a7a6f4197b663864da5d7361748e3',      
	 
	45: b'c01a824a27111512e5ab8f77a9c342ba5c6a3cf',
	 
	
	 
	  46: b'aae3f53a3bc4a99af40ed7d06a3f8f3b7252572',
	
	
	47: b'670100c784a6bbfe6b87c9b84017502fdbc30c0', 
	
	
	
	
	
	 48: b'03274285b16329dcaed3176f3776c890e943430', 
	 
	  49: b'ecc135e47a22b699e6c42fab89b78369f4934c5',
	
	 
	50: b'37db3be142a567dbeb12b56d566be5e2f277f90', 
	51: b'4877c22a6543d50cdafbbeeaacedeac70992e9b',52: b'4b3515fb497d32e75a1ca10f2218a90f64c8fea', 
	 
	
	53: b'b4c189a8732f8af3f325b6b9b3afd3dd3b5f947',
	
	 
	54: b'0f81ce154d060b1adc0d3e89976cc57a4f184ee',  
	
	55: b'0082da3d71a0607741119166119a6eb23c1c1f2',
	
	 
	
	 56: b'a29d78090230126ff899f95bb01e8c3401c0cbb',
	 
	 
	
	 57: b'57beb73fcf708d13ad0a5a8e12edaed2ce69b29',
	
	 58: b'2bea36a8bd77430fbf1d3b1420c3a45257e9150',
	 
	
	
	
	  
	 59: b'3f869ac8a80c9b40c24ba02a9edd7cb58d99f64',
	60: b'ab83a0220f37e2ae0ef4a0274c60367d8a1a407',      
	
	 61: b'fd85ebe09bfb95fc608e7acfe185478d23c5683',
	   62: b'7a1920f2c6c7aab4fbfca5822672eefb06298ae',
	
	
	
	
	63: b'fdfcdbab955ff7dbffb8e45d1f7a495f5c6635a', 
	 
	 
	 
	
	
	64: b'28963d8b3c9f7c6c03480612b43879a7a9eea7a',
	
	  65: b'ecf3af5e330f661eb9534c0469ee1f64811d0f1',66: b'2a15874de4694af343b060fbb1a71560c3b4156',
	67: b'adc216e0ded0df8c0fc19552d3f38566c856225',   68: b'dd78c8e0eee8d488ed7883d3553d615e079a8e9',   
	
	
	
	
	  69: b'1d65bb0c537b2f012e315511210d72f8abbc6c6', 
	 70: b'59290c9fbded92934a1602d1dcfcd6653b588e2',
	
	
	   
	 
	71: b'4e36630a6b1aa977a40b526c842a34c00f6f126',
	
	   72: b'68f82845b9b360c5d30950b6989535473a28dc6',    
	    73: b'680f2108c8e0b78cf7dffaaaf4a8ddd396e1e09',   
	
	 74: b'dfe73b1f3569730b192c25b794f54bca76dbe62',
	 
	 
	
	
	75: b'2d2f07b0ae2ac9bbf7ed5afdb3c3f5c6ab0fb61',
	
	76: b'2494b653f86dd27be4d6e2ae940e469ea342672',
	  
	
	
	  77: b'3a4ef21cc86100d4f86d881913c14e17ac69325',
	
	
	
	    78: b'5cf482f11f8cb39bb0fcfab194b4f9e91002c3f',   79: b'34b191842a934b2747263b010582fcc251107fd',
	
	
	 
	
	 80: b'79bc3071eb0e9946275754113d2462566205dc2', 81: b'cabc6fc3921e1d3f8baf931cab0556ea3309fc1',
	
	  
	  
	
	
	82: b'13c954815372798a88b5252ce356d26ba40355b',
	
	83: b'6e78c9a3cbfee536d581b36615ef6e2c4848985',
	   
	 84: b'65be55bd442e94e20704736346efcfbac5de662',
	  85: b'44cb00f5976593ddf1f19d18c5faf9dcc9f3203',   86: b'6760e52cc054108b888376890fe65384575d3d4',    87: b'a4a9b2c3cd80dc494a6491b7315de0b4222e2f2',  
	 88: b'd37e8242c27b5b2e5e22e8a4e20549b83f27306', 
	 89: b'e58db43d3e0023a6ffb35bab8c3c9d42100961e', 
	 
	90: b'90d6ed53e839a91a52c2c40e43a05b48a0a4c76', 
	
	 91: b'7815c430dd12f48e3960ab3558d0c50256def21',
	
	   
	
	 92: b'a55798ed563d5e04fbb01d16658a7197151fe1c',
	 93: b'b192fb8adafec3f664b6053fb5ddef06652f292',
	 
	  
	
	94: b'4f915892c18aae86cdb02fea5ac1e2cb605e2c0',
	        95: b'70d8ddbe491097805d463ec2e916981fc8f6eaf',
	
	 96: b'c6378e29d3a67088ac1b8308fa2793a35a9055b',   
	
	
	
	97: b'5ad397cd8a0a865d70ec7ca6262c82e9672a6d7',
	  
	 
	
	98: b'b74a6e1eccbb749345080cbb6fc4ac6fd9dd10d',
	
	
	
	99: b'eb08e7630a141147b088c43a058b38a1d4112ab',
	  
	
	
	b'bdaaddcefacaabedadecbdadddbaddedabbdeed': 25}