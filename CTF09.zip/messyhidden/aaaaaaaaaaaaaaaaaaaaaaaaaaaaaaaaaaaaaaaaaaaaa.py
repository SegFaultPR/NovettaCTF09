class ffdeeefedaaaffdbfebbbbcdedefafcadeebcaf:
	cedfcbaeefefdbabeceadadcecaefbacaaeafea={0: b'40cdd72f07ef1792311db7510dcdc66dd992562', 1: b'8ab3e16d021880a7e4e0150a180924d29b08bc7',     
	
	 2: b'41317c45d3e4e5a0cda67b3dcf1e354eb704a89', 3: b'8f0c21a2801f64a07e10864e29da5297c12fb51',4: b'196630b6de363a359ea946bd81f3453970d0765',
	
	 
	
	
	
	5: b'b26390cfbce7cdd188cce6fcd95496305077b69', 
	
	
	     
	6: b'abf1601ab3e6c08e94a42378f88e2d7b5a45587',  
	
	
	
	
	
	 7: b'e188fc95019a005d4ce12d62dcc0b5b73ce3184', 8: b'95f00ba116a2bcc0b13d60eb79c1c38766526e9',9: b'817ef2f95d4197925452566b9088569e1ad579d',  
	 
	
	10: b'52a373e90438f7fbc0651f8ba204227f0815c6b',11: b'f18a1e89415897371705c347cbe31c58749d75b', 12: b'eca476ad1341556fb9a22573241a62544ee3837',   
	    13: b'4031c433ab80265ab224ce735326bee7866aa1c',
	  
	
	 
	14: b'891ed69072cb3512e7c4e927ee66fd05da1ddd9',
	
	    
	
	15: b'1271967e6bbd4dcc0e46b6c9a5551bbf77a2487',  
	
	
	
	  
	16: b'656c0893f167765e272217d33de475743f039b2',  
	
	
	
	 17: b'46a24dc83ee3345cd99cfeca7a12188e944ba2b', 18: b'75afcf854a6956e52e87ca75b0d182f6b1f35e3',
	 
	 
	
	 
	
	
	19: b'dcad18fab9412012c802be2688702182487a407',
	
	 
	  
	 
	20: b'ceb8c4d1d422a62e811ad5b5fcf4e36d6e3bc1d',21: b'0760a484d9fbbfb24ac6524a967983511da6140',
	   
	
	
	  22: b'c7ebf6334be43d0c26f7bcd367407b4c92eb371',
	
	23: b'697da3d54b2ed7308a066730a54c651dfc351d8',
	
	 24: b'4fe57cf011ec197acca745ae5f62b38b76b6b28', 
	
	
	
	25: b'fc2fae7a87e2113f3ecc84b255d8ad9ae1bba93',  
	    26: b'6483098ce7b3c29f3ec8bbd0ed81db18c3d972b',
	 
	
	
	 
	
	27: b'0f7325de147c521daa5cd041c2d7f6a127f578a',
	 
	
	28: b'22a4db4d496f49c0872e2fb6b86eae707f635c4', 
	29: b'00eacae356d0f7c842b049a966f70fb53705f89', 
	 
	  
	30: b'90a902b86a8af47cca907653a28f9aec4de21eb',
	 
	
	 31: b'1fec7c8763e5c21dd3526d769f69b7feee13993', 32: b'da10116f5dd37706bf51bf09b32b8450e563c81', 
	
	 
	33: b'7bb6ac001d9761e95601def7adeb0f808bd4555',
	  
	 
	 34: b'8d7537c400ebfa0706a1f1b4cb104b26d87c0a9', 35: b'73b7ae9008b58fcccf0a53bd84eb6a3684de5d9',
	   36: b'f1b9e2dc95ecbc3340db0ed46370ac9e60fd693',
	
	
	 
	
	   37: b'5f6ba0d6d27fc7a29303d58351eff083f0e2918', 
	 
	38: b'c7fe10ec7077bc1c65db0c361555fada6026691',
	 
	 
	 
	 
	
	39: b'2f8266ee02cb3305800a8d9aa582c44706c51a8',
	
	
	40: b'e13d1143cbe1bb4de258e0c2b40c9551d895c6c', 
	  
	 
	 41: b'cf18b65c45238cbcf2c80175c41a7f10dee303d',
	
	 
	  
	42: b'a5ec6d940e934e86af630658ea10c9bf8d72f04',  
	  
	43: b'58859f3ff571b779b9870fec57c695f993859be',44: b'7beb67fe952eb232540c8130e511c74f10e389d', 
	
	
	 
	
	45: b'033743e0b5e4f1d4a0a4580b87fc9f2a14fdbd7',46: b'f77ccb11a70489805de4700e9c3141d0d4a83b1', 47: b'49ae04734899c1e7fc5d2e83f6a0bc8013eded1', 
	
	 
	48: b'88e3d8a047ebbb94c45f7f78e7660d8f9654646',    
	
	  
	49: b'8d7ec9d429579e1a78b0ed7b7ffe9c6e7c75593', 50: b'0088aa0c8dbe074c3573a430ed0ed08fcf983c0',
	 51: b'80957bfaca485bdd6f9c97a1d567596599e5820', 
	 
	
	
	 52: b'8dbb0c746967134ec4290cd0a5bc77f5ee78698',53: b'62ce65c97152d9f4d59b2c0eae474a5db5571ba',
	54: b'7ad83fcadfe203da1efbfc0a48445b86d331e7c',
	
	
	  
	
	 
	55: b'b15a9ec70e72616153efa00bb236e8f49c7593d',
	
	 
	56: b'67dd6f4a87cfaf0a75e9ef2fc1f0ebbcfa6bbb4', 
	
	  
	
	
	 57: b'93cf2a915adf9e966c021bf4d4895fd1cf12a7f',   
	    
	58: b'a05d973cc5463a8d6cf4738f051ae5706c233b5',
	
	
	  59: b'440f1994726b0ec8c473f6ebbfcf1aa7b039915',
	 60: b'74a0a38db3c65aa40ea973d5a6b678277dc9fd3',  
	
	
	  
	
	61: b'395150cee453c767678098f357ef2fce35ee51b',  
	 
	  
	
	62: b'd70984e2339aa80b1618c4e45c85669d642f124',
	 
	
	
	 63: b'0521c5e35f3c6ccd92d1dc4b770a388f363ca7c', 
	 
	 
	
	
	 64: b'dfb519ebf6082b5cea360b62c0322be9e45bfee',  65: b'c9294aaadf226e15c1ba9e42df910da674c60b0',66: b'71ababdaa541df842b0a520390e7b357ab3c011',
	 
	 67: b'176b28e008a80a185971aaa772b8a0f2518b1d9',
	
	68: b'61738fc6a4f846c1784d037386d5d2f83817027', 
	    
	69: b'daeeb1ed7c50b65032425413620f52b668fee92', 70: b'c0347dc708d5aa36f0d3516435545a078af26ff',
	
	
	
	
	
	
	71: b'ec808eafb24b786656382736ce6755dc04aee49',  
	72: b'378f4fdc0411033f22eb18460dcd4ba7eb0a31c',
	73: b'f1428efe1660927dd164cca9183fe7f187d190f',
	
	  
	 
	
	 74: b'5a112adffbbadba1563d97f95c792cf940fe7a4', 
	 
	 
	75: b'a563cb1acc2c2855f86e5e5c98fa6c8296521c6',
	
	 
	
	
	76: b'4bbc4dde4aae921d5fe9c704498f41f09ccb8db', 
	 
	  
	
	 77: b'b3850b5efb657b426f3bb48722157ed36fbb1a8',
	   78: b'57b2de7983ceafc21cb7012aef4874063adc49c',
	  
	  
	
	  79: b'a09755f72570ba385be11093db28fb538761ac5', 
	
	  80: b'1ff4689ca9aa67e0c631a5cfb2366a2b33330f0',
	
	
	  
	  
	81: b'a8ff138448d42c7c4f0f6a1dafa18c569e75627',   
	 82: b'a8b131a431ddc36a8b72b1102ce7a93bfce7bdb',
	 
	  83: b'c8621c5cdd7a98d9f87dd32c1859ceacb0d67fe', 84: b'c69bf509708aece9244e94fb72039488dc78db0',
	85: b'e2c52a80b484863678b4c9b6ce9e76b17afe37b',
	 
	
	 
	 86: b'809cac6eceb2aeab35ea62389dc03061108dcdf', 
	87: b'db47ba3e6f865fea7a04a9f5a9ca0f6cb0327e8',  
	
	  
	 
	88: b'42c5d64bccc1e0853d0c22f8fdf9196370a8594',  
	 89: b'ecdfa7e62fff3246bca90bc0a67501c1fc90854', 
	 90: b'2bb5aa6eebe5d67858d8ddd1324d43a7575ba7c',
	 
	
	91: b'2b6adc01b6d331b8a165af1d61585cb30ebcd52',
	
	  92: b'f0dfb72f7f4648e5780a212b93e921955ce925e',
	
	93: b'b4499c4f68225c2091ff557f435c230762f87af',
	94: b'69894e7d95759308c2e9124a5654d05f4c1a91a', 
	
	
	  
	
	95: b'209535e1fbd1cafefbb6441b995f1735812b5ba', 96: b'648ac1595852761beff3515130c25ba0460557c',
	
	
	97: b'598d583186e9e7ddbbfa7cc752f52052d975ff1', 
	   
	98: b'837fda21c66fa0456416cd96de88bcc7a89f8da',  
	 
	 
	 
	 99: b'44850e0d19eb7372c315ad7c112b3abe86d4bb9', 
	b'ecdecfdfbcdbfcabfbedccddefddccfdcaaeddc': 71}