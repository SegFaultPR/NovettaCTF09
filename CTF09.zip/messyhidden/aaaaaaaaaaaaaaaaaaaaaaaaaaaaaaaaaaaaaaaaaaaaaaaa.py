class daeeeafbffaadbdfabbdebdafcccecedabeadee:
	fffbfbdfdbcddefdfbbccbbbeeefabeecbedaea={0: b'93f0502c60418e3a517da26f617e3668b728a6b',1: b'8c31852fc5e4fbd7ba34abf3ff83c3c587dd7dd',
	
	 
	
	 
	   2: b'9328489881ec7a2a766b37fb8f4458a9afaaa72',
	
	3: b'49cc8d2bd08e06800d2da7188ec83c255b85ef5', 
	4: b'd5002f3d17443818a4001d779e2df1734eac175',
	
	
	
	 
	
	 5: b'02232f44b5dd02f7224471952d6a4bc3abe8c6a',
	  
	 
	
	 6: b'38bf3613e7576ee23494382b647adfb7edeb72a',
	 
	
	
	
	
	7: b'f75286d9165242615937220815a9e6c1c0f8a6a', 
	
	   
	
	 
	8: b'57d1c861a08762a6c62b6ab353b16f40e5012f6',  
	  9: b'213234d80235e1b2bb45a72a848b4d4cde6f8a7', 
	   
	10: b'02c78afb4f7be51a00df3478b66fca4f37d6c12',  11: b'3674827581e2b22790d0f3c0c7a7d23ce16754a',
	
	 
	  12: b'0123fb7677bb418e71d995533dbdf3073ce1a69',
	 
	13: b'175a5323e22337995d9e64d5940cd54754c5a0e',
	
	 
	   14: b'42249d71adec35dcfa4dbffbaa2c85cecc6aeef',    
	15: b'4bbd655492f2d8d94fe07268592a6d83e055d32',
	 
	
	  
	16: b'8cb14846bde855df4c6f6eb5cdf7cb4feede1e4',
	17: b'f7d81bdbc6a60a97e1d332e7a67f1721a751eb6',
	  18: b'34d6647ddde7686b1eb304e5c4e91cb528a3be3',
	
	 
	 
	
	19: b'd3f6326c67a8632b2c79504ee12574b54e677e0',
	 
	 
	  
	20: b'6882c51fec89591dc780073fd56bc7f0f19c928', 
	
	 
	 
	21: b'3605b6f0e60f6144447bfc09ca757f69ca4bb02', 
	
	 
	22: b'4eee741a3546114d9c0fde86fc427a4524099be', 
	
	
	 
	  23: b'2b52a119d3e43614dfaaf53a664ffe2d9d542d4',  
	
	
	 
	 24: b'b3cfb6d54e75be7d22f3ad96d0276e1eb5d0263',   25: b'abd70e9d9331151cdb8aa9491258aca16e9e98d',
	      26: b'0d563dd6ae43227fbdb90b823fcf7f9d8be34a8',
	
	    
	
	 
	27: b'0e8679b8a1a45557485516816c9a6d249846cd0',  28: b'd96f4144e886895a1cf1b2b89d895a50e756070',   
	  29: b'dcc38d49c768a5c4de1681c7922cb0e1febe453', 30: b'03227b9c6c327fb4d52fc148911cbbf47b67253', 31: b'920bb218f8eb77e7117577ad363b4b094447225',  
	
	
	 
	 32: b'fb4b777ef0b2026a92c435c500c2d10349cffbe',
	33: b'df14ce096a2886c0ea60baa7f1f182f3bc35461', 34: b'1ed8306ac533bec9f8470e44d11ea387b3316e5', 
	
	35: b'cd025d91b295d882a99017f9bd1d827deebde22',
	
	  
	36: b'c13c0a509f69898c000e911a9db412b018054e0',   
	
	37: b'bd57300a8efddc8cca768bbbf633db793242be2',
	
	
	 
	 
	
	38: b'6ba4b63c3b3e3d3a3324cbe5fb2f44ffaeaaa70',  39: b'5bbd90cb2fcacd8012e4736935f3e8a34123e0c',40: b'f202ac7da006de1d5e274a5b06bee3592ec44c0',
	 
	41: b'1939424690245008f893715b6681e6132f04f72',     
	42: b'ac156db2df0d145fc9931a3fa4f67011ac0a035',
	 
	     43: b'baadeda0669538c3becb58ca723e7628207d991',
	  
	
	44: b'a76a16b70fa4c6f9e3965ddc226ee07c1c321fd',   
	  
	45: b'e43722ca177dd83cf4898673fa68417499c2546',
	 
	
	   46: b'bfe25b70ac35aa637355b4215dcccaa7a6f9b8e',
	
	   
	47: b'602a45ebae50b109fbb70ad3920696c6df04dbe',48: b'665533d353cbe9a6c4aba365adae2bcf5ce4526',
	 
	
	
	 49: b'b6b8138f7f6bd6926ad4b00b75f08cb00d564df', 
	
	
	  50: b'7db3fabdb77c8071c650b2c8525c7ae91a258cf',
	 
	 
	
	
	
	 
	51: b'f284f60b36dd95e11ff97c07a662e7262323f4f',
	 
	 
	
	
	52: b'e6da640a9ab9cb3a88315e94bd358f0a2ac02dd',
	 
	
	
	 
	 
	53: b'ad41f245393be6a01e427607d3a41111019e6c0', 
	
	54: b'22f4aa3d57132bbe1690c3aa35badf1e09350f6',
	    
	
	55: b'9da34e8b7ec85e6e4df4a71d0bdfe5f323d3ee8', 
	   56: b'54ce6290c9f4300bdf56bc916b53165c01e8148',57: b'b6eaa07ea2b01e5e03864aa7cd7689aa1217b7c',
	58: b'f25295926f641061aaeda9fb88ef27aa1dd7dcd',
	59: b'2fa0bb576d29c0e9ad4f522b0753ae624d2962c', 
	
	60: b'3ad2d0d835e17fe88c7c82edb72ff6526ac2bc7',
	
	61: b'aef4a1863228243bb614c61fb8d64bbf29933cd',62: b'8ff8c495980545d008bffd9f6b499b8eaa4a7cb',
	  
	 
	
	
	63: b'0c39402a9ff0099b76db5ec5e24ca19186cafba',  64: b'fef688acfd5f1449991c33cf8f8da6795d5f87f',   
	
	 65: b'da8dd6c382acb1ded858961c3ffe67c5196d5d9',    
	
	    66: b'5074fc08b8c2c2596fc410b4c2bf06319ef649e', 67: b'0722e5f6d87c909d0d2a22154b50d8a79ec2f7c',
	 
	
	
	
	
	  68: b'113f4b7630d22de072f3a62571d5e782a153f4f',
	
	 
	69: b'7290059d5feb8c1bbfe65b127eefd108e0ee48a',
	
	
	 
	
	70: b'a5cf3680dcd2b583b768c7db27e3cc1c5eaa045',
	71: b'a1ada47dc1486cd7c7b1b48bcf9ae4b67dbcd37',  
	72: b'5f9cc6598b5c8d05f04306f9dcc10b0724dd845',
	     
	
	73: b'4167d37fdcffeef71882d8f6b153a71ac0914dc', 
	 
	 
	
	
	 74: b'fd6e024774c98d95e09a34a8319641a7c9476a3',   
	
	
	75: b'b2a440274cea6b93f16927b5e6b7e4d7ab51986',
	76: b'7d5a91c97cef1d55d0545c6f71d156124cf02a0',    
	  
	  77: b'4882042448820421e6ffafde162ecb081cc19e7',
	 
	
	78: b'78028588e1b3182ec0031365f96937570178f2a',
	  
	
	 79: b'6e828bbd4d50adf87c69aba041fc41929ef6ba8',  80: b'adc6e285254b404d58954c26248649738d350d7',
	 
	
	
	
	   81: b'f9e30f6e10ac163ecaf6d9f5c2f6e2bef31b9fd',    
	
	 82: b'59ad649a3da15576ef1e220bdb5fb6b9bf0ca64',
	   83: b'05d07feefe523325dd49ed3fe4d87285ac131bb',
	
	
	
	    84: b'108d065ec73597b1716d89b30ad425ed3824f37',
	
	
	 85: b'c41830ebdffa33302fd9b6df00cac0582f4f0e6',86: b'1852a8177bfed57eb138061e2ff77ab8eeedafc', 
	
	 87: b'503df9a308fa27f6ae1443432fe9f443dedd0e7',
	
	 
	
	 
	
	 88: b'5461e3c13d3e2072443874a6ea9b7acabe2836b',
	
	 
	
	 89: b'5900f9c33b0f8f5045e9efcaafa5722ff4577fd',
	 
	
	
	 90: b'50faa572f65ec79e686d436a2699cfeb44d5abb',
	91: b'41488e1dfd400b876c04ae7b19e936064804e85', 
	 
	
	
	
	
	
	92: b'4e163e28d1be9bfe330c7610349f4631aa96412',93: b'365c6c688ffa9c4490f97ee0051286e3fc31d67',  94: b'8040f940b5f926a6d698977f793332f22f085f5',
	 
	 95: b'829eae43210890c6414a6531a9ccac4777935ba',  
	
	 
	
	
	96: b'79513edd6f5d207ad7fc72a8f1d495e8f294fe6',
	 
	
	  
	  97: b'ac0adeb8cf2f1b4f64e5579fb7a52b8e0920e28',
	 98: b'811d3e524be9c5b8c90feab3d17a98d1b44f301', 
	
	  99: b'6cd5625b6924e8420cd6504931f49371128dec4', 
	 b'daaceefcaabfefccdbaeadabfdededddcdeaeea': 77}