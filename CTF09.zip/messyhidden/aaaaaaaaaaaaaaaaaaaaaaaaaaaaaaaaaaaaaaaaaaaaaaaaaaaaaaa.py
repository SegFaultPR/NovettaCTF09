class fffcddefdfcefbbedffcfeedeacacddcabdbece:
	fccaebfdeefeddadefdfbeaefeeacacfadeebcb={0: b'f2158d64bba0b8f60c3f32fd6d0dfe25b61e87b',
	 
	 1: b'f6c73b6a4b1db5e1fa2401dd8a289181c15ef6c', 
	
	
	    
	
	2: b'707c24d79a544464fab4aa206512a4f0bfcb375',     
	 
	
	 3: b'385d389a9ba0db89ec805410dd407a388721887', 
	
	4: b'1d96ed5994d6f7ef452dc2203ebb94eb551072e',
	
	
	  
	
	5: b'ac3b5c4999867305fb05890284fcec583216260',
	
	  
	
	
	   6: b'913044877abf76cae313697cb962ab8eb569b8e', 
	
	
	  
	7: b'd426855f1836b4a749f8954c3b902d54f6ac614',
	
	
	
	  
	 
	8: b'ff2668c461ac7ea3403be023d7d4fb64741c808', 
	9: b'55b9c2e7179c3df7cafeea0895316e04e675128',
	 10: b'0f5bbc44e2064a102ad85af00c76c305106b4dd', 
	11: b'15e252cdc1e697a3bc047a6f619535a77e4d805',
	
	 
	 
	 
	12: b'896cec00b7ae2264a7b80a5c2f99ae4158da247',
	 
	
	
	 
	  
	13: b'4f3a1f0a82204b34e79cfa60c4189867884e0f7', 
	
	 
	 
	
	
	14: b'd8ceefa86e1b4769134c7f67b646857b851cad4',  
	15: b'2f21b0ad45f264afc57398a41e32968eff6620d',  
	
	16: b'5e9591fc22aa008ecdee0734cc8d6602c2b806a',
	   17: b'545c2dda5ddf009558ce00304cc35a18d5ec83a',    18: b'ca43e15b7c0921ad71e11f363ec25714befd6ea',
	 
	 
	
	 
	19: b'63ba36132cb117c3358230359a6c556807b97e7', 
	
	   
	20: b'c8f9b6884994139e7b2db9e288dee39b823f404', 21: b'a80b2e7b9f8263a82a4095785f380f6ae536f42',22: b'286ee596f62440ee7107f0687d49255f8f90235',  23: b'2a1b8c100195809eb6daba66482ae88529adc36',
	
	
	
	
	24: b'fd0b5285bae69bfef0af0c4b3ef031bea8d69d7',   
	
	
	  
	 25: b'b1c7143ccbb77539ee3e592ed5dcd9d53d16ea5',
	
	
	
	26: b'aa2aa583f4ab903105c7c0068adfebe6cac936a',    27: b'13bdce9a7b02f536ed94dd09fc1fed6054c27b3',    
	
	28: b'4bf01152971b658967a3ab5ee87adf642f53c11',
	     
	 29: b'043f62d419f8c8e79a4546b303f220136eb7ec8',  
	  
	 30: b'1588a9f5f16815b32d031ed484c02231a3acb40',  
	 
	31: b'ef5c3d23182b09be266ea07d0598438c5202a9d', 
	 
	32: b'93db3925eeaf852b3c8c68cb9f928d3788bc410',
	 
	33: b'c55953bb75dcf0c06e4ec1ddf56e51919e9fd80',   
	 
	
	34: b'df5c286e2c950b97d5176277c04097bf5edec36', 
	 
	
	
	 
	
	
	35: b'ce4db45bd6e2604877957985575e284f9764fb2', 36: b'2f37d829fbaca2603f33a955d782133f51bbb32', 
	
	
	
	
	   37: b'9b44a620ba9ef7e62bfe0dee52fc5b0f7f90b07',
	
	
	
	 
	  38: b'b9b37cc9cce13673658e49ee849d9596440b8fc',
	
	
	 
	
	39: b'3aaba6f7c26d84bb163b311cc31c46f6503a5c5', 
	  40: b'094ebda954b3e0add21c8ff58967d2a36d418a9',
	
	41: b'bb03065d2c44cbf445793adbadc1e6151411a62', 
	  42: b'cb45e3c9f232d6273933042baa4bea95b3471a9', 
	43: b'dbf39e6586247fed2e42595cbddd4a31a85037e',
	     
	
	
	44: b'fdad8dcb7b8058f96df7b8a7a838701772f7793',
	
	
	
	
	 
	
	 45: b'8d7a00cf1824bff78b6c8a301d59da8597e0ca6',46: b'f80febf3e8194e83bbcdbe3cde66bd407fd1abd',
	
	  
	   47: b'e0c44d8764bf68404b743a49e903b4c35bf50c6',
	  48: b'45562140a8a85b8c5dd1bf1f7b005d2d4b390da',
	
	 
	49: b'bacf0950ec3d136bc372ad824bacdc32a094acf',50: b'd42fa9e5782f4327efc6490566296fa7e62fab9', 
	
	51: b'14c434ee062151f65342fec8a14e7d2e6ad251a',52: b'50f0866f8d5cf736c84ff1c378fa5819ec9ef4d',
	
	   
	  
	 53: b'4aa5f5ff0e2d46a9422d5d64147ca0f068d0ff1',  
	
	   
	54: b'280546ed86ecd3f7df4d0fdc2984696e1deb589', 55: b'1a742f2f34352c0a88abcfe7203cf91cbfa1b2b', 
	   
	
	
	
	56: b'aa68a9a615f660f8d1fea90d4aace3fb000e853',    
	 
	57: b'7a9a3b99ce3a306550f5b9168c637d3a818f61c',   
	58: b'3cd28cd593b05e7f72a65ca59051c10008a5ea2',
	
	  
	
	 
	
	59: b'31d2244e82241f701ed1a22bb7a5e17dd4d85ec',
	
	 
	
	
	
	
	
	 60: b'5eb53dfe06fd926d984ef661f6d7344222a8891', 
	
	  61: b'ce8d9b55871aaacde10bf6c0038999a4862208e',
	 
	
	  
	
	
	62: b'09664497e1ad596e135c14e59696f5ce329ba2b',   
	
	63: b'f1f2448a35d2f160f0a667b84b835299cf9c122',
	   
	 
	64: b'0b7e2514e4e6ea8524f71a860e5253292345cc9',
	65: b'eceb379eb7129eb9de3ace3aa882e43f2a98580',
	
	  
	
	  
	66: b'76dc88ef9dfddc35a7fcd66a79cfa4d2b04d989',67: b'c921c6360cf99bd3901f9e6272201cfa7aae23e',  
	 
	 68: b'5d13bfdc954a6d5be7c32be4a539e37922c09b4',
	 
	   69: b'aa0c92f8bf4b00a5c9c6d77da05b9f89ef9d253',
	70: b'f8625c9624d035baba6c5ab41f42b85f7501cd4',
	
	  
	71: b'4cbec0bb07471dcf270df0e7cdb1eecfc2bf502', 
	
	    72: b'd8884b93983882e8c22b121ec28e31a779418bb', 73: b'1bf913c5f603591824f2f6e46b445c288c22abf',  
	   
	 
	74: b'5dc1ed2edc17adf5b51104298911f23255ccfff',
	
	  
	
	 
	
	
	75: b'9fca2d03d811fded19005833916c7b95e156a40',
	 76: b'1575aed89f1ee0275fb645b00e0a53b040d1d3d',
	
	  
	
	
	77: b'c474c7e4be94df730f5cb691736ed782c630088',
	 
	 
	
	  78: b'0af51ae0b1e304077f62a597611e531cf41aec7',  
	   79: b'ceb55a45ec48366dafe12fb044cfe7173ab9ce7',   
	 
	80: b'78c0df7a94785a773d3c8c53542a0f6c65909d3', 
	  
	
	81: b'11350e1449a58c5d50e32658277b00641793355',  
	 
	   
	 82: b'57d75b1def96c95928988fe1614df7bf62da83f',  
	83: b'9904338bdc1b82e7e67170cfd743761bbaa1602',  
	  
	 
	
	 84: b'72109183525be94f0f86dbe7c97d14a123199c1', 
	
	   
	   85: b'b90874d3bac0ba710737721e6f410fd5bb8c12c',  
	
	
	
	
	86: b'74d94dbe61d13a381a1d04a1f355b3b34e6f67e', 
	    87: b'129c7f376f409efc26767f61e6dacd406628d94',
	
	 
	
	  
	
	
	88: b'6c8c40848efc4c25ee468333de35f64a3288f40',
	
	
	 
	
	
	89: b'2d5423a8a9fb06a3e6dcef7779ae07ecbcb11f3',
	   90: b'79da73ad35569eec9f2a93bb5ef7bdeb2525667', 
	    
	91: b'3e105d77451317860946db4382d35f7c7481cb6',   92: b'90ef9e320c4f08601daa4f09bd0702148e664f9',  
	 
	 
	
	 93: b'e9cbb997d2ac9ee1e8de5f03b19a8359e8f47e8',
	
	94: b'eb22ed207bd0b938d13d29cbfde35c0b15c70b1',
	   
	  
	
	 95: b'cf241dcfaee57c4ef8f2e58de85a0736ec52959',
	 
	96: b'041bc582e9c7498128b13a9766ba2bba8e843e1',  
	  
	 
	
	
	97: b'e3ffa1189cdfbe9818bcfea4db2541eb6ea8de5', 
	
	 
	   98: b'8242a519aa41c7c1d1c2970831798394cc629dd',99: b'ee663895e00c17d00cdfa16d5c9749376d6acba',
	
	
	  b'aaebbceeececfabdeeddafdebfcdccfaadcdaed': 68}