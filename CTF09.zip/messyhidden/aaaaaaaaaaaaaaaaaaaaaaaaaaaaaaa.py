class dafebbecadbafcecbdcaebeeedfccebdcbaacdf:
	cacefcceadfaccbdfdedfbabcbabefedafdaaae={0: b'a8f8c649c26e0d36cec7fdf410b2b87eb35bb6c', 
	  
	 
	 1: b'2db5e1c12a723b71f1fd65a598c49e7fb27f8d5',
	 
	 
	 
	
	 2: b'2e0922ed0b3a4e6ef85d88671ed94dd43ca4781',
	 3: b'aefbbf182829dad112bfeea4dfa7db1732ce226', 
	 4: b'f869f275dffd3746066d3291dd6a3dfb194c8e4',
	 
	
	  5: b'470fc5b7fcf8b8e517055eae931b3f66e04eda4',6: b'a9d3f64258adaf8568b07c32cf3b1cd33246b17',
	
	 
	
	 
	  7: b'ef7b496955689d9cc25790cad33393d27716615',  
	 
	 
	
	
	8: b'e70b4c0885d5e385ab070c5a01bfd7819af0a7b',
	
	 
	
	
	
	  
	9: b'b8ae3788496b5c99b425778a995f78213dd2fb7',
	10: b'f1f28f14d5ba9801386f49530aa44a4e3bba9ad',
	   
	11: b'c4f69348cbd6ac9d3d97284e59c926512ab3bfc',
	
	12: b'848ef913760dc934556830058ed785e2e58431c',  
	 
	
	 13: b'3d7cb713df385e0bb24e4bb7de14522c0633c9c',  
	14: b'a1cdc3d30d7640d5bb11f67519ada677fe8ffcd',
	 
	
	 
	
	15: b'f1fb8ffd09011b8490cfdee1798feeae1dae6e4',      
	
	 16: b'2ca7c0b93ba9e4b353e1d070f0f64a90be03635',17: b'f6a03cc745c9785025979c4630e309939c1b923',
	18: b'9455c5f02fd85960b7cc5ba6a997cf07dd7aa12', 
	19: b'b9b103a6375140336b942fcd57c9940af6c3aea',
	
	
	
	 
	20: b'7a0f0d55ea32308a73a118544cb4428e348f933', 
	 
	
	
	 21: b'f03e0da544c7bd0d50e9d6b622190644314685e',
	  
	
	
	
	
	22: b'03a769af692c834ef40c36c63591ac983d1561a', 
	
	
	
	
	
	
	 23: b'f33473456ac084cea59aa3c54b70626a359a9c2',    24: b'ee043762276e6033c73ff24020788c57a246a98', 
	 
	  
	
	25: b'00145b7b4e0849cf64ec85ee48bd467bc85bfda', 
	
	
	
	 26: b'9201ef5399eda3b4f7eb352eda5c0d330504f0c',
	  27: b'b365280c9ec306a4886e2ca74058eabdd88b045', 
	  
	 
	28: b'2bf281d6dd463c4aa2eeb8a2c661c68510de7aa',
	
	
	
	
	
	
	 29: b'69dd9e261bcce48f5e7be6e40bc521870d5c4be', 
	
	  30: b'9c4aac21a1837e96da9dbccbd4ac3947b8e827f',
	  
	
	
	31: b'e176230a5bdbce3e1b2a0a443dd4000237456f2', 
	 
	 
	
	32: b'bf2fa28373a08b5ebb56abbc1b52c6599a88291',33: b'4d6cd68a4ac330f1c628c164c3316fa4c919cef',34: b'72d03e5a2ebfc1e635858713203e707b3d90453', 
	35: b'c14b3b23247dc5a728199198104ee1a89f1f2cc',  
	
	
	
	 
	 36: b'6cff2e891c16235ce3715c93a4e4a98133cf04c', 
	   
	 37: b'75b6ba49bb47dcd0f8a00e26ea0e4895b8a85ed',
	
	 
	    
	
	38: b'91951dfd73a3500594e5966013bb6080c5a7a14', 
	
	39: b'8f3322149270ee6e3143323e19134b390199c67', 
	40: b'42b79104d3b71bffaa0ae395acd3498cc99de1f',
	    
	
	
	
	 41: b'31df064e318f03e56d78986e60b7591de722af3',
	 
	
	  
	 42: b'9e79ebe6de861b7c4029b4dd451972d70ba5d9c', 
	   
	 43: b'2a9b4d8fb1ee71ccf9900a2f3ae80bf1125db04',
	 
	
	
	
	  
	
	44: b'e6c08999840eb934acb0f560c340d6709b22452',
	    
	 
	
	 45: b'b7a4897c4e3ce4113b06f0708886e0b332c690b', 
	
	
	
	
	46: b'7fe07c4c53771c7aa30f4ab7a420e216f6f63ad', 
	
	 
	
	47: b'e2cf23087c4bfa35c40acb1fb0d11615bbb7e4a',
	   48: b'157192a6265bf27d3a48b928632e8d0eaa2aec6', 
	
	
	
	
	  49: b'e7d3219272a3e9a0630e34c020a7e9da5d5fbde',50: b'c7ab90a410d863ac59243df1a76706d1fde0681',51: b'88bdb61b88ef5b4c3cc9046ea6501b62f40cca5', 
	
	 
	 
	52: b'd2a5b6807152e60957f3081cafe4b088866c45a',
	 
	
	
	  
	53: b'5454d5a32c2cd09b264b3347f27bc68feaab79d',  54: b'bb2b3c585126f11e8907a7f2664ae171d31eaa1',
	
	  
	 
	55: b'64be2d4297b619f2b5fcd893974333dbbebf649',  
	
	  56: b'd417bce3379c088a04971cf27e2d6465062605f',     
	57: b'f70721b257458fd6ecc067c918abbb25b2d4348',
	  
	
	
	58: b'4cdbfde688fbd2023a4aae13b8dc4953166f943',
	   
	
	
	  
	59: b'0833fc03948a95aee97a3532ef6a0a293f0ce3b',
	
	
	
	
	60: b'2f62693f30bd0c0be839a7befe0d9ce92d27703',
	
	
	
	
	61: b'2b733168ea2434dd9fe46026eb1127247bca9d2',
	 62: b'b8f86e23063bb81ab1cccd19ac1adc919d416ae', 
	   63: b'31ea2d59412d92c58523ed8af7d415426af35c9', 64: b'dea2db85addbea803d926a844a1e277a16017d7', 
	65: b'ab90f385e2a7626327ac12f304cbb28cffb8e23', 
	
	
	66: b'af8f54dec4525ab3a5771b72fabda9859906a4a', 
	 
	 
	
	
	
	67: b'7c8702723d7f36f697e5a60d842ec91bbe706f7',
	   
	  68: b'b48fd6d2e50031dad875c8d08838023d5571097',    
	 
	
	69: b'39a5147262cea0e35cbe6859a8dd3ee5007ec45',  
	
	70: b'0dd181ac465479c68d231f33ec74a61d86a61cc',  
	 
	 71: b'ad53b6d16a996198e49e6e5b9510cb3d4ada7e7', 
	 
	 
	 
	 72: b'025ca6cf06296243b4aa066d5deaf2248c0e17e',  
	 
	
	73: b'4f5e2dd6aa38d46d2d012f455a77e2e7cf035e9',74: b'474c7bea047b18c56d35b677a112884a81ed6d2', 
	
	
	75: b'76e88a1484f59575f1d3956cd5582f9ab169b92', 76: b'ad4cc55012c01320a316862b69f360ee079d1ac', 
	 
	77: b'be6cd639ef6ee3bfb6d74130d027029aa54a8b0',
	
	
	
	78: b'53dc886e244db3b217ab0aac32272e0d3402a57', 
	 
	79: b'fc7a27f6d1a6a5c1002ba9d4603b0bff7b32c59',
	
	 
	   80: b'a3f4dc1a67b294fad6a40f5bd7b8546df1a7654', 
	
	
	  
	
	
	
	81: b'3f9ae941e954a2a2d4c08bad23a7d3df49c0c5f', 
	   
	82: b'c60b52e6eb87e612a235fd51b0ec150019a4cf1', 
	 
	    
	83: b'129f4ed7698ddfe5d4774a62140c26a4d5f49ee',
	
	84: b'a797d5cdee29ab3f24c52e2bd2313499f3e8056',  85: b'2bd4f56f4c6627f8e31d3f8b460a4fcd873a664',86: b'8b574730dedd4bddcdd7cff6ddb481e7914a177',87: b'85822bf99321cf2251c96af0f1612467892a31b',
	
	
	  88: b'34d8ffee4ee5eef9a2a86da0445b398d2ce2b7b',   
	
	  89: b'7622470b66886eb67f3a3367f41a08606ee753f',  90: b'21a213b1f3666dde54bc76262b9e83d497eca24', 
	 
	
	 
	91: b'3004173439a078bcaf885f107a23b5380087080', 
	 
	 92: b'db4b075ee5489d03fdb1897fd9c68183f39db67',
	   
	93: b'2ce47a3b928552400b3656b519050ad51cc7953',94: b'071515de1db1b4da29bab83ae043e7ce7f24a57',   
	
	
	 
	
	95: b'b116ee576f7072a8335df22eaafc51c71160dc0',
	
	 
	 
	 
	96: b'32947e6536e345a2b553446ee4140f6f30d8e59',97: b'd3fc32105a55bbf5621feddf9dd99627e0b3909',
	  
	 
	98: b'a77b0e83aba45a8501c500e9d90bc1d16d76740',
	
	
	
	  99: b'5d1ce480b199d3c29d61869135dad444985039a',   b'bffddecdceddfeddfabaedbfeefddceabaeaddc': 53}