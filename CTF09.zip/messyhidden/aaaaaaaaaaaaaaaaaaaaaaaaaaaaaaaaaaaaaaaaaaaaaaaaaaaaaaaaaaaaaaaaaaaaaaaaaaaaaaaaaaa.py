class cfdaadadfbfabcbfafaaeffdcaabbaaacededcd:
	cdcaaccebedabdacbefcddbafebfdffabacadff={0: b'd21893c43308e73b6279158d49f985c07caca12',
	 
	  
	1: b'9ac4f59989189324d3d5fad2bbe077fbb49b776',  
	 
	 2: b'a21ffae98ae8e5dafc8b3845e4e1e784ada2c2c',
	  3: b'dd8aa4a3fbdf10e66b933e72020e6456fabb936', 
	
	 
	
	
	 4: b'ac26cad56fda9c028ad132715437ddc43c50dd6',
	
	 
	    
	5: b'9a903c366b448d6ce5e5e4bfb5ba9ae5da00009', 
	 
	  
	
	6: b'd0494d859d7389cab2f40432b2e4b1c6c26ddc3',
	7: b'6773b1687c6efafb5b8ce606a4ca5bffc0223a7', 
	8: b'dad236b4db8f08bc9c668512033aeb5410aeaae', 
	 
	
	 9: b'c16af2f243c98518082ef24159ec44c60fa6cd3',  10: b'f6d1f654560e93ffd7a0b529082c1b4a2ec951b', 11: b'2cde728a6378ff18d28ccaae9b79b88b7efdbd0',   12: b'a3c2b5cc136a1716e0e968c5adffa3328b8e668',
	13: b'8aab06816ffb09dbfb1862c2db1551da69e9b99', 
	
	14: b'ed00cd80ef55a21cb11382918de84ede390a79f', 
	
	
	 
	15: b'45ab1f2ce9d6b82acd81314e1be9189d24895b7', 
	 
	
	16: b'93820d8d01db1521442bb94704509c1e48afe6f',
	       
	17: b'9f907e4b1c471661a09a28305bb095f45fe956c', 
	18: b'e73352ee811dabfb555d79adc144b76ba715076',19: b'2be64aeac8d41d0cd4616bd9e98e288a3b02fd8',
	
	 
	 
	20: b'31b872a2674edfe82da47a9937c1f2537f00d10',  21: b'113d8c9ac9ec7b71f53ad1bb1566bc5a403e72b',  
	
	
	    22: b'600a48bd87dcd76a0fddd0cad2fda070c0bb178',
	 
	  
	
	 
	 23: b'47c16dcf7b672d2e26f003045ee850e8f8dce0e',
	
	  
	  
	24: b'b749451ba334aa9fa67a12bc6d4a0ba3d14564a',25: b'9b6bb0b6b129b5801b372b0809e8de699c34f65',  26: b'1c3a2de06af369b1f2be63518d82e1c8a1b14a4',
	
	      27: b'c6a98668e842e27a7d5e6e6c0faf2b2b97f7be0',
	  
	 
	
	
	28: b'534ac33b10d39c3399eae81919289aa2f37c45f',  
	
	  
	  
	29: b'4d0d7f1c5e15377234d70dfca2adfbe9c03435b',
	30: b'3a16a99d1e78f76093cccc50503b5dbc809cf64', 
	
	31: b'c3a3a7df0680600f26ed01f74eaa5534118a26d',
	
	
	   
	
	
	32: b'6bb74c850fc67e850e225531b9e82f1aa3aa755',33: b'eca15600d03f10382797012a014a9279954418b',  34: b'13f6bf96e7c530bb398e75e8102dd84475b95f3', 
	
	
	
	
	35: b'dc7c06fcde315fefbbaa22b77191ebd597c5ee5',
	36: b'3051f4bb279e614f646658fb7d54a0aa8f46b01', 
	
	
	
	37: b'ac72b6201a0a2e79315a1710d5c3fa01512d4b1',
	 
	38: b'f4fc9cef58a226041c8772e65c8b1b2d3fdcdd1',39: b'12c3b5e60bb4d5b02be73503ca80acef543c794',    
	 40: b'7c11b71e88f8e874d81c50088056f3a2f79c0b6',41: b'd2c5cd8f8928bd50e7e81318d2c83d19b2e778c', 
	 
	  
	 42: b'80cfb8aadc91d3e729a71a5ae7992813195c3e5',
	43: b'02f4155d17f5b5ab3d1906c5361c9fe38a7ecf1', 
	 
	
	
	
	44: b'ed83604f5a0daa3db20e1e55a7d62407916f2b1', 
	
	
	  
	  
	45: b'f35597a79257c94f2eb7699c6b2f5f9880c5047', 
	
	  
	
	  46: b'c718edc9f037e80ffe5fc9fbcc8ade85496c4ce',47: b'9e98642bae936da76ad0c1943193436105dd2dc',  48: b'f9979dff566e0544e394c8dd5f9b49f881bf409',  
	49: b'a505bb63c3477c36702f0e75c5af3597454850b',
	
	
	  
	50: b'19669312ce0b06e113b75da6789c1a3370af914',  
	  
	
	
	 
	51: b'21cdae90ebd5ec17df83d6caef33edc57889a6a',
	 
	
	
	
	  
	52: b'324383a650f5b4d055c50ae89f67be2c7c40e3b',53: b'aa950750a918b39e4b4edb0cef4202da1c2cc7a',
	
	 
	 
	54: b'b862d9f0cb4bdf1dd35e207061c907313d991a2',    
	 55: b'bfe65a9aa4a883b3b051378fd77cb0f052aa604', 56: b'bb4c8f34b6fbf1bafdb5116c0d3c0c97eadc7e6',
	
	
	
	
	
	 
	
	57: b'536707d41031941b6c125070c265d5c34e5d642',
	 
	 58: b'337af6529e11a52540d343259e592526bb8fc48',
	
	 
	
	 
	 
	59: b'4c0b1e802f6ae8283608add6b921daed3c94a37',
	  60: b'66f41866cf89574467f80da887e21d34a583c98',
	61: b'c6fe3a2e7c18e1bbfcdad03d7e71e30abe45967',
	
	
	
	
	
	
	 
	 62: b'df1652ffee47f3510cea476a59841d9c1505436', 
	
	
	   
	63: b'3a830c96cfb5edc581e9bd852029408a0552e65',     
	 
	64: b'e0251b47231c5db29cfbf5d3f11c22b88ecea7e',
	 
	65: b'ac69d0b32a57d2269f479ef4f813ccad58ee511',    
	
	
	
	66: b'3ff0bf7f5acb1b2b5787165b4d2bdf3c0672d48',
	
	
	
	67: b'371daa0fd477810a0b269852553506d27767e91',  68: b'b8a9a490cd94de3002f218f8d48b5d0d02ed168',
	 
	  
	 
	69: b'33fe160c77b306e95ece0c485969bda86f55ac7',
	 
	 70: b'019a8bc4f4a263fd50e003433a04664a3a9f762', 71: b'a0aa8bbed0cfa7b89489b8af1d6890587a30118',
	 72: b'a365f7ee3be64fb1d2716a131b2683c99ff2862', 
	
	
	
	
	73: b'd699c5490556ee1b592040c0e5d1154fe2610dd',
	    
	 
	 74: b'ea19e6ca031e81a3a6aa3e55771b0006d1c4a65',
	
	 
	
	 75: b'd2ac383efffbee435766308ff959cde095a1ee0',
	76: b'66991101157157826301ca65cb8c0c5e10ce317',
	
	 77: b'44c7c66db9f2edfaec5405a4312906dc9b4bd25', 
	   78: b'7d535bddd71b53f61d51945edbd71e0e0004d93',
	
	  79: b'b23e04519331192a895258983bc9169ccc22fc6', 
	
	80: b'd7bae4e1ef6507f36cc934e3f79a3321a15ccbb',
	 
	
	81: b'f8df7b2881ef28883eb1a92ccd2199901b67ff9', 
	
	82: b'9bcdd8294ebda73f9dcd914389bd1a01ded1701',
	 
	  83: b'c3298623c9384ce9a70ffe219cc644f8688db80', 
	
	
	84: b'e959d9d8c602eec25c4d1e4e2bb46309b485489',  
	
	
	 
	  85: b'4cf6f0f04ffe1e1186adcce3abc481f23b7dd02',86: b'b26b659bce349136f2e24abb43bdc9c15628e9f',
	
	
	87: b'75de8c29b10e7e3846c8bc9c9b064a6b3dc7639',
	
	88: b'b3dbe41351fd8238671225dd9c8e4150ccade08',  
	
	
	
	 
	89: b'7af9ab9985331a678d8ef42961d9bdd6bcbd9f4',
	
	 
	90: b'56d4efb8ac9559c5699c8de9db10988b1076259', 
	
	
	 91: b'14eb2573d47b8d5241ff21f8655c4289d99cd45',
	92: b'a23b4c0c35c4765a995125d89ed40ae33f976bc',93: b'37e130255b3f549d1db80e6b192c975ee0b51ae',
	 
	94: b'e90dd1e9094f047e75f310930ed2a839879fb32', 95: b'a7428c1a1d5e39ac226092cc46f6d7c6434e2e0',
	
	
	  
	  
	
	96: b'5c448d931ca8bfbcc540831c6b5cebb6e1631bb',
	
	  
	
	 97: b'dcaf327717f1b15c68e93c2a58973294f4e512c',98: b'bfc1967dcc36fe2135eecd55d36cc3ab9c285e3',  
	
	
	
	99: b'6c75b721d52d92babfd47bfaf710311bace45a5', 
	b'bcacddabebfbdffddeaccafafeadeaabbaeeadb': 25}