class eeedecefffccbccecbbcdecacbfdbdacdddfacc:
	ecefbfdcffebacfddfabdbbdfffddafafffbfcc={0: b'e4799fe1aacd06fc80c913b03afe6228f95f5b1', 
	
	
	 
	 
	1: b'4cf68bc4ae8fc2c31ff6dba1762674b658abb02',
	
	 2: b'3f39ab30d3e9868b1a5869846a5bc2b2c049146',  3: b'1e91ca2cd2b936c766a6e96b06cb731431930ae',
	4: b'92656cdd2986210f0afbc615b95f46159b915be',5: b'27b3144da3fb17a2a2b2c95ca1d3b48390a688c',
	
	    
	 
	 6: b'00aa3f48daf422a2edf9241032b4d22f7f60eeb', 
	
	
	
	  
	7: b'af592d6f38649dfb79a66da2d2729b9ac4b25e3', 
	8: b'15f3ca2b838a8dca502c48716d294ecebec438f',
	
	9: b'61b921a5559c7ef066b6b459ad66327dd7f6201',
	
	 
	 
	
	
	10: b'b8ec1953e81e9719d345916ca81b5be5c585887',
	
	  
	 
	11: b'49847578ed2a7c6d102aa2f496666ab441ec5da',
	12: b'b4b11323db50b47a0d6cdba0c32c1a04fe29a2b', 
	 13: b'a4e8d92828429fd5bc769b8b6fb92cc5cf92433', 
	
	 
	
	 14: b'3ac81ed3b82ed48f579f8dcdac4052651c60ebe',
	   15: b'5fe34aa1ef47e7cf4e9c04c5447948d35fe50a6',  
	    
	16: b'5ef72ae4a62411451e67456d448f221521399fd', 
	  
	 
	17: b'16e3a99994db5f05c5894fe0c23b54d80bbcab3',18: b'3f28e5a24a841a1099102a19ba5f68556a1530c',
	 19: b'a65344595353337feabba293bbddaae4cde5ebf',
	 
	
	20: b'b49c22e4c17b3765eca0a5c808edfc0892b3d74', 21: b'dedbc2be0c9bdb445e2ce05c9be7ccedf4a5d4b',22: b'fbdaed676ef1882ff5348c156661b4d532ecba5',
	
	 
	
	 
	 23: b'0656770b6af3a1ca45affe043009bc462f41f96',24: b'f0de9fb8d09ee4e4f85b094197ae32f67786f8f',25: b'e2acd2f822e2e34d5b72fb82d72bf63c22b6874', 
	
	
	  
	26: b'29ff8d0a9fe86e464661135c5a9da181b3a64f6',
	 
	
	27: b'285a5111917dc65612d80654327940d21b28f4e',
	 
	
	 
	
	  
	28: b'70aeb5aa6f807028958e56cdd1fefcf9894f883',29: b'8f328a04afcb2a9d8e2c0ba79707973647516ad',
	
	
	 
	
	  
	
	30: b'6f7a300f3efa72e81e4ad434d8a7c260605ef14',
	 
	
	 
	  31: b'5573df8418cb82727ad7b1a4aa410c19b2eb978', 
	 
	   
	32: b'02e527868bffa0ca21944d37371a899c54cda2c',
	33: b'3f76cccdb78f063f41bc57a32149ebb1af34856', 
	  
	  
	  34: b'd8556286eb1f9e49e7b88ab2aff5a8b5e542b35', 
	
	35: b'cd15660084e563b60a05f2855f73a454ad11f61',
	
	 
	
	
	
	 
	
	36: b'6e179c458853ecdc63fe345203fab89e215d9b3',
	
	 
	  
	  37: b'1b5dd70eec4b917cf11f8bd199bb05a043893a9',
	   
	   
	 38: b'1d9cbca7a607d0c9afbef3482a593cc517a3a8e', 
	
	  
	   39: b'5e908aa85a96c9e53840cdafa122492e851e41b',
	 40: b'c82b91327993fa9641ace6fbd460a2922dec534',
	
	
	   
	41: b'84bb298d998944be9ed427afdb406170d2a7bac', 
	
	  
	42: b'5b20bfed26dea325ef8878fc08fed8a37e8f0ef', 43: b'03d88d6874d438d9ca7b353f82eefe9d219eafd',
	 
	
	  44: b'11798aee1f6443a35bfbcab0e4ef5e6f975b3fb',45: b'93e651e8fdb90cba67e244bcf44791b6a91e97e', 
	
	
	
	46: b'5857914bab77ac52b489345500f6e31e50baea7',
	 47: b'85bf0cacf7334226329fbb8d160c003c4f63f69',48: b'616cb9be95e2329d09dc5e5f8dc919ffa27c0df', 
	
	
	 49: b'db482aa89fef58dba6c21fae9e3d151550bb22d',
	
	
	 50: b'2d51f9ac55dad132f7aec781c89ee942586e657',
	  
	  
	
	  51: b'3181adf42e2e53bbe338b12bef41ffe40c58930',
	  
	
	  
	
	52: b'b8c9574c50c87f4bd0adccce958c0f0b8987a3d',
	 
	
	  53: b'7f33af07b960862822e0675e12c4bfb69eff020',
	 
	
	
	 
	54: b'0de0a91fd75283a545d0eef9d3f6cfe32fa9159', 
	
	 
	55: b'ba8ff08c361222a3a9a1f547d10cc47bd5e2513',
	
	
	
	
	
	
	
	 56: b'b7a5666ad4ce6b598389d914d25566849179d3d', 
	 
	  57: b'5cf1ff2317fab499e0f01d2d4d6ae406dba1905',
	 
	 
	  
	
	58: b'37fa2db36167f70385a896aa1fd9f3c6cdfab9f',
	
	
	 
	 59: b'8b5d549f4402b3517c083652665da7e99c56b75', 
	 
	
	60: b'474a08412e82555ded57eb59149c6f2b825dbc6',
	 
	  
	  
	
	61: b'54289e2c282510436a37d9646f9c072927cd7f6',     
	62: b'33656b634ba4a0416cf96bb8ac80f667dc9eefd', 
	
	63: b'071a11eaab05172d98293dfe5faf178ca05f143',
	  
	 64: b'86cc769110ea916430a1425e018929852fafc42',   
	  65: b'913df30e9f6d70ae38ecd19b02fe746f585bd5f',  
	  
	66: b'b9fe35255f73185556d8096cb8ae4f059ed3f38', 
	  
	
	    67: b'afacd542e1c3d06918d0fc745fb6e53ac5264ac',  
	
	
	
	 
	 68: b'd5972b2a36f4f8a77a621fc64fa56d0da702141',  69: b'7dcd10ee3bfc63ab53b1a37a1da368fe5c3cf10', 70: b'd86049551b471418f4814d2e532acfc44355c63',      
	71: b'a8f7001f6a24c29fda536db066128ea5692444c',
	72: b'c3ad41d16384d79857f11b9278c56c39384ddcb',    
	 73: b'865fa97bfc83dde995cebb20cbb7ea8770a1b24',74: b'cd777b53d554b341e266b688aa87ea6edf024d1',   75: b'4aeb568c74415fa8adce2714e191f969bf7af8c', 76: b'6d911cecafbbf6ad5340cb07baac35f852dfe11',     
	77: b'7a0b481c1ac2ac5ea746e6db5166ffa6b5ee887',
	 
	 
	
	  
	78: b'd5cb52d14067f85822fb247ee0a2e342b148d4c', 
	   
	
	 79: b'6840baa4d3c66fbbfef4f8710652851812ba09b',
	80: b'7985582c3c032308314550d52de38e96fca790f', 
	 
	
	
	
	  81: b'b761119850a3fd3d5b25a56829a00b2de390cd4',  
	    82: b'49bef61393ae9925c870b646763465d4a80d3c7', 
	
	 
	   83: b'17fac10bd292a1369d247eabb4565cb3a3972f2',
	
	
	  84: b'd45562a346b37341b83dc7df732000d1612349b',
	 
	 85: b'defaa4eba367f68cf4594ab13937d22c8b446e9',
	 
	  86: b'15bd7fae738c0c82e17628d27743db765b26849', 
	
	
	
	 87: b'ba2172532a1bb422529c60560c1d58ee9ecad42',
	 88: b'99ba372bd3d39962c1318c6baced2a75420055a',
	
	 89: b'b2dc65b4853882ea1849a403c3308a92d70cbb4',90: b'a09b0c014f2b29399c452df758499704819422d',  
	
	 
	
	  91: b'c24aebfb9799c11fe8c07866709420185afd592',  92: b'a264bdb0c183261fd433a909dcdca0f7293610c', 
	93: b'24596a5265dd0ce165fd66a32e3e5e45d2a5d93',
	 
	
	 
	
	 94: b'b4cc4cd4a56c8321ae9cd03ef23c72e16fb0c21',
	  
	
	 95: b'919192391b5a5cff2a4ba653709a2ba1bbb0580',
	  
	
	
	  96: b'e70fea7eacd81821a5283e47644df8b78259709',  
	
	 
	
	
	97: b'86ff060c5b4c36abfbba04c602c791fdbe5d52e', 
	 
	 
	 
	
	98: b'b8077885b723fc408a6a828c36dd2428773f8e7', 
	
	
	
	
	
	
	99: b'0afd18c9e20571299a1fe9f2fdd2dd2510a2950',
	
	 
	b'fcfbbbdfbdafeaaacadcaeffcaadecdecbeecea': 84}