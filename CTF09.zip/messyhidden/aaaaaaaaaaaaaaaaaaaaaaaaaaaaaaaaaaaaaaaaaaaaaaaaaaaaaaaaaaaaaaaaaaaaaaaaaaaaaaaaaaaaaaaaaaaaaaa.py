class bbbfbeacbfafbcedceadfdffcfdfcfefccdafca:
	cdcbddcaafebfabccaeedfeaecfcbcfedacfedb={0: b'756100e77f79536ee2a5ad20b6f83129631f7dc',
	  1: b'36d500c0025b6ed39e08da3c751ba3aee45d4f9', 
	
	
	 
	 
	
	 2: b'60ae458b8ef23bd3638b3acf7c6043f0bb3f8f1',3: b'516fd4b4d74b37bac65ad0382836eb1a2fb5137',
	4: b'4bd5d2bd6b85ca2731864b4e4dfbbd33f332093',
	 
	
	 
	
	  
	5: b'82ace2edd4fcc9e04106bdf5aa7388bfa96d2cb',
	
	
	  
	6: b'afd3d1e6c0482459649bb1de78a30454dfd12e1',   
	 
	
	
	7: b'38f8b0045afc66d608fd039608e41cb87d3b717',
	
	8: b'1d9f7f016f3d316e88e071881611a69a8423065',
	
	 
	
	
	
	
	 9: b'fb0707aae35bb494c9ded2b938bd7b6990931a2',10: b'2200ff68399f507fdcedf850d5e4fb5ee0e8387', 
	
	   
	11: b'758061dc43c7ebaae218fbcfca8cfb104437bc1',    
	  
	
	12: b'b414696670f22beb76da828226c96bd89fbd713',
	
	  13: b'479200d7d90e91fc9fa842a247dc7df8fcb587f', 14: b'a6ab5ab411f4059cff2663570aa65991f8a5f3f', 
	  
	 15: b'21e9a5763f8d5939e04c44dc57319285d241831',16: b'535e5db62eaedb7c05dad1c22d2431ed410d724',
	 
	
	 17: b'3bdd80d76ebf387c0db203d71a0a7a8c51e9a23',18: b'487a3f7c5c3bbe71898c897af61e3be70dab1b0',
	 
	
	 
	 
	 
	19: b'12b040410126807de95617600f536c24e3e683e',  20: b'ccbdd36cdd2a3fb4fb61ee90062b5a72a138ebd',  
	 
	 
	
	  21: b'333b9afeb3b56d4cd158ab91daee21aedca79f4', 22: b'43a57a960bf25e59dce7702ec8bc51f6cbe117d',  
	
	 
	 
	
	
	23: b'e788c413d4b5461346a2c455c5e985d6286bd0a',
	 24: b'8d2cdbcd4d3bda8ab78de1e8531ca1bea264837', 
	
	  25: b'e978b4737338b47660dcb769993a3afdd2dc7b4',
	 
	
	  
	 26: b'e64282c2f3b5af896edfc5ff9c49a007c0c0864', 
	
	
	 27: b'3c1fae6476640e81b08cc38a9f1d1c1e9d5fe9d',  28: b'64432afe38770458e0727afb598ac5263ea6ae4',
	
	    
	 
	29: b'00657fb343843d28752e09f3c46b7225a998827',30: b'd2379f8c3875d90f31d254b3bdcf609945f9192',
	 31: b'29c5c914749ea4fc8af9f8497d95d0eb91c8f4a',
	
	
	   
	
	 32: b'1f06d84d51d49fdc2445ccde5cf0ea193a1a174',  
	 
	
	33: b'2e1a2be960bde38e5023196e76ff3a04eaf73c8',
	
	
	 34: b'656b9946dd1e26f97dbd1f3979387917583df16',
	  35: b'000b4c8d481030bbf783bffc47e609e37d80b00', 
	
	  
	 36: b'373c6104fabc61b2ef5ca042fdb808ffe74011b',
	
	
	 
	37: b'c9e2288bb4071f5b934ffe2f2dcd8790d448006',  
	
	  38: b'cbe4d965b4e06ec8d813b10875816d6797f3940', 
	 
	   39: b'ad26cf4ee474cb274c54a8dc8b2b2646a80f173',
	
	
	
	 40: b'21d19cadbfd7d938fbb55b4cb7e14cee083f2f8',
	 
	     41: b'4bc302678edb83e77c03d425c34aab78cbf8956', 
	  
	
	
	
	 
	42: b'6d6da4de3502c8a7a3a962b5246503ae08c6143', 
	
	     
	43: b'5bfdb20ca18776f6d8a29bbaf0276f9bfe1f2bb',
	
	44: b'9d346a8799621e82d398515033721131d65d7b0',
	
	 
	
	 
	  45: b'2f2cc1cd7fd76347c9809ecd5976c1ad1376912',
	  
	  
	
	 
	46: b'31f4702325cffd0a432bfd502db7ef0c38c056d',
	47: b'ad9116d84e23176855e89bede3af15ebb593260',    
	 
	  
	48: b'3f048038463197b6e3b6f142397057fd201f877',
	  
	  
	  49: b'24a3299bd500a829417a8087380c9a429241f59',  
	50: b'a0cf1d433ccd1511e563a4458f8e411b3309be5',
	 
	
	51: b'bcd65f64c3bb2f2bf69d9b78a8e03e635fef0b7',   52: b'1374aa2102b405848cd0cd56091ddbfaa5921ee',
	 
	
	
	 53: b'da07f4c9884b13621a91ed67b6e2d6ec4ccf96a', 
	
	
	
	
	   
	54: b'7da4a53b36703d2a75a928a1fe9e3931ff6fd32',  
	
	 
	 
	  55: b'ad7d000c2acf511f8ef54ca8af75c136ac8797e',
	 
	
	
	
	    56: b'5c502a1558ac2d1418abd97a3c9b4273eb7f4ce',
	 
	
	
	 
	   57: b'18a2d4989c47aabae56c003b47ad6c04c021a21', 
	
	
	  
	58: b'396abdf218ccc05ccdc29af4b207eeb66de92bf',
	  59: b'5e6dff2eff87ce19702ea8537b1fc5a3cdcf976',
	
	
	
	60: b'880f0732e65772fbc78e2ff4348ee64fa97560d',
	
	   61: b'b18bd35f131540e04185da8c755e8b9525d21ef',  62: b'ad2ec10517b9c450c40600c67da13f71040efe1',
	 
	  
	 
	
	
	63: b'4156e208214864cf499feb2a4dbd0b228c7f674', 
	 
	64: b'cbfbc8237c31e1b30db9ca239d3aaee9b2f2f56',   65: b'39fddb9354a0036b747b0b53a6860f03ee3a12e',
	66: b'6d56cee7f311639bc02d05eaec29909c90bf198',
	
	
	  
	   
	67: b'49e32718e83298ead8fd36bbcf33a73cd214335', 
	
	   
	
	68: b'30efc7f34ee450f18f9fdb9628bd967b948e188', 
	     
	
	69: b'f026d8484dcc8b980a9bdf1f59c76e2488341c7',
	 70: b'953a8381b5cd67e204c65f69d8c84381e80bb30',
	
	
	
	
	
	
	 
	 71: b'358c37951a13eb71d66a060fdeddd74293d65a2',
	 
	
	   
	
	72: b'cec56aa346e3eb6a57430f8933ee5787cfcfe68',
	
	73: b'ca82af8d330162ae132e116530ee3ad40405169',  74: b'66549d8049df77438dd582de703b234541bc028',
	 
	  
	 
	
	75: b'6c445e2bf9ae313fb32b6c743895ecce657fe22', 76: b'deff282c9e18b9736669f85f23a77654718a5c7', 
	
	
	 
	   77: b'07b050aa5587a4c50c37ca5f7edb3f3c359a5fb',
	
	
	78: b'c14d93d50e38a356252e25047dad2b725803556',
	  
	 
	 
	79: b'9b18f1bbdbeb911ce07e398a34c84b64dc26982',
	
	80: b'bb42c9f3f5085facbf193ecd7919d80f7c34e2c',
	
	81: b'543a3891dff99d511deaa936d5906601dbf52e3',
	
	  
	
	82: b'90bb9b5e41f58b30fdf33a52fadfaa89562875e', 
	  
	
	   
	83: b'178d132a5a143cc8d5fd2b626fa04568a9cee63',
	       
	
	84: b'4e6d8dca31a5a0a23917ab8dde889bfbc70141e',    
	85: b'b8e4addb4b7a56b05c90b53f2af09ab2af685d2', 
	
	86: b'31f060fb3d854283d92614b967739db11ed0e33',
	 87: b'8892556948cbb507ca3e40835d683cb16f8a3a9',88: b'1197e9de34f982c426d02501dd6badaeee82206',    
	89: b'0497e0c99cda53cc1a1211fed8022983812097a', 
	 
	
	 
	 90: b'2334c8bfacbf62db60f90a13ec6746ea1759d24',    
	 
	 
	
	91: b'5fbc84e421de0c3cbe763641a793e5bb7ccda4b', 
	  92: b'14bfcc4369051e1a9d21009d2f8a2f0eff3eab9',     
	 93: b'cee438b514ae7c1b6176ccaf7d77c222b893635', 
	 
	 
	  
	94: b'1439b66287492880641d8a347ee900c24597228',  
	 
	 95: b'dc68e494851f937f8d130e1dacbafbd587e0ce9',
	
	  96: b'8c9790c0858457fc7861f6833582065f0356885',
	 
	
	 97: b'998779d7769a4db7f0f724526d4b82ab7426181',98: b'5d23d765f4ba31f74804546095fd2b912739473',99: b'25ee69bdb51cfc1aab15bcb615955d80ae44a99', b'fcbcccefeafdcbcdbbdedacecbdbffbdeaaebec': 56}