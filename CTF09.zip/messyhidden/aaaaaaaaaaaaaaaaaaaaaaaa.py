class faceefdfafaadbeebddafafccdecaceecfddbbb:
	eedfbedcbefffebcffbafbafcbcddafdebefdec={0: b'db9d3c75fa62b5775073b25a6419f1a05948818',  1: b'5be44d671c2a9a55d720c4211ecaced504f3c2f',
	 
	   2: b'ef2f3c53d5b4f006a290f49631b958d889ba103',
	
	
	3: b'6c2a65314c486a7a60cafe99ab286463e440867',  
	4: b'80ae7a7b79cc3e1807f474aec5b7d3d607345f0',
	
	    
	 5: b'6e2da5ebcc925ea765f4a4ad552e5871dae3e35', 
	
	
	
	
	6: b'd272fa4bcd4aa7b3babf0a16cc8cea0333960ec',
	 
	
	   
	7: b'83b3288f4424a097315090430e726f0a5a91f77',
	
	   
	
	8: b'51f4aeb7a8a2e6ef56cb8a27c5317a467b5a273', 
	 
	 9: b'94be2cc8cd478f712cff8deee17fdcaca8488c0',10: b'c02e5aa19ad45e2db15c3e5dbdf0773ea378005',
	  11: b'2cdda297e5327dda9cc34adf1e309e253e02d24',
	 
	
	12: b'7746c4a157b3a32ffae3d85f30e25a2c57bda43',  
	
	
	13: b'a82ff4aa3521340995cf69d4c9da3296cdceab1',
	
	
	  14: b'0c5fa40f4577c122c048b6d28f80984a9244f39', 
	
	   
	 15: b'6eeaae8c19fca67fb19c4e346d9ba589c254054', 16: b'448023f7ce5d245c5fce866f20c384f009b0dda',  
	
	17: b'686a30002c8fc6ebb15a3a11671edcd38bcfd49',   18: b'b6b8139af599510ceb2cae2751f56ec361db757',   
	19: b'e003578f1b307f58e146dd6165b80881e0a53a2',  
	
	
	
	
	 
	20: b'8dcea58abf4862f0d396a9e83922b2eda8e16de', 
	
	   
	
	 21: b'b402a9a959b256f4180f9489eedfe544559786f',
	
	
	
	22: b'fe1661885212995c51ff2e97e67360e3b42580c', 
	
	 
	23: b'4dbf1490ff6bf5ad3e07a3e855ba979479b9bca',  24: b'cc64b345dbc4287a45ad66a9872f126356ba967',25: b'a96b03ed864d8cf671a3f185f017f102a3586a6', 
	  
	  26: b'062594f20728f7a8b457db3f49cda6dd69a978e', 
	
	
	
	 
	 
	 27: b'825aad5123f9fe336ebf28d625d2755ec7a26e5',
	
	  
	
	
	28: b'8f31d958f39e2136a77c6bc532e642dbe7aca1d',
	   
	
	
	29: b'91e99c31b34910e4c37bc5fff48598b3c0d65a1',
	
	30: b'161df091e05c3a06f9fe9fd1f83f521d924c28b',
	
	 
	
	
	
	  31: b'787c77f7e478be948654179cc4a4f7f5a12e4c9',
	
	
	
	 
	
	 32: b'b116378de7798162f8b1356a7acdb1bdd76063e', 
	
	
	
	  33: b'852656b1e687ca3d075ddccd8fe7bf84db3476b', 34: b'7eb62cf363477a68b3b7cc6768f8ac6dd6c4d25',
	
	  
	
	35: b'e5f7fa3c7b142384f6cbcbaceff9d38264a35be', 
	 
	   36: b'721c978f1ce66873d9863a0019011f153e16c54',  
	37: b'b65e393554457cbbe240f785eee51abc04f56c0',
	
	
	
	
	
	 38: b'8739d4f0aa4930416e515a1e128b75c41d94b3c',
	
	  39: b'86802b7facdffbd70f8b8e2662cc312a88aa096',
	 
	
	
	
	 
	40: b'eaaba3dca07921bdb0f37d3d4b6ef84e6408559', 
	
	 
	 
	 
	 41: b'ff150e93f2edc8eaccc9d2009bfcaa3fb0dd029',    42: b'0789d7461f5ed4b08cc7115b72a3fe049aa4dd2',
	  
	
	 
	43: b'5f9f75de8aa198af0404ac87461b489ea0d4f66',
	
	
	
	
	 
	44: b'063d439e0a5c03e20396ed18a948ffb0203e7d7',45: b'6e0911bc0b9702c46fc45089426b9858fca4812',
	
	
	
	 
	 
	46: b'b1896651f29d7dc6e88d1ec89ceddcf12ac17f2',47: b'8ac090d802e3070ad757fe62a045ba5d1179c0a',
	 48: b'd523a99804ef05c232f8dcc3e4e3ea50f9a5146',  49: b'9d38074db5c23c54e4edfd6d850a5d5d3988879', 
	
	
	  
	 
	50: b'8775722f7938b8b198f216cb043c1428b24e32f', 51: b'c87f7101e95d2a2c6cceba9a8bd93da14e8e17c', 
	
	
	52: b'5fdf276ed35c82068e1b55686ae7d3e3ced0dbd', 
	  
	53: b'39be1dc009a094ccf8138421c82029740fe8480',
	
	  
	 
	54: b'ac39d7392d788af5cd05acd093b988e2ade016a', 55: b'e10176b29278c904c63542dcdd0b0884306a92b',  
	
	
	 
	56: b'4c4af57c0014e09683105bfbc158821560bea4e',
	
	
	 
	57: b'1d829a73a4fa6ed8df575ecb46a6851147d5fda',
	
	 58: b'9607be36326c33280beb9681365d1907f3dbc9e',
	 
	
	
	 
	  
	59: b'dbcdce40b116fd41d8cd9bfcc95830a060c250d',
	 
	 
	
	
	 
	60: b'84dc7c77438a37398c65c83047c0aa41d58f758',   
	 61: b'd7bc105e1126fab643d2dee998e1e28eef43419', 
	  
	 
	
	 
	62: b'f33737f8b1a13fd16c174980833a5cdd4e6b631',
	
	
	 
	
	
	63: b'1f8701b18b415f013e591a6b00223f1caf20c88',64: b'55887da91a9a3db1cc54a39d870011c5bc83681',
	
	65: b'30a3c08ae1577acc255ae4c87ee6f6cbd508388',   
	
	66: b'239a7ffd6e61de154beb791dedd9bc6643510d8',  
	
	
	 
	
	
	 67: b'd15501d1d611415938514d3cb160e92cbfce9bb', 
	 
	  68: b'8950cc79d41fef468d0cf264b746ba3c2d8fce1',
	  
	     69: b'506dac7faf415bd8f5f607c1621c09cc8614af1',
	  70: b'9587a18459530f9634ed8f871a5b72c9eced152',  71: b'f40fb748b6fe21b1dcaffc09056ac32dbd4d4a3',
	 
	72: b'31efb96df47ee62a2f8427c388570cf9deed7d7',
	  
	  
	  73: b'2483cb8253d7ff77ce4a783de6c6ef6df55aafe',
	 74: b'410a1906c302dad53e74fed536ab1282b430fa7',
	75: b'03f6eeb8367263470aab7dc0a8543d91bc3a293',
	       76: b'2a29e55f1cd27cb0105a6e2e61c93302b6a2523',77: b'd5d065b951d39d3b002d5baf784cca23a7ced00', 
	 
	 
	78: b'd8773880571049ba2607d8750551d0961373f7f', 
	79: b'53ff85b8e4bb21894dd5407c137a6f358b6c498',   
	 
	80: b'ae310a3b791018ae4b77c3de6478c669bd07371',
	
	  
	
	81: b'b25a8bbbde972aaee523d7fcfbd6510d7f79990',82: b'0da4480096897bb5fc526fef6c9cc525b934083',
	83: b'81d3f29e50b9d950b2bd9d2f9466438806c236a',
	 
	
	
	
	 
	
	84: b'ea04eb4a68782f9b4e588df202817e38b093616',
	 
	 85: b'c157fb162ae2dd3ac993ab9559fc90cb6ac55fc',  
	 
	  
	 
	86: b'a0677397fa3d4a1752a5581e40d9785652e0fd8', 87: b'951f0ace6de7e66a03841d63bc4a81b57cb95fe',
	 
	88: b'96140a25b8d810fa5a34e65bf0322dde9890190',
	    
	89: b'7b3395b5045dc181f56c54da0b6d14ac2be2f09', 
	 
	 
	90: b'3c100ff3fae3f06f374fb941ced7d65a526e4c1',
	 91: b'7e7d96e81e74d1810df5170f06db24dd83dad33',
	
	
	
	
	 
	 92: b'5bd155291a4480d36f0633143e2912bec54014e',    
	  93: b'5e105f7b2cad6adf8c31710ce32064eff013dfb',
	  
	94: b'4534cd651827664e474b72ec8ce5ded99efd27f',  
	 
	
	95: b'92dae8f23c77557fc4114a9c99f1e04467139e4', 
	96: b'0ab0851b04c08a03c4efb5c3ea725bd5b7774b5', 
	
	
	  
	
	 97: b'e97ac7b7e0e12154aa62c6f81fe662de9b819b8', 
	
	
	98: b'8e8d9d5701d48346e2b00afaf1f895ca90f62bc', 
	
	  
	 
	
	 99: b'f339341650d92892a4a59337af672751dd07747',b'ddcebededffcfabfdbadbcacadeebdceecddfdc': 89}