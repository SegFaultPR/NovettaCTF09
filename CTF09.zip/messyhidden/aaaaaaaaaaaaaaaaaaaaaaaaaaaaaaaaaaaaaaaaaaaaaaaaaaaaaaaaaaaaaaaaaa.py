class beeeedeefdebeaaeafcdeafabeeeefdcbabacfa:
	deacfbeabcefdfecadfceaebacecbeedcccfcac={0: b'40ba26a600695d7b09e33feb0b7fe94c9ebbd2d',
	 
	
	 
	
	
	1: b'02978adf8094a97c30f8e129772a7a649c6c578', 
	
	2: b'0581a1e426a6d00c5a0059ffc6720fcb4178e8a',
	 
	
	
	 
	
	 
	3: b'fdfceae3b3ae48ef2dc33ae49560fb3668fd268',
	  
	
	4: b'4469b77fc0db43e377e5d903a83c41109778d94',
	5: b'21506198709f125b48d5eb3ac1ad00138ac3178', 
	 
	
	
	
	 
	
	6: b'ee88fa16918d9fb7abdc9ab36399224b24b6eb6', 
	  7: b'6f7e332648c3b26c3d77f3c8df18eee050ada56',
	   
	  
	
	8: b'202a1da57d172edc0a44f350042d3d48ea53c59', 9: b'e83df621c981bb3f3fb981019953b2fb0add080',
	
	 
	 
	
	  10: b'ddd41c5354021e706def56ce4f5a83b6e84b135',
	  
	11: b'a9f1318069cb44ce513842f5ef51c7bd7f7cc8c',  12: b'd9f248dd6a4781b3daa180d471a86569b2d4971',13: b'f713e1ceeb7262290830180bb7bc28d7ea72122',   
	
	14: b'82ac3cf8ecebc6040549be63e75976be9dcb050',
	
	 
	
	
	15: b'349f726e80aedb93271fa38fa2380a76a988ccf', 
	
	
	
	
	 
	 16: b'00446bf74d0d33d37fd9f4172285a944cd8ce2f', 17: b'75c52e3e480da411efa67f7f875f6d6aa6a6a75',
	 
	 
	
	
	 
	18: b'6feaa4594ea28b2e958e1119da54fac3ce7ae80',
	
	 
	
	    
	19: b'cb983d292d85535292aa2e0d1afde9fed7bb86d', 
	 
	  
	
	  20: b'5be9a30388d0289f861d3de9169ec5717341861', 
	 
	  
	 21: b'e3efdcce70c2fddc6ab3b0487d24e2316256882',
	    
	
	
	 
	22: b'4558ea57e325afbc9de7e2c6b881a266b8157c5', 23: b'3161d0a2919f67495de030029f1ce747fc705fd',  
	
	
	24: b'6595d48728e8bc3f8e2fcbedb166f2d18f7109b', 
	   
	  
	
	25: b'feafa18b93f6b66e5243ef79c48465a8c42ce6d',
	
	26: b'4614251d90e3fdcb2cb06c4c5dd112d14bf5ef2',
	 27: b'aad55663d3689c9e1d5844ad29383dcf0d130d1', 
	     28: b'57888b0aeb2c3fdf9f47fe643ee6ff67397700e',
	
	 29: b'a11591afeedd5a039871a29125354a8a9f6093a', 
	30: b'ee37b6ee8ef22207c6b0fc8a365e7fb3528ffea',   
	
	   31: b'743f72a88c401a8ea3881453d7a4eaf3decac59',    
	   
	 32: b'5c52d8d5d39ed09b5ccb3c58b7cb72665322841',
	
	
	
	
	
	
	33: b'9192a41af505a30f4355d2c1fa1ffc356994a90', 
	34: b'1c9011d9f149a7e12193fc91df24388db73a1c7',
	 
	
	  
	
	35: b'afc17058339b65de71ebffb00cc6fc8bd570b97',  36: b'45486a6a6baa315aeb2a69dc5abb8bce336f89c',
	
	   
	 37: b'205e30ffbd30190b568d29fa4ca343334d0638b',
	
	  
	
	
	 
	 38: b'ffd35d808e42ebfac54f648137e93438d4e6732',
	
	
	
	 
	 
	
	
	39: b'2905fa8fb44b0908b99168461519086744b4772',
	
	   
	
	
	
	
	40: b'6545c75fceca1680df2be9cf2706f321932ac1f',
	   41: b'3aff35f47d366d6ec287af0bd2e2f0d54c1f899',
	
	
	42: b'b904f9bab9a0872bbef4eb363422d93a47beefe',
	     
	  43: b'813c8c4e82eceebc1c587ee66743e715446260b',44: b'8c39e48c984d51b1f1736f29456b4f21bcdaa53',
	45: b'd4b5c0f890e24ea5ee7cfa64e4e0ceb554c30d9',   
	
	
	
	
	  46: b'6b2697d68361fc33947cb304b39b7c32d6b3c49', 
	
	
	
	
	47: b'47720149d5c9582899734475efca8ece99d4e0d',  
	 
	48: b'd2cc2db98a1c049a814683dee20ccc79847572e', 
	 
	
	
	 
	
	 49: b'ab737bf40b4cd4f39e0c424d5d2025593525e36',
	 
	
	
	 
	
	
	50: b'4574b4f28dd1c703bcb43ce38d6345fd2977347',51: b'd330416e47f091e2c78dd6cff5c22bb9e243f7f', 
	
	
	52: b'cca16f7ea0261ca076b3e2332d0facc3071e0fa',
	
	 
	53: b'3f1dbb832cb7642363f4294697631266aed1a57', 
	
	
	 
	  54: b'baa89e9677fc16a7d8286e056533886cbe45c78',
	 55: b'd18c990b709db24b4f69366373acc93f823e3e1',
	 
	
	 
	    56: b'538f78dd563893682dd6ccb5d933a0a5521188d', 
	   
	  
	
	57: b'f3390c3607d88ccdae2c65923692d1e1124a80b',
	
	
	 
	
	 58: b'ce065d5a48f26edd2679a8e4e59a95f529e92af', 59: b'64ab8e6901bc966b0f972d12706403984b249ad', 
	 
	60: b'7efc63905c5c472d378ae6515b2f93575fc7f5c', 
	61: b'ca8ce39a846d34a3fa57c6df3c2cbc237c1a51f',
	
	      
	62: b'143f6f7d2d59a5e8e0cf8920d1123e850536ba8',
	 
	 
	 
	
	
	 63: b'09e465b1f2416fdbba055c2c38b1300ec36209c',      
	  
	64: b'781ead5b3626ec815373d7e6c977137bea26d12',
	
	 
	 
	
	65: b'10bc9f3a9651736cad32496850c451a46685eb7',
	
	 
	  
	 
	66: b'4a9b5426f67a07f3223fde50df63d678d241423', 
	 
	
	  67: b'5ad3fc3ae0099c704b0595dfacaf7034908b518', 
	   
	68: b'6cf9e77d5ead5488d494b302992446b1d12c5c3',
	
	  
	  69: b'2296b36800eb97570c12a9e2fc293add76d94df',
	
	 
	
	
	70: b'b6e6512a40219d6537e18e55f442cd33f6c67a3',
	
	
	
	 
	
	 71: b'200b573eb896418d1d9e4d6e5b29c4a6b736d70',
	72: b'5953e9aee4784a87b79d1462e12068432db0fe4',
	   73: b'0f7526fb521dc7d50f0ac8151951debf5a6ce9c', 
	 
	
	74: b'025d57c6565a35ccee7f53b1a42b7e91442d01b',
	
	75: b'6e3590467c3e99e54b70f62763171f3b09263b5', 
	
	
	
	
	76: b'2b892e71b32f437d2ca27231ef370923d577d5d',
	  
	 77: b'8a85c8ae21d553d526d317b045d46da7be2c007',
	   
	
	  
	78: b'eecd1873a60c43d4eaef45f3dd91427ae1c4da1', 79: b'bb45eea7955e8adc2101ebc6a5c84b34b559d37',  
	 80: b'1e41777fd282b66eb3912997fc72eca53725186',
	  
	
	
	 
	
	 81: b'8a6df190732447db3640d8dd226902cb455fe23',  
	
	
	
	    82: b'f6620ff29e6afab18d5f0b6d338be99063ded93', 
	  83: b'c8ed22c846de2b85ae928526e31934479b19a15',
	84: b'59be6faeb9e1763f019f2e9ea6877aa5eca45fa',
	85: b'41cc9cb7b81e369ba98cabd384a39a29c18a3b1',  
	 86: b'cf205c08ce8e1ba8c2575335807b6503515d82d',  
	87: b'62f5d5926f938f1558868a9924b2783c0c62c48',
	
	 
	   
	
	 88: b'6cc3f689c4de5857a40b50dc5ddd20e412d08d9',
	   
	89: b'3ab0c923f535bc905afb42b386d1c99433d2857',
	
	   90: b'9d85104bb087761a9b75100fc51b519a743d98b', 91: b'264a05e2f1ebeca07eae534bbfddd0ad8f28ba3', 92: b'1f4b4ce593b7227556b9c2fcba9dc045d1b080c',
	
	  93: b'e46f71c6e96fbcb410ac32bb2aaf8c1657ba26e',
	 94: b'ef690fee107b57b5af8a21509959903f7644790',
	
	
	
	
	  95: b'e5d46189211b8d2cd846233b457d63f04943641',
	
	
	
	    
	
	96: b'9124b9c03a4e6bcb1cd7db72b5d1ec33ee97efd', 
	
	    
	
	97: b'3e5e71f02e995ed9a0c62ee6c37d0bb814fc2cc', 
	 
	  
	 
	98: b'8b80f63845a2ff4f746517ed8090cba0bed9fe3',    
	
	99: b'b8121200b23bff880da6ddb24e10551477a0d2e',b'beefedaebbcfaadecaaaaedabcfcdbacdebdefb': 34}