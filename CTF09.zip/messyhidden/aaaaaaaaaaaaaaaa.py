class ccdefecdaefacfdcdcddbcfbafcfcabaedeceaa:
	efaafadeabbefafbdcdafebfebdefcaaccfdcec={0: b'0a7861fcc1a4c65b180d2daf50bdcda3d97c2a8', 1: b'd9da746a2efd0b2ede3b029a3ed689e40c7b687',
	
	 
	
	
	
	
	
	 2: b'b3f7c6007db3a83c75c0bc034528529a4ed911a', 
	
	
	  3: b'80446806957f6d5e1f5d12ebc6fe9ba74f9ccd1',
	
	  
	4: b'8d082029fe6c8867797a972a87bed4f7df52248',5: b'95fca4579c92e0fcef7f5cbe1cd1b3c2488b677', 
	 
	 
	  
	6: b'371a4861d43856f08c3f0ff7d701c7926f78417',  
	    7: b'592e40cd503a33347e630ab875ed7fc9da30c61', 8: b'd1fe7b2aec2407f78751405176e92916445478e',    
	
	 9: b'5a9f9c0cae509e7d6ac22ffec91e5f9ebba4a66',
	  10: b'cf3a47dd0a02323cdf558bcf803f39f1b06ac0d',11: b'971c521f13f27d15926f4f8d100968877edc2d1',
	 
	 12: b'b96a60c1b832cdc7703e3c9698d630dc9ff919c', 
	  
	  13: b'91c5c086e7bad62336aa2a4a74e3b50a8e56d20',
	  
	14: b'29800272ffdc44401202745d0c56d8a65f3da01',
	
	  
	 
	
	15: b'1ae2fa9d8ce2fc2a3c7ab4eae2f6bfbbf23d638', 16: b'820424488204204112242041122420411f228e3',
	
	    
	17: b'df3957d7f310fd0ccd711e99208cd86eba61e9a',
	 
	18: b'1790bb11fa9dcf5c29020b30e9957bc39e645e8',19: b'e75ae5df75ef6c26c499f8100b5d8d43f5ebeef', 
	
	       20: b'e85ce52c1287977ec795840a222a3c378861e7f',
	
	 
	
	21: b'7723fd630d38f87153188f81ae8d31b1af383b1',
	
	
	  
	 22: b'e91bcb5408c92d7f957f31e92a021728c6375c5',
	
	
	23: b'd30d1e0508c7d34ba65b277bfdd180d880920e8',
	 
	 
	
	 24: b'd56009deddf92ad94bfb19bd153de7577b5767b',
	
	  
	
	  25: b'bcf2b021b12a8f6d86f790da930b3d5f8fca8b4',
	 
	  
	
	  
	26: b'2909e39a5b0705c02c6e9d731514d615789be61',
	27: b'16b9b96c9f3b1f346e5295ddd70c8870c845c5a',
	
	28: b'8b93feae9d70cf82653468c494820a1af4dd0eb',      
	
	
	29: b'1fc00d940e8591ebfa9c7ee38745d7abe89ad14',
	30: b'1609393991fda246bc0cf7c1cf07527fc37e35e', 
	31: b'5e383dff13329e7d2cf57fa93112a0e2fc3c962', 
	32: b'103f1f087d5a507506b3ae8ebeebae46517d11d',  
	   33: b'9ebb8c0a3ac32717e7d6668a9e14d8acf8b93b2', 
	
	 
	
	34: b'9f643ff709f6be0691f415fe7e0c64e1b4b9061', 
	35: b'7d9db3ef0a3e377491108dd7999e67acf76439e', 
	
	  36: b'e044f14a6addd0e4d49dccdaa396aebca4c410e', 37: b'50fc6ac9946e53cf68ad9b5bff2131717ca806c',
	  
	 
	
	 38: b'9f2367b7a7ba4260a25352fe29db2d4f1930c0e', 
	   
	    39: b'29d4ed9001060b17ee646790856284bcfde59b6', 40: b'9acaf0efe0eb072163ee35e50510cd3c98cc075', 41: b'816284c04e93c62dd5b5bf1d69868c5dd8fa66c',
	
	
	 42: b'34304c674b58c9152b8cf243b4dafef775005f9', 
	  
	
	
	 
	 43: b'3b9c2365846b5480ed66d96da4a225d6e648056',  
	   44: b'0f0f30449f8b5d700569dd67da21dfff6bd9efc',
	
	45: b'8b5b326604f7cd08ce04197dd9bb343ba6d90c0',
	
	 
	  
	
	 46: b'13f04a4f2f76a2eec4fb51712012156b3f9ce3b',
	
	 47: b'752b65c6d43cc88f16111089f3e22b2b268ff0f', 
	 
	48: b'4ad13ccef052e80bc75a9733777d95f4294ea90',  
	
	 
	
	  49: b'c51944dfe9066eb56f690631d0a2ddb02c75acc', 
	   50: b'836e04b95f97c88a4525c4c830cedc0372a0268',  
	
	  
	
	
	 51: b'9db41eac1cb29edc36afaec408584aa27c86915',
	
	
	
	
	52: b'f37bdbccdd6c6f621ecca2619c5cc6bf54d12e6',
	
	
	 
	 
	
	53: b'985897b41f8647db6e6060b8e11d4c74896764d',    54: b'958d883809db163b58a8533b2f00bed61193bf5', 
	
	   
	55: b'a303276b2103fc12f142a213f955bc04c4ffdcc',
	
	56: b'27d17b2e2e957ee1142fbbe0a422eb05c76cd4b',
	  
	 
	
	 57: b'd44aef646c07525a4a9a3cddd39e91f6c936ec2',
	  
	
	   58: b'34c68ff5b7c4b057fc212ab4ea4728a11eda845', 
	
	
	
	
	
	 
	
	59: b'0af72d118702509b0dcc1558d401ea7b353f746',60: b'247b78485c2854ce4be26b847947262f49b154f', 
	 
	61: b'5197adeb8b03f616ccfd5811be36d87f848437f',
	
	
	
	  
	62: b'a732cd38f02943bf097dc21dca4ebfad60f7de0',   
	63: b'7eadcf30b5a6e62209e7f78577a532197eb2ff3',
	 
	64: b'2728ad968e21d0d0824d3ea6811d773d8d5a5ec',
	
	
	
	   
	65: b'37df3a7aba897eccf82fb7982089a5085406700',
	 
	
	
	
	
	  66: b'84cdd34b5ec867ddc1e57377778ffca0dd17854',
	67: b'7d7439169ac7abd27781bad9bfaf217e4ca17c7',
	
	  68: b'ca9187336353c96f63d32c28e6b6043493f955c',69: b'2fa5ddeac1fd7b92037140cb7f0639d7b9ad61c',    
	
	
	
	 
	70: b'9277bb9ac24989ce4f3052cd4dfb03d4966209c', 
	
	
	 
	 71: b'd532342821ab6365e9f9b77bdcc24f9b663a16a',
	
	
	
	
	
	  72: b'587e036a913956f6179098f13cb85bf13e4fc7b',   73: b'a72716be486c4e7e0ae84163f56035bf300a830',  
	
	
	 
	
	
	74: b'6d828cb2b27f2676bc3303531cec7c57f06ef9e', 
	
	  
	
	
	75: b'a173b3f8dad06ea1905b7bd587b7b0b63043c8b',
	   
	
	   76: b'8c616098bcb7ba2245f90c42ccd8149082e0f72', 
	
	 
	  
	77: b'bb15c39f3046c754b7838f533af2c9e82c3630f',
	  
	 
	 
	78: b'8117d6054122f3d39f9b27a195db29155cd610b',
	
	 
	
	79: b'0bd272f81cc48f074d166614be20611a6f87e00',
	
	 
	80: b'02fed2e8207391a04e5e475be8cfa7f74bc5e92', 
	 
	
	  81: b'ad9f965a8ec99884fdc1457ee5e82b5e82f770a',
	  
	82: b'f3e4a0aa2554b0d95a8cb075375bd26c3702be6',  
	   
	83: b'd929306ec3de03ebfa674042172b3f8f58b5984', 
	
	
	
	   84: b'6109c5d4cb279fe793ec7f00c4b21d9d7efa868',
	 85: b'db89bdde803cc641826fb53d2b614c89f7f6ecd',
	 86: b'e373595f7d714074bbf9a131e725100d226c49a',  
	
	
	
	
	   87: b'bad148931633598d0274fa9ee3f0f6c355c369e',
	
	88: b'80d7a06eca95e9ceb889d5f0bc1daf0c8d67630',89: b'222ee57377b4a62909630b24a389cdc77a517e9', 
	
	   
	  
	90: b'57b4abe15a666f9291fd3b5cbef5c119f056761',
	
	
	   
	 
	 91: b'0dc2af76367442e59d6e2c199f8bb10bdbbb26f',
	
	92: b'71f059ca666bcecc2ab6bb1165ddf59b97adac8',  
	   
	
	
	93: b'1825aad9b9548c422a2a47920cd3541c454f275',
	 
	
	   94: b'27b9c52a2ad1dcbe00b54cda4d6c3ee91a0fe02',
	
	
	  95: b'7eddc6dc1b6625e3b5a893e8ab9edb66662ed38', 
	
	 
	 
	 96: b'fc6590d0489077e77df94abd6aa0ad77dec3c09',  
	 
	
	97: b'b782b9ee6cfbbb9ef1cb78a7e396efa1f453d03',
	
	 98: b'61d8aa0e4af157340ce15522449b0d2df0186fa', 99: b'4efc2fa91d10d991240adc61a82c871abafe470',b'bcffbecaccdceefddfafcfbcedbccdfeafdeaee': 16}