class bbcecabdeafddebeffefebabdafecbfbceebbfc:
	eddcabfabfacdcdfddddbabcefabcabcccddfbd={0: b'af5cef30e7e748e5bfdea41cbc09debc45cd765',
	 
	
	
	
	  
	1: b'df24648127e24616657e12ec06318b7992cf490', 
	 
	2: b'bf52821a75e38376e3f0049db5c0b63da04f4ef', 
	 3: b'95d160d645f232949758387641e0d24e490ade6',      4: b'bf88868fff0c3a7171d9d23a5f7b1de99acd0cb',
	
	
	 
	 5: b'7569c41e8ed554fe39b350e8b6ad1f1ca07426e',  
	
	
	 
	
	 
	6: b'49ade2162adb615058be83a45ceda663b2a110f',
	
	
	  
	 
	
	 7: b'd5eb2390cdc9acca1f4e932d0602352e0d0289a', 8: b'2ea6b3bd3452ed86fcc9502fe69791364606be6',    
	 9: b'972e4d2d4429f5078f75bdd677da9e9ce53e4a0',
	 
	10: b'9b64779f00387b6611115ca99c665c21a14b07f',
	
	11: b'58bd4427436a4776de04c3a6c047a8c357ba23e', 
	
	
	
	 12: b'606da7def8a0ba04744d79ecd771de952add39c',
	 
	  
	13: b'ff2b131d6490840cab6477f0e40a898a6256236',   
	
	
	
	 14: b'7fdd10853ba0e5816637076aeb0210c089c6f07',
	  15: b'637a9d8fc26cfe5e3ca6714a80c085b22e4fd2a',16: b'fef70b9e8b90eac1c4edd6672702b658d4f98c2', 17: b'45a24fbbb67be82f474c22caa113b69ce09a273',
	 
	 
	
	   18: b'4ef39be641721512dc9fcfe1ea42086f42cfbfe',19: b'b6634113360973eb4d7cecc5b5bdedeea394039',
	
	  
	
	 
	 
	20: b'72bdf944c42e17c0c9754f9f13d47e34d4ed692',
	21: b'0783e017e1a720664b7984c6998105b9273a922',  
	
	 
	  
	 22: b'b65b50239c1470a44e3fb3ab4f92ba19f5bb2d8',
	
	
	 
	
	23: b'd9c689d410b70894825d6a60f118edad13c7a69',
	 
	 
	
	 
	
	24: b'd0dcf9e87d6ba4902fa8e49fba2042448820424',25: b'1f59c228e2de3b6f3b4570147734dd2141f1868',
	26: b'fb5b63fc26c53247bfac0bb8e973ceeb483c6af',
	  
	    
	27: b'd373c053cc89eaa4aa9e7b3d7bbd91b7b25a936', 28: b'f034a4031a47bafce5b7ede279c745ad39a6d55',
	 
	 
	    29: b'eaf0e26550ba05d01a3ff127d7f015a05be5ba9',
	 
	 
	 30: b'be17d297e53c358a402a1ae3364af5595793c56',
	
	
	  
	  
	
	31: b'49264f80dc8c38b4a4f588d618bd91331cab254', 
	
	 
	   
	 32: b'76b09cee9a7846dec19cf92f145b7009f7d4c95', 33: b'ae67622774d92f1d0cb87084cba3a9ab13e85ac',
	
	
	    
	 
	34: b'd0285b11e5d172ca4741ee1224de359b6eb123d', 
	
	
	
	
	 35: b'8206e0d62287f10608c8a08bc8a5c23a88f7c53',
	36: b'a7ba977fc800718cc57240ab3f424dc56a62635',
	
	     
	  37: b'0a0845f5b13d093361a8d248d39cdb1154cb855',  
	38: b'd407fa81d295d9def3a0f4999140c5e8c991a5a',
	
	 
	 
	39: b'5a5077988416e019d134f45411ad02fb322ed25', 
	40: b'f53d8a285df82c230af790f0013e707c30f8d18',41: b'5229f07c70cc6360ea87dadef6d8bed9613e9f4',  
	 
	   
	42: b'fd1086ffe4a5f2513b99e4f0b12588393360ae3',
	
	  
	  43: b'3d604bf407df3cba5a2dde97aa8630b7e910fb9',
	
	 
	44: b'dae4c410c1550efe97dec20e76d9de3a16dd65f',
	45: b'01e82d289b4941e37dacaa945b15377c7eec97a',
	 
	46: b'bc919cfaa91c14cbf64e918b0bdbaf7b15127a8',
	 
	
	
	
	  47: b'2cf25be2a23a07c3f215723826cb8924bdc1422',
	  
	48: b'ef26a23057525aadbde09d66a16de21a32454e5',
	
	
	
	
	 49: b'1f085e3189972e89fbe2c3b1e7f64e7e1ee93f0', 
	   50: b'673f343292ce4c4507f7409f343efd428d2c57d',  
	
	    
	 51: b'88659468334f4c0dc205f3c04fd640da9d61cdc',  52: b'8527ae6deac93e4ff544e9ab96aa68423843ca9',
	 
	  
	
	53: b'd322104238f492f18369fb4884ecbcf30114905',
	
	 
	 
	
	
	  54: b'2164e7aa92a0d13e90d811eb78352f782fb24d8',
	
	
	    
	
	55: b'9d3379fe80ee8d472dd85a6163f1363918039fe', 
	
	
	 
	  56: b'13161f54c0d07eb61caf83dabf7247f0e661a19',   57: b'c9d3873464fc88501ae6397f41e479ab2bff037',  
	
	 
	58: b'be6c9354133619c44b2968401d88120a7bda055',
	  
	59: b'02f67a0bb61f15c0f7a1a35d36b849964df8d37',
	
	
	  60: b'dfef838f85f7f29bc7cd4b1f22315a4fa87b18f',  
	 
	
	 61: b'a3066aee526cca05a7777ad6f649d698be2dc8d',
	 62: b'ef4ba6084847f1617e5b1dc9c81b98f4b57ee50',63: b'f4f59c2f63e8b1ac2b383c819f08cb263dacd76', 
	
	
	 64: b'af6a31edcf0f095281d0f9ef48d2985a85f6950',  
	
	 
	 
	 65: b'53be55c9e2224b214a24de16ae765a2ee73992a', 
	  
	
	 
	66: b'b9882c31bdf6f8a5571b6fb8aadd9de8ac3eb7a', 
	
	 
	 67: b'7eb2f966af55d8bc6cc9493b6482bb720d2cdc0',
	68: b'38ab86e60d5f89dce9f39d2e89b6cb3b7932642',
	
	
	 
	69: b'6ddf2afee146f6e5455c35eb1cd34b37ce301f6', 
	
	
	 70: b'4ff5679e42c2b804ecad4d4a88da821e4992c56',
	71: b'887eb758c6cb11e2278cb68ffe0a1b1f7e55d42',      72: b'699e77084f1d39d3224009f26b8a3e3cdc0dd3a',73: b'099043c1be113c0c5028d31287eb6680d106c8f', 
	
	 
	  
	 74: b'139e027c076c3ad42854f880b0223f6fb19ed17',
	 
	  75: b'04e33ab3c2fadab3e3945173ba506eb88affd3d',
	
	  
	76: b'1ec4270c70cc3dad3c21685b564c3aa4adde44d',  
	
	
	
	
	 77: b'746f15f838c43e12f48c481238f2fb69b27a94f',
	  
	 
	78: b'46ef60515665f70ccdd0ed8223833f9657d1eec', 79: b'5e9c01731736987f6284856cced1434c1602d8c',
	  
	 
	
	
	
	80: b'3d12e5ba6f666ad1057def8103b2269f338e661', 
	  
	
	   81: b'f4d3858cc57831bd339f55375cae5e04286af8c',
	 
	  
	 
	 
	82: b'c4fedf8cfc035612b74d636fbdf81d1948d64d3',
	
	
	  
	83: b'95ae10eb51cd5bb2a73690f8c33569fce22fd76',
	84: b'11bdf23412ef7048d6cc6e5e113d5a7bbf7fa17',
	85: b'723ff4ca794cca2a4fe2d3534822071a1bb6100',
	
	
	
	 
	
	
	 86: b'0244a85e0600617c463b101a59b68356f78fdf5',
	 
	  
	  
	
	87: b'cfe9e526d3b2b6aa8e021cc4ad6c607273d43e9',    
	
	 
	
	 88: b'b08e3574ae3d17fffdfc52a41d31e4234ae9423',89: b'6655599ad9901e64663b8c2380a6cf958b24892',
	   
	
	90: b'550261fc412beae7196a7e44615945597a14263',
	
	
	
	 
	91: b'2e40b5a675ca260115c6e92886169bb187aa5c9', 
	 92: b'9eab707c54ac98e4ea0b5a8b2fc1f01a1c6eca9',
	
	
	 
	
	
	
	  93: b'c1c02d01e662c8c9467b1ef65d6c929757f4a4b',
	
	   
	94: b'afbd8727f4243a4a1fda5e911355217169ffc25',
	 
	   
	 95: b'8b4e3d7428bb1d71901ceb4dd8bd7b045320585',   
	 
	
	
	
	 96: b'ec98a503e5608c3efe79613b07980bd4d343ca5',
	 97: b'f5464f95b8cc1560c899c2d23c159d1ebe49163',  98: b'ef16d13982d193513c857ed3c2df17a447f5033',
	
	 
	 
	99: b'227a9a1c46969e1e30d3044284439917237ea2f',b'cafceccfcdfdafcbcbcfdddbdfdbdbbfbbaceef': 24}