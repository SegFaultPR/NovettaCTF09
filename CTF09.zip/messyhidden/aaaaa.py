class ccbbddfafaefccfcbcadbdacfcccceeaeaaccfb:
	aebafdfaadcddabefaefeabbcedbdfaaadbceac={0: b'bda483621dbc885aa52189cdd867f0b2878f83b',
	    
	 
	1: b'3d0b916bc8da05e0525ebb17a089400436e4f07',
	  
	 2: b'92c8b1de8dd50dfcba51af0fcab55919f50cef3',
	 
	 3: b'0d92f71f53b6f753fa8d3649dd9957206cf339f', 4: b'13159e910a95895153f4dfd7cc69d48c108303d', 5: b'788b45dee87d39301d5a00a3c3df79eb1fb25dd',
	  
	6: b'14a110789dba0f0b668a325259026311eee1897',  7: b'6efec0aa77600dad7020097c4dde47f91523a9e',
	    
	
	 
	
	8: b'4d4507e3011100192ece177e110000001974455', 
	
	 
	
	
	
	9: b'08ca8d9c282c71c7df9602853daa60bad64cca2',
	10: b'823cd3544ea38abad6ef3bec3ed7f6393799cc6',
	11: b'ea9c34f45b483a44532348fdc138db5e3e455ee',
	 
	 
	
	
	 
	12: b'e7b4fa3b71638a6fd50e1a1df1b7619203fc4ea',
	
	
	
	 
	
	
	
	 13: b'e20e6800dec68a8920447f78f17b0d1e8e0993b',  
	
	 
	
	14: b'fb3514a526fbe1b0331417b15e9e3c306c67b2a',
	
	
	 
	  15: b'4dc080260959c184c8bc9c2f1b0954369f554a2', 
	
	 
	 
	
	16: b'6f3ec608e4917b8555b04429d058139eb26b74c',
	   
	
	17: b'a211b27ac27e80a8d7c5d19ccbc4d85657aab85', 
	 18: b'3dfdb7f341ebee9b8beadb11dd303a5efe36fb2',19: b'01bfcb5bfc2e6472761b6a6bae70eb0973f176d',
	
	  20: b'ccd06857bd03d1ec83f427a04be4c70a45c7573', 
	21: b'b901d33da46ddd76f5fbe182c908bf503362843',
	22: b'dde293d72427bff8bb6dc681b703c4406e1f0b1',      
	23: b'e27a76aae3cc3373a01421252b5be6829eaaa41',24: b'2daa9657ba19c9377086a7665b969bb6d95565f', 
	 
	
	
	 25: b'030ff21bb2084f191c368a338be8844f2203839',
	
	
	26: b'968bba56b33f06619efb18e96de2f449735bdcb',
	  
	 
	27: b'e50e23a4f3a2ff85f01af3adec8f92732af10ca',
	
	
	
	
	
	
	
	  28: b'12d4b9c0ea4bbb68379e61e9b241d1d988a5367',
	  
	29: b'f945dcdb3e4ada0937e74b8a868a81d893d4664', 
	
	
	 
	 
	
	 30: b'54865a04d9e7a11e51d0935e36fbac142affeae',31: b'e1ba2b9bd0fc754a082df329997a77876526124',32: b'cfca82a63a38cc5bf52eeb7c2cba76552c117b2',
	  
	33: b'55758228c335137fbab853dbdca8e0a563598c7',
	
	 
	
	  
	 
	34: b'621bc7c3ff34bd3237476e3ce72d420b302bb67',
	  
	  
	  
	35: b'906bdbdef1643b4fbff4fee034a59cc5fbb0ab6', 36: b'1518bc1941ed4e69184fcf8c3cff8fce6ab659e',
	
	 
	   
	
	37: b'82f3ca590735f67e80a725ba4e6fa58e9588a4b',  
	
	
	
	 38: b'5fe112ff8102b2fd49135f7e29d382445e64da9',39: b'7541152fb8336b78b517cde2b8c6968ce44e655',
	  
	 
	 40: b'1dba3dace51f31ef41c023436061284fd31b58d',
	  41: b'3177ef35031adf39adb90ae9db324cc5a781ceb', 
	 
	 42: b'2bff8c4ffc0955ce6fe140174acdee46a85e6ea',  
	
	 43: b'ed5ccd35393434f9a6bddd0f59909bcf538e298',  
	
	 44: b'ccd3f63bc395f6fbd8430105aee004146ce4d39',  
	45: b'a46ff6324d9881cc38861e66b0966381eaab0ea',
	 
	
	46: b'5c88c5b8e4a36b867acb6c0f9d608fea961aa12',   
	 47: b'55c11affe54ec041c08b06dec124def37cac565',
	
	  
	 
	
	 
	48: b'39d881dac0b5c8c885bac5aecb6df80fb52d44a',
	    
	 
	49: b'ce840fee5d8f5f727855bf715ef5a11886fd0e7',
	
	
	  
	50: b'efd3de0720b9c9cee1e71b2fb1f0474732d67d8',
	
	
	  
	51: b'66ecdca270d0cef61127dd52a0573ed19e624c3',
	
	52: b'fd59c5dabe3b4544121ab39120f19ac79a2b084',     53: b'302e0e5d7d8d9012b4d710c7a8e11b52577c1f6',  
	
	
	
	
	
	54: b'f0d6d293edc196186e24696cd3010f97a7a5237',55: b'ea39e919cf199759839e351477632120128af1f',  
	 
	56: b'555e48300870a2b9fd061f0d98b76386898ce52',
	 57: b'2073a51600b8dafd6d1fdc50e56345f8cfed24a',
	 
	 
	 
	
	58: b'dc419cf80afe6bce7c826f7eb4da623f73deb9c', 
	
	 
	
	
	 
	59: b'069c45c0a63ec77ec0e40c154c3cf50da850f01',
	60: b'dc76a9528a6e0a1d2d2affce2ca2a99999daca8', 
	 
	    
	61: b'4a6143b163e1158b9b8189f34534fca47212b64',
	
	
	
	
	  62: b'90b1d5b3971a3b4793dd3cf1652e26adcc32890',
	
	  
	63: b'51e613eb03bb3f4b7bcf03ce42a69c4bc32ec0c',
	
	
	 
	 64: b'1eeefc9ce3bd2e81518114f8d7eb136db4f658e',
	
	
	
	 
	    65: b'7c0c68da30d2357bce2832a3d59917703df21ca', 
	
	
	
	
	66: b'd477c926f25ee317171fdabf99598b56c464f91',   
	  67: b'81ae9be0c8d1b8a9363cd6506a74b3320de646d',
	
	
	
	68: b'f4ac2529afd3ea154c8dbda8875bbd714f81164', 
	
	
	 69: b'f40c84a750ebe9dcac118b5a4f6e1331f7bfb61',  
	70: b'1efb6ac5db1209db5f342c1518d513d2ca162ee',  71: b'58c81cea608dc5aca4612069bdb656b70780880', 
	 
	 
	
	 
	 72: b'9fc074e0b381bcf2562b01d89468ea922d77580', 
	
	 73: b'3f3cceccef251157f151212cb468064e2df1c81',
	
	   
	 74: b'53776ef9976e67a4a263dadc32e5c726d2b2225',75: b'226081d1a6bc245bbd46bceb426844452347ca3', 
	76: b'070fca5d63920610f156b057bdcdc87a535c57a',77: b'205de6370703a58413ad8fb07bb6369be2fb11f',     
	 78: b'87aee73d9e32d4c07d971e3dedf08499a00f903',
	 
	 
	 
	79: b'1e33f30cdd3ad737e5496fb1dcc466760b92595',80: b'605ae5033c2b829bbf48a3280d5802dc429427c',
	81: b'3a2c1a3bbe66ee03dc658d1832e8b0b51d44765',
	   82: b'21f6f8b0d8d766131ecc60ef134439f94f1d4e2',
	
	
	
	
	83: b'aa00cdfaa93a8145056e4394faf169e9a3fc4fb',    
	   
	84: b'f61217ec73a54119a6f64fa71595d86684c1ceb',
	
	85: b'e8e4b67526be7b2795fe6356c8a555bb4077e07',
	  86: b'abcbe0b84e6824e632a073e89298c310e4b22f8',   
	 
	 87: b'fce923be14a4e2dca21f6eb696cfcdcf31ef6aa',
	  
	
	 
	 
	 88: b'ccb66bdb55cc0a8aac2d40ce39ebf10800473fb',
	89: b'72f4b3dedb9b527e871886c95ed0be59dffb3a7',     
	90: b'27abc040d678aa6b3e79fafb75f93acf4102c54',91: b'eaa9fa510b383e4bdb201262c3f9105ee91dc85',
	
	 
	92: b'7dae49d2926362d95ba0e05040e514f38ddcb23', 
	
	 
	 
	 
	 93: b'226906df155d194fd458920386f575bc2032802',94: b'28e66710c1bd01721b58edef5c07e11c6a518c6',
	
	
	  
	
	 95: b'd2881af2b0dfb4546b61fa8924280641dde81d2', 
	
	
	 
	96: b'66268ef3deab7a6fd1b1a286808634944f9fde1', 
	  
	
	 97: b'823c760fc9b2952a4291e273305eb6be7f90530',
	
	  
	  
	 98: b'4d5e24853c7fccb9ef366f0d84548154f3ac3a1', 
	 
	 
	99: b'05800843279de03e54d77aa03286eeb709665c1',
	
	
	
	 b'cbdcbdcfddbaaaabbbdaddddbffdbccecfdcdba': 8}