class febaebacfdbfdadcbeccdbafdecfdfabeeccdcf:
	dcdeecddfaffafacfabaefcefcbdcbefddcdccd={0: b'c147923b66ac38e7b2430bc3dc90385c93cf66f',  
	
	  
	
	1: b'383ba5e682ce67f04a6c65f1265f52459885602', 
	
	 
	
	 2: b'779bcc8e6ee33244ea494631cb235b6b041a517', 
	3: b'd4425155b45bb7fd2f07c6d8401e613037867c7',
	
	   
	4: b'4dc7656c1d52ad740a0d3e42cd4586fb42be153',
	 
	
	   
	 5: b'68e177a0fe09393fe52f3c91e7f8e1ba02b0726',6: b'4a06219dec43357d66df77bf21062dcf1bc827a',     
	 
	7: b'62d48467d438547ee792ca5517bf4be42f2c81e',8: b'b4e5f2d2f871a0aac96d053c617f52f575d8374', 
	
	 
	
	 
	 
	9: b'd6561b701aa6e62d92cd8b7cc79c98abd127ba1',
	
	10: b'd794291c50945ab7715445e46d14bcebaaff103',11: b'bbf86bdd8028fdcefb4756f2764e6d3804c54e2',
	
	
	
	
	
	
	 
	12: b'561c7c1ea3b6f0c057b6e776e2eb0f6de767d1c',
	     13: b'b28b1ca8e2a62df5465c8b3fd372a3cfc60e5f0',  
	    
	
	14: b'df2aaa3f3acd4e457fae2285934151150eb88e6',
	 
	
	 
	 15: b'7df95f4cdaba473e649814ead6fb7bfb5fc12af',
	  
	
	
	16: b'ae01e7c18239aff5f6ca2b98f4ee4d5129aa419', 17: b'0000397df0c3d0cdaea420a24776b2eaabb08db',
	
	18: b'dfd4963c38a6102f99e547dc8a64a34799a0cf0',
	19: b'b30430415dc645c395f64f92befc05b5a50c22d',   
	 
	
	 
	20: b'e86c3625019fd6103a969604888e9d441ea0e31',  
	
	
	21: b'01e3a794ad027e113e28da0cdd5eef6480a9bde', 
	 22: b'7c3c13bab68dd0e872f3859a71cd0c9ac9f51e8',  
	 
	
	
	
	 
	23: b'1315a87abcec544cec4b5667975384079cc19f6',  
	
	
	
	
	 
	 24: b'ff54277baac62c42b8e6ed6b24c316d390b8776',25: b'f6b8b586dd6a4cb9111991110b9dcccb058260e',  
	  
	26: b'c4c6fed1f126704fa7d63510c87c73e0a8078fe',  
	  
	
	  27: b'aa3671412b280481299f2e066e88f8102f17e87',
	
	
	
	
	 28: b'0a8d90ffeaa7b929c671ec080d5ee8d22df7bf4',29: b'92e727a9a9673e371aa77267572f580ca089cfd',  
	    30: b'bc3b4c5fef85fae8736b1ca3c85f95a1e362b30',  
	
	   31: b'a072f081d2ba031792ea666ebf261fd87deab37',
	 
	32: b'd96bd80d3fe2a75620a751c983def4493daa72a',
	
	  
	
	33: b'56e0d13d5ca6a1069633ffac0ee3b8c2c3a07c6',
	  
	
	
	   34: b'333137660b851eed16e109c90d477a71447ac9d',
	    35: b'725dc9df1d1e071fe790b2567c07fdb7a54e0a5', 
	36: b'2fa2c5ece80f462383b5ba9f0307c91c02b272c', 
	 
	
	   
	 37: b'332895970571f641d01732d1eb4a92465a1f8d8',
	
	 
	   
	38: b'8437925deeb3067bc495ecc9fff355f1ab8e5d3',  
	
	39: b'ce9346791996eddf2446a21ec0e996fbae00627',  40: b'4763425e9c5bdd52915a41104d4d07268a78d91', 
	 
	
	
	    41: b'c877bdf915efde6be7998f0ec01fb9628a95ccc',
	42: b'9cb9aa732cfea37eeeb6c88016203f866c37148', 
	    
	 
	43: b'4770368bce975a0abc9e8c90806fb0b46a4b8c4', 
	  
	
	 
	44: b'18091c06e4925cce829ee7168c9f48961eda411',
	
	  45: b'2eb41ebafd3a9d2a1d08e9f33fccaf1cfaf36c8',   
	
	    46: b'dd5ceddc96f2c5d41c9371925697535dfce2a1e',
	
	 
	     47: b'bd2a147ec0114a71d5650c8358396af302b3796', 
	 
	
	
	 
	
	48: b'fa0c1f1bc9e1913349457d5f37181e981ea4938',
	
	   
	
	 
	 49: b'097c1f0ec71e60b2d260e8b6b7ca964c6e77f63', 
	 
	 
	
	50: b'8d19baa31ef831fa4fae5f864a1ff78e23dc145',
	
	   
	
	51: b'8e976fdde6a0cac74072e43b2b051ac9ebad2fc',  52: b'b066f0214041036682c5c6bc39e4d1eaa087f5d',  53: b'd8a257ce289ee9a4533776cfe1bdf43d5deb8ed', 
	    54: b'8f3d0b17b939d0988e0bf5f3f5a8a0d1418df64',
	55: b'bc879286be6b4518e5c4afb9af7664b870fa8e7',
	 
	
	
	56: b'6a9e48b7da71d4b66167ef41bc260b72a7ccad5',
	    
	57: b'4461c72dbee1222e1cde76d32d16596e06e3351',
	      
	 
	58: b'3edfb7d6154c09d09bfdfac00562664a88a1581',
	59: b'537ce4d0f70c64f12b1452849301f416a2b9dd9',
	
	
	
	  
	  
	60: b'1b11a59b9b93b6d8cad5fb572c479490791f63c',
	
	61: b'303c558610b6059336a299954b51c46d2ad7095',
	
	 
	
	  
	
	62: b'3d65d09f9af950ea78a1a21862bdbfd8d84b6a0', 63: b'358a857659da80c92ee3276cf964fc68eaef264',64: b'8b8276e522265784bac17f71d57550a43e23a54',
	  
	 
	 65: b'3392548ab9aa0aa6842e4e78568209ba548bd0f',
	 
	
	    66: b'4c78a25256148eb26ee4aec157cef2509ee8b8c',
	  
	  67: b'5d73fc11ca26b6c0aa261caedbb5df7673ba9c2',
	 
	 
	
	 68: b'9193f8380b65fa7f0ec5da37a87331a8c60fd87',  
	
	
	  69: b'c7d219ca02f0f422bd92228ec26e99c1762122c',  
	70: b'a5020a54e0e9deaf0b3c0457533bb8f28122e2f',
	
	
	71: b'6eacc10aa187b99dbb38cda484449d5572a2927', 
	
	   72: b'd8c0b36e077d460f147be11c9529e60ce97979e',
	 
	  
	  
	 73: b'1900ec4cf7c1b56b73eed63431098f494f6fe14',
	
	    
	 74: b'b85ba6942ba85848a5950a949193142f4f31222', 
	 
	
	75: b'db1cbc5be71c2b413f6b988621b9e99e151ca86',76: b'4cd5010b4873c99a6456c3f33a5afe48fe0ab07',  
	  77: b'5927d4ea63427f1c8bd1d5447126a8adf2d8420',78: b'e94ec5ac58594b91d4f06d5491532fe2f1f4a32', 
	79: b'672daa6580d800f03c8bc0f96f23a09a87617a2',
	
	  
	
	80: b'bce393af788b18eee2e5f94e69deb6ff6dcdb79',
	  81: b'ba59cdd5bed2e9077e28c0e5d412145164f26e5', 
	 
	 
	
	
	  82: b'f145027b3cfd7911bda2d4d1b36a5c619ebe109',
	
	  
	 
	 
	83: b'879c5e9096ed182fc4ae929a04ec207f053eaa6',
	 
	  
	
	
	84: b'51b572838ab0b438fa8a4d248ee30cc5f8c41fb', 
	
	   85: b'9f1f50e37baf91272565b2b58b482930949fbcb',     86: b'9e64d3462b58af1d424c13c9d608e74c042b32e',
	
	
	 
	  87: b'd67230ccba7b2463ef7ca46559be78e2ed769d0', 
	88: b'4c6a57170757bd8a6cf9c16540a31ccdcc6a9e1', 
	89: b'a9928186208ffa4f0d932603130eb241149e690', 
	
	     90: b'88fe94c2d9c21c4ac4eced621ca989eac90e688', 
	
	
	
	
	 
	91: b'8ee53564f61081238cc0d41d58637ffa2ff7246',
	 
	
	 
	 
	
	
	92: b'e2632be9e217a557556b34708fbb552efaaf93d', 
	   
	
	  93: b'932b795853b623e3bd0a45ee100855f477adab9', 
	 
	
	 94: b'fbb6352374aed28efcc9e8d5a488b8def20d73d',
	95: b'20eb6811df189039553b149d98b8947735b6698',
	
	 96: b'0adeccf5b3f5d116ccdea8f00701165e929a41e',    97: b'b17cceed17e1d0490af7bbce83ba9dee29f67d8',
	
	 98: b'9f288ad16613a02dedc0217ea71d03d712c0706',
	
	
	
	
	
	99: b'a86f86776425f971cb52100a883f43baea520b1',
	
	
	   
	b'ddeadffdfbdcffcbfceeeabddeaffbbcdcaedbc': 48}