class efedcbcdaabeedafbbfebdebabddccacaddaaef:
	bdabdfadfcfadddcafafcbedeeeaaecbcebddfc={0: b'54db2b2e92a4fc5905a8458e05fb786afc1ed0c',
	 
	 
	
	 1: b'47cdb0f1a6f40b9086416a3ab429b50ec623113',  
	
	  
	
	 
	2: b'235650a7070b1606e5e29940688a56a05c52114',
	
	
	
	  
	
	
	
	3: b'dea9304d2b11a64138be4df4f3438b2343356a6',   4: b'd6057fd38c1ec9590e96547ea443592a0947b49', 
	
	    5: b'71b05aac70c3d651f0209d9d7e48b94c5ed1e63',
	     
	 6: b'99cae4dea9432d2ee6c1eedd4bff752e73932cc', 
	
	
	
	
	 
	
	7: b'1416585bffd7a5c2c7178b3f54f28e86bc3207d',
	
	 
	 
	   8: b'37c3863d203a84b273f0b9cd4ccab8d87b5a5a5',
	 
	  
	
	
	 9: b'70abbf4ace255b890493ef92582c49fd6d22dbf', 
	 
	   
	 10: b'ea990e45e343f32ce3e591f7e60c465831a4068', 
	
	   
	  11: b'fb5bf72a798b47fbe9aab742cae3f1be9115925',  
	 
	 
	
	12: b'7fe78bb9e8e509741d4821a268b1c7934d4bbb4',
	
	
	  
	
	
	13: b'c9bee385ea99fe0ae066a26526f9709749774bd',  
	  
	  
	
	14: b'4bc1aa9bd91c47eef6fe83bd7e28f817f269fe6',
	      15: b'438fe46a43920c2e6479b71538fc94db49463aa', 
	 16: b'aea577fa6e3e2a766c9f20783934ea33ecad8ec',
	 
	
	 
	 17: b'95d2afbe40b823ad48526cfb925228e922bc5de', 
	
	18: b'b525d5fd52bf67c1713cf3010d73d06c78c6365',
	
	 
	
	
	
	
	19: b'f17b50b7bccded9ac5ff0b51714d76aff2f62c0',20: b'8a6de4f4625ff39bd139a0d410425c65a6788cf',
	21: b'c2df3ba5c6ac1a6fdc3f70f0c8d0461acd2d73d',
	
	 
	
	22: b'764b797cdd2737298dcbd195debede2704c59cc',
	23: b'0f48e2d3c9ed9d9669755f08f77b4a97c8d42ae',
	
	
	
	
	   24: b'e194ddd45c94f61a9c114662c6f0a7c09215460',
	
	
	25: b'9b3fa0956f8227a3fd5a3d27f9e06fd6354a155',
	
	
	  
	
	 
	26: b'82ec0d364a8a71caa22f5abe5bd6ed6374b97ae',
	
	
	
	
	
	27: b'16db47165f00b4eac00b4187c65dc17f08b627a',     
	
	28: b'9671f0dc57cee552aacabe6ee31540a06d27382',  29: b'73f7b735e7a4f0f49e6fe721a8bdc507217f569',
	
	 
	
	 
	30: b'6b6e91442f0ba813f64e35af747070fe34634ce',
	
	   
	31: b'4cac704a506d4ec9e134761fe0e35780e8c6d65', 
	  
	32: b'650d1f6af6b0c073681565011efe5afc92d2ea2', 
	  33: b'433cd9747a4decc69076ea4e6bfd9d5add30b2e', 
	34: b'8333cb3b691b16fb3b69f07f0e4393acdba41f4',
	   
	  
	  35: b'3ed7cfd8f5b0a627e8ffeedfbec6b214ff6552e',
	 36: b'5b9718f8d24fa878882c72fd088868d6e3ef9d5', 
	37: b'cf95fca6bc6003a7c9dc12207b7b66d9e9dba2b',38: b'e5c87e0b9e7bd6db4d4272e8d5024f2464993b9',
	
	
	 
	
	
	
	39: b'fd423c3d20f342b85d502759f7ff7e6b68d1021',
	  
	
	 
	
	 
	40: b'62e3f7d077e201c819b08f58d93d1dfe9095240',
	 
	 
	 
	41: b'aa8b8dac25497847ebd873f925c0576d0d5ba23', 
	
	
	42: b'e5372af4c8d1c28dd2bffd9870f9457a476d5a3',   
	43: b'215850ccbe5a485bdf028d48112e71d0f7314cf', 
	
	   44: b'85c9958d6278d68efe6bab5bda708e0289cf299', 
	
	 
	
	 
	
	 45: b'676c2c18906c8bd5a8608cfea33ecb89e8f26a8',
	
	
	
	   
	 
	46: b'8f832ceae99f5e37c8a40969c3432671b716207',      
	47: b'63a1b727157b8f9b902c159a33e048d4f8495c9',
	 
	
	48: b'cfd00c31c41f5c5e94c6be529d4a51445153df3', 49: b'fee30215451237b01b517a231c72eff60097a15',
	 
	  50: b'f6b126d1c23c0490a2087de0e6223967fba89d1', 51: b'430d559460f90e085ac4606963162a597d3762d',
	
	
	 
	 
	 52: b'06aa93cb74c97d587f73200ec16f83800fdb35c',   
	53: b'0ecfd7ef5404d81e05da130d9684d4133b37271', 
	  
	
	 54: b'bb5ad80d434645c28db7f464c624321762369d3',55: b'497bf117a16ffc93b9635bdf2996372d1fd5cda', 
	
	 56: b'a64ff6780c1360ebf4b8fe3c0a348d20b5cffb6',
	57: b'a86d9ed812a19a3ac95f942e353408b4dc76389', 
	
	
	
	  
	58: b'bee3be7df56de9edbbab53eb36f3821d7f7a74b',
	59: b'd2a9397af2b25f61cec76d6106b94b41437eb58',
	
	 
	
	 60: b'02222dbdbe0d504acdbd88b159bf36325760181',61: b'239f50c653e5fa1a5cd207e13daf252f8d526aa', 62: b'b418da0ae7131006d6e1ffea6508b947dbd8ac3', 
	
	
	 63: b'999bd9996eec51dfa2d11e4c1a3bf27bdbf5f6a', 
	
	
	
	
	64: b'79eb10f61543299caf373901da4aaef2e682187',
	65: b'928bdfb5f2a9cd53b6807048eac89625652f9c6',
	 
	 
	
	   66: b'0f168a2ee7940052bde854fe9d2538a246b906e',    67: b'a1dd9df7f45975bc4e44970576d5a32fe30ba49', 
	
	68: b'f8f2d3a0dcbb75372f38c7a477c8e00ef2e9e6d',
	69: b'0457e436dd5fe286984215d774c11617e237e1c', 
	70: b'43b40ca1b26c6faef5e57cfb717d494e6c2899b', 
	71: b'3627194638fb0bffea6819ef6d3fa555939272a', 
	72: b'c841745ff9981f693d3e7c13f3da6c8e70d1aee', 
	 73: b'b0194f3154a8125826505ad4f1c80f4bed307ef',74: b'2a72ead17c5780c778c4df153cd2cc22165785c', 
	  
	  75: b'b28c433978de0181be18ff8f7bb5da49f4680d8',
	76: b'1f0500160456b2068280bd826bed874d1821a03', 
	
	  77: b'074e3c0e20e9a05f2b2d41de11c17f503f375a8',
	
	
	
	 
	78: b'f052f2030ddbd92a4735efd0af8655e4da4009f', 
	
	 79: b'e2327094c97a645f8068e4a50d2636bc10825e3',
	
	80: b'7d77ff9bfaeadd4c2a4728c4b678bb2112f2806',81: b'6128a1810149b4c9cb242a5f820eb0aafb8a419',
	  
	
	 
	  82: b'5554158557f092f7a5c62e220bf509d1ef7f657',
	 83: b'ae28775c153dcf2beaa838e934ba80b98f33d26', 
	  84: b'c7f746eba93e8872a5e88feb242c409b8c93002',
	
	
	 
	85: b'65a4c1fbfcdfbe07c37ce4d9c9944f9f5b62dfa',
	    
	
	
	
	86: b'058cbfa3a07e5dc6f73c598cf2a434a5fc79f4e',
	 
	
	  87: b'f746204201d3cb8a4e26466c1d06c6e65ccbc25', 
	   
	
	
	 88: b'20dba4def03481ed126b337b3bfce3bb88c819b', 
	 
	  89: b'e1f7e4eb5d8d71241fe0d21ebd1d492d0c0f66d',
	90: b'8e34e90fe4ca54326e2083499e74eed7fb373be',
	
	91: b'a00ffcd765fc01fe3fecec0c339f91aa7cbd47e',
	
	
	92: b'e288b1c871a30beeb3286074291836db33c710a',
	 93: b'e518bd5e82def3c41ff1d1963b47ac497485f36', 94: b'17482fb85ab7c86521ebf9af0287fc76743af24',  
	
	
	 
	  95: b'74bc0c4fcef4b50381a88a544b6d711fff23336',
	 
	 
	 
	 96: b'81bed29bd227ae008512d618613df21118f68f4',
	
	   
	
	 97: b'f7f6c80431837974facc82e87373a7929ca0e23',  
	
	
	
	 
	 
	98: b'3e322397137f96825e940431e62a2037b3032b5',   
	
	
	   99: b'9afb9b0223c13406b517ebcdaf075e36e222096', 
	 
	  
	
	 b'bcbbbeabbafeaeffbadbfbcdccffbffecfeefdf': 63}