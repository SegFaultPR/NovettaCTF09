'''
Woah what a mess! I split flag.png up and hid its parts in this package.

Security through obscurity!

To get the last 37 bytes, you'll have to find the correct answers to quiz.txt,
I hope you know a lot about pythons.
'''

__all__ = ['a'*(i+1) for i in range(100)]