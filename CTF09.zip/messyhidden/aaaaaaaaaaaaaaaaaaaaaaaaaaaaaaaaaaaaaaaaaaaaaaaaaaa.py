class affffaffcfedcefaaddadcbeeadbaefbfdcdceb:
	ebbfbeafbffaeeebdeefcdcabfcffebabdefdca={0: b'40633fb509227056e6f0429c3ee87c88802398d',   
	
	
	 1: b'4016c7d429519c6f364dd7c518bf27c25f5da11',
	
	
	
	
	2: b'804109abe90a6dbb075d3c19ba64ab039c5bbad', 3: b'd8aa27b762cbad594b783c7aaa817423a8f4330', 
	
	
	 4: b'db79938053c9c364985ecff9f2036c208210a57',  
	
	
	
	
	
	
	
	5: b'04fb8560a29c4913bda920ea14def617c8474eb', 
	
	6: b'aa85e8789d4c34488938eb084e375c5aaabef19',
	
	
	 
	    
	7: b'49de37275c315d2444ef646ccb3c66900fe6c21', 
	 
	
	 
	   8: b'1fb1384f6073c3e02f8163b1f441083a038739f',
	
	 
	
	
	
	 
	9: b'fb4def4f6ef106a17d805e7191a6e27dff6f843',    
	     10: b'cc6d8cef20b57ff58fa923216d86601f80bd3e7',
	11: b'77dfbbd3304dc0886ff79cd93bc438638f56bbf',
	 
	
	12: b'd7801adf9ac905d9c591bb18db37645c0f10860', 
	13: b'6143fb6b18896c5884c5e28192623e26fb1928a',14: b'1d984b948c351dedbdd8ec66c098cf32da26548',
	
	
	 
	
	15: b'88e63ff9e35a2329371c30cabbad83dfbbdbe5c',  
	 
	 
	   16: b'dba67b955d66ac4e9d017e571f16b9882c9833f',
	
	
	 17: b'28c2383f78c14e5ac57605ea3159975cceceb99',  
	  
	
	18: b'8810e3e691c92f866c08b89629d5fac433d599e',
	  19: b'44f704ebb36e52648d07be70d836f5c97541bc9',
	
	
	 20: b'404de9db7daf0b4f4cd158c54f00cae0f1b7103',
	
	
	 
	
	
	
	21: b'430be3e4032ad5c98541ae1f5dbcf66c092f784',
	  22: b'3e3bc9c424c3bf86a87a8b45b13b68f87782caf',
	
	
	 
	
	23: b'd58b2762487d67bc6af8130d42f3837baf6ba15',
	
	 
	 
	 
	
	24: b'dc5b313b887cdaf8d60c01179299d214e3b783d',
	
	
	
	25: b'08faf8724eae23a6400269ddc4d828640563f51',
	
	26: b'ad9a6109da1ec33b1e6373f059c7b672ac879ee',
	
	 27: b'd49e13e1aee20ff3c209d5f8a05639d36869e68',
	
	 
	
	 28: b'd992888ac6f28e8c5084562e3d800f9255e2948',
	
	    
	
	
	29: b'28b358e2cad37694dd62123249199d5ecde9fc0', 
	30: b'0f005be9b305dfd2d1eeeb46075efa1a542b8ef',31: b'6822776375a308ed47ff1eb96b6a475ce2023ca',
	   32: b'af544b6a1803252b326445660897cf1951f3315', 
	
	
	
	
	
	
	 33: b'e2ba7bc9807bf1a635f3ec13d88deb1149d47c7', 
	 
	
	34: b'14c9ac11418a2f75e4ae8daa32c5e994fda97af',
	
	    
	
	  35: b'1767f4c1a5ba4f222327335b79c44799e53a235',
	  
	     36: b'42aa961be3d4732eba113c51d03547f49700990',
	
	
	
	
	    37: b'9807100631f0c92c1fe7d6c67deb19dc5892cb7',
	
	   
	
	  38: b'30c49a229fa7e68fc1fd2cd269d37f308616642',
	  
	 
	39: b'b6ad3f4ea9c878e03d911e04b7f530b30fe3bb8',
	  
	40: b'5b248725242fa7fa590a952b962bd27c0c4e1cc', 41: b'0fd2ed5c20edae6e45aa65ad5588f624126cb42',
	 
	    
	
	42: b'7320819a36bef53b5f657b4226b04ec6cc88260', 
	  
	
	43: b'3401ddab87061775d62482bb49fb174a942f49e',44: b'a2d55c2a3d1ad79d539a37d548922ea7a7beb35',
	
	
	45: b'83293d3b3981ec74e9213f560de91743bc280fe',      46: b'9f241a6fdb4df6435d5865237cf9a6e7370dfcc',
	 
	
	
	47: b'8851120707f1c0873677131faf4b60808c83672',
	   
	 48: b'a011ecbffa1b5461f177d017e7c80873c4e5149',49: b'7df839931d6b730419ed5c3eee39d23f3008971', 
	  50: b'a6338309cd683ec93ca9d6e409dcb4c389dff2e', 51: b'1bf31a752dd9d69e73b1e22bd97c78357230112', 
	
	
	52: b'968729017fb584efc600d3db0fa953406109a9e',
	53: b'2b3f7c05c7d37c8662182cd18c197f1d2dc2ebf',
	
	      
	 54: b'9ec0a86524afd9435214e704b10cf1b0155df5f',
	55: b'2ba94fa2a8cf030457f33a9150fff2c545a0c28', 
	 
	 
	
	
	
	
	56: b'e2bd2727eb75d8526e5a41ac24a96bdc33a0fd9',
	 
	
	  
	
	
	57: b'bd0e8ed4325b86211ff4d670036fcc3d83b447e',
	
	 
	 
	  
	58: b'dcff9cccea5b404b5ac1b71e88aba8a08f6ede6',
	 
	 
	 59: b'a1c233d3298928d8745f50c7a01765a9d9dce5b',
	 
	  
	    60: b'7f259351a441d64de38ba46a98b5c9680ca0a52',  
	
	
	
	 
	
	
	61: b'918c5a944414d79031b642877c490022f846aec', 
	62: b'47cf2c30b7d0a6bccfc8f3bcedad39e843400c9',
	63: b'f7ed1832c157403ebf406a6b8c17d7416101f2a', 
	
	
	  64: b'6aaa26e8515d749b943e7f9830ad13c6bba91d9',65: b'c7dfa18beb517e5e651c2248f4c06cb1036aed2',
	 66: b'9ef786a658d3be54e89979b6d4e3e38ae341eff',
	 
	
	    
	67: b'd1f28f1ad996de1c87cb3d365542e97bc9dd838',
	
	
	
	
	
	68: b'76d4c790e61f07f8b65b959a4853ae10079f3b2', 69: b'498df7fa18b1fe22813a09d2c47e25c6534e480',
	 
	
	 
	 
	70: b'2a79a47998a2e1f1513d61252c4f3b9255cb81f',
	
	 
	
	 
	
	 
	71: b'1ecbddf2041c5ac05ba914a41c4ad5f9bf63ad8',  
	  
	
	   72: b'd861d91c66c7853491fc866c1ef00aac67efe11', 73: b'd78be74cf6e55abc2d16a6b307efe6ad6507073',74: b'16a0cbf9fbd4a6fce2030c265bc253e78f33415',
	 
	
	
	
	
	   75: b'05ab0cfd1988a3126d333ef72ea2e1f8ede7a9c',    76: b'0d6a1d1db462a03c6353c5e0227a5e26d80a707',77: b'89bddbc20936c197f2a5d35811152c9711948bf', 
	 
	 
	78: b'0ccaffb24a9c3e0bfbc8e7f27f6f6a10f54179d',   
	
	 
	 79: b'042a8a5416fb4362702e536b90256c797d9aa18', 
	80: b'ed26e546c847893965cd7cf022ac7b2ad8a90cc', 
	 
	81: b'2239bc526b28b02f12c0a034c72d9ad4272a403',
	  82: b'3ed5753f6c9f40480741f11c40bc20269d80f39',
	
	 83: b'45fdbdec65097e9c3fccfde3532bab675ee3849',
	 
	 
	84: b'9dbdfb57dd09b084081e112c9df7cd149d58a60',  
	
	
	
	
	  85: b'3c7801363c985d38d2e96fced5f917bb88bb740',
	 86: b'2cebb064efe4c7fc3e7fc25dc97d8c2bd146a01',  
	
	
	
	
	
	 87: b'7ac3d53b4d73a6d5c7edd20c6f075648011cd03',
	
	
	 
	 
	
	 88: b'1eac657e74e8f88b66d4d0c8f8c23acf4ea2c43', 89: b'd19db2b2761b884478fff9be808494a02180c72',   90: b'e8905dc23291af39ea7940f0deba825c1e40e25',
	
	
	
	
	   
	 91: b'119d147c61d72ed52e10aa425446b11fc37783b',  
	
	 92: b'39d1ec8ffc1afe925ff06c56c59b7e12237e956', 
	
	93: b'7c4b6bef87277a0b9952d80a775bd319f96410d', 94: b'a450996d6f0b093076a814579811c106075765a', 
	   
	
	
	 
	95: b'615c75b9f7baf30ee6a98ca0720940f49df9344',
	     
	  96: b'0ebaf707e0c2fbbce6e83ae390d74f00f4ef070',  97: b'a0062b72b26005e6aa564cc5e0d035be3cbf864', 
	    98: b'66b4a470cc283ba77ab0cb2a8b1476e2566e7eb',99: b'1d5dd7be44bc4368a7f7b2d1a0e7edea2dd5925',   
	
	 
	b'cbadcaefadfacfcbfccfcabbfaaefcdcfbedeff': 27}