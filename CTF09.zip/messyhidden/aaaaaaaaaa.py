class feccaafadacdcafabdbbaaccacdccbebbbbadcf:
	abeabeefdfaeacafffceffabdddfecaccdddddd={0: b'81b82c3f322701567f482af7ce77220fceebe7a',
	 
	 1: b'86674531593cbbd5ff0a86459e433e3855ddf02',2: b'05258a32f392b03cf6a93e0d2bde57bc3ce3e93',
	 
	3: b'4123326b1b61dd498d899686c4d9ca4e8f84a8d',
	 
	 
	 
	4: b'b7e388f36f022a8e885efe390189dee58954757',
	
	
	5: b'aa547c87f3d494527eeb271ffd9603fa8acd900',
	 
	 
	
	
	 
	6: b'254bd0ca8a0afa62883ae157d174e9ceec0b06f',
	   
	7: b'd3688fdd27de43113fe214972b0990a3890d9bc',
	
	
	
	
	 
	  8: b'8caf0b7baf4f131ac594f9bad89fa9581e2150f', 
	 9: b'9eef829d427d523d561d43b57a9cb92ba2b5c54', 
	
	
	
	
	10: b'a129fb5c8ca88374e7ec0d50542ba9e9e3813a1', 
	 11: b'ab1e13f85f14a8c641e346bc3db4ed18824f18c',
	
	
	
	 12: b'd0b7c0ec6575aa491851097baffa938756d8632',
	  
	   
	13: b'5c954db7377d7020bbc26aedc5869a86ee02149',
	
	   
	
	  14: b'1dfee71ab4a3d2e18d042d81436ecd3e8722a21',
	 
	15: b'18b2ebc29a042454cc16169ab01a0adb06aa53a',    
	
	  16: b'b009a8d57ba35029a77df16da271b6443e5d18f',
	 
	  
	  17: b'00045cf78acba1711bf7e61ffc0821462a2a9d3',  
	   
	18: b'a6331ce6aba728576f0702031a41f8ff5b5b614',
	       19: b'7b0a212e97cb0fb7b430c81f704c12b550eefc2',
	 
	
	
	
	 20: b'6129b0d1fac401a377ad1ec7cbd15b2074796b5',
	 21: b'ba771b00091ad6da88ea6d410d97415e888cb13', 
	 
	   22: b'cc6e318f4752a7c45941f9d9086fb26fb217ee4',    23: b'f43314b12bc3ca196aca6046097bba598dc9d07',
	 
	 24: b'15fecb0a59c3429f7bf0050cfdcf49dcc281b0e',
	   
	
	 25: b'825d195f41bac51a48df13650037d3357286410', 26: b'c25aeb99382ef9f1528c88301e90cbb7324b1b4',
	
	 
	 
	
	
	 
	27: b'cd0b2493cc79422b1f39b1878230700ceab0a2c',
	
	  
	
	 
	 28: b'15421ac8b702f052d3a377b4b557f768364cec6',
	  
	
	29: b'e6232269ba947e56a795bb78e2acecd8ae55f16', 
	 
	
	
	 
	 30: b'e2bc593f5743148334e9c0cbdeb93e89a7c495f', 
	 31: b'00168773b13b32ccd8a7bca966f6e1f6ede8b29',
	 
	
	32: b'9bc7945bd695dab93c7f1f928db62415ff92e06',
	
	
	
	
	   33: b'54429b5e391803a3673f866b551ac6e0ef64f05', 34: b'1264a0d3e7a74590e295c8903747dc49a2b0560', 
	
	
	 
	  
	 35: b'37e74081c2fc7c6d99fcf84647960dcfb206fa6',36: b'075e3705e1d68cdc8a6496a4de82c22d4575203',  37: b'44d52a4803b76fd08179d94053604ffd2820ea3',
	
	
	   38: b'bea54e14cf7eb28e046a4cf765dd87badd19820',
	 
	39: b'9445d87ea832ba1d55d45e689a06c3218c4dda8',  
	
	  
	
	 40: b'4eecaec1dd819fcf68d32bebc4368d204a87c9c',
	41: b'928a697d11d85745d9e5e5a9ad060c3df1d006b',
	42: b'be37a09900057f9d7cbc78256da422762d20243',   
	 
	
	43: b'ee1cf51b756d583873597080ad940851c3bd473',
	
	44: b'192a154a78c6d6e70c676336797b359d32a8bc0',
	
	45: b'1fe4fb65aa592c4a17ca6f1c5b6a2c70f556421',
	
	46: b'102d382b8d16aa31dd2d06c9faf23312e6b95bb',       47: b'129c3a2568f4c4a5690cd1f2394048155824a00', 
	  
	  
	
	 48: b'9d4444e64e25919741b0d34f200a97de102ab5a', 
	 
	
	    49: b'a5dd029f101fcef8d492c3556272ba065d62aa9',
	
	
	 
	
	 
	
	50: b'421994d9789dee578ec3d19f851eae371cf9722', 
	       
	51: b'2c63494e0dbe240af49f310317d332d12abf607',
	
	 
	 52: b'a8bb5efa90665cbf79148e22358ac620448dbf9',
	53: b'3743dd564cc1b7999149fbe066d9efc4b5a1446',  
	
	
	
	54: b'4ea1985006ed602c90827cb9eb20600cc3fdcfa',
	 
	 
	
	55: b'127c0900e29b3ce703329d6cfcbe580a98083c4', 
	
	  
	 
	56: b'275f3950ff6b929bb040fe56ab5be2589641952',
	
	57: b'f65fed51f1faa4c4548c770fc3840bed6d882dc',
	
	 
	58: b'318d27e3fda6173c88debc61a495de6ba72efed',
	59: b'54fa9f0536cb0a228517bf48b9b346101ffca13',
	 
	  60: b'79563ab99db3f6f13df556ac161022a720d7c6e',
	
	
	61: b'74224082dc6c015899ae86836eec94ab2f117d6',
	
	
	  
	62: b'bc60e3fdeb14d56da7d019fe08e6f902b7999be',
	
	
	   
	 63: b'7e6f9d0f2fbef924d32d1dc94a00e3615f8485f',
	64: b'eb531f8c982a4e890b21d6d07c42a6ed272bf88',  
	
	  
	
	 65: b'561ff0edf07c26d7f2bd9df5b5d4aefb0b785ef', 
	 
	
	
	
	
	 66: b'ec16d9545e57259ed7e5edc176f82335560338f', 
	  
	
	67: b'33e7a919e62b5daf5c19e5ccb4e043a4258d363',
	
	   68: b'364ee4e2ddeeb9af017991225bdb06bc81f657c', 
	
	 
	 69: b'3eff263332f927a6eeeb4f9e93748344dfbd67d',
	 70: b'edae36ea4ea0d6010c7b70679d09dc41fad891c',
	
	
	71: b'93564c04a6e13f71d28d0b3d5c7be3404e0e67a', 
	 
	
	
	 
	 72: b'fab4f387d141f9b82f74cba2a2b3fbe9e65da17',73: b'20167cbcf38aa3a713555e8d442e44a4511fb52',     
	 
	  74: b'7dd551ee6feaf5a49a2831c60f58193b2f6983d',
	  
	  75: b'd96b628300d536d78f07bc79362ccd043cfa157',    76: b'e1988baeccd270935aeb95de28d6d5eea007f49', 
	
	 
	 
	 
	
	77: b'c31f5474b99d3e2046a460c6f8530128e237096',
	
	
	 
	78: b'9761f40ca9a56a9971da3d1a00b98ee00420d0f',
	 
	 79: b'7ca3027f4768b48e0a4260f5dee62df072f446e',  
	
	
	 80: b'2b016915e092a9fd3aa8843168f6967538ade0b', 
	
	
	 81: b'aedc5329ba6da9d64308bfd0379f369f77f1ca0',  
	
	   
	
	 82: b'f382aea668cfb3d39c62f61db89282e5bfbd856', 
	83: b'695ae7f2d9798728bec03f40bea7967d09700ec',  84: b'0af405cdb5538b039e2b772fc09eef9176908cd',
	
	
	 
	
	85: b'df9b8b47e3709f4dcae1ce3d77248e9047821bc',
	
	86: b'a018f33a4ebaabe6ebb98b9ff8207f79d621e93',
	  
	87: b'0f891abc1f63e1696de6b4f57d93dcf4d18f7e3',88: b'2d812a3e633bc06cae28c595a4dee715364a831', 
	
	89: b'c3413da9efc4093a33345094489d0711b8d2e7b',90: b'2c599beba7da307ff612b25f70d82a4a2252480', 
	
	
	
	
	  91: b'df88136b4eefa5607ca77ed83aeb2eb607b98b7',
	
	    
	92: b'ef7c7c324143ec178814de7e2093bfe152a37a3',
	
	 
	
	  
	
	
	93: b'010e58442d4db8846a85484dcb2c92cbb6110f7',94: b'7111efad2a2f5f745286f6fcf620da6a86689c4',
	     
	95: b'fa586a149bf5fb5afe3b5bc74895fc9ebcdf961',
	 
	
	
	 
	96: b'198e289677259ca6912667eac46ddceb639ad16',97: b'3357a98ba9eb5988fe389b5ee3af7fb8151f73c',  
	
	98: b'076a4add8ea6a2cbbd37a6f1a0f8c8045270867', 
	
	  
	 
	 
	99: b'6994b4af5146a768ade11a806c1f17c09491195',b'ccfebffabcedddecbdebcdbbcccbbadaaaaebda': 3}