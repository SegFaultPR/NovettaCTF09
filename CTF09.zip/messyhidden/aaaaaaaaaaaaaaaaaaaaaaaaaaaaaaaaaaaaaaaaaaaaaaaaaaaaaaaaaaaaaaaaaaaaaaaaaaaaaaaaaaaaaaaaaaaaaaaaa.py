class fecfeefdebbbacadfbbfeebddbdeabfacbcbcbc:
	adabaecbaedaaeadddbffbcdecfcdfccfecaddb={0: b'88c4a786b9a99a9bdd3c0bb9833e7c6aa5b20fa',      
	
	 
	1: b'e8e2b33f83cd6771d184167f4def9b5a367d0a0',
	 2: b'6c52ca1245d9f05517e33402eb5b643d3a22763', 
	
	
	
	
	  3: b'85142865f637bd395c06db12929485e4f010b99',   4: b'a554ebd3b11804c43e2e4cf996a05518e9a386c', 
	    5: b'e8d48f5e9f13059076583db3f774e6c530098da', 
	  
	
	 
	 
	6: b'8ae828f726c5340cfee3e7d3c2a1410f2a56c77', 
	  7: b'37a18cc51106046e43c6f1ea73e7bd2b5b8fdac',  
	    8: b'71d47aae7b5f8c5a0672e037f64ad02412d133e',
	 
	
	  9: b'eae7b6edae9604692411f7e3ddfddd3195cdded', 10: b'7497d1356e37a68c3505a0ca066edae2a044118',
	 
	
	 
	 
	  11: b'de601444f0a20ec2b10daa044afa05d58767f98', 
	 
	
	
	
	 
	12: b'26a967fe06c1aa5ae1cdf2985996d0d50a93276',    
	  
	13: b'463f0fcaf7bb73a1562c2c64f4ce6df716b97bd',
	
	 14: b'ac1bce1aa6ecb2670fb0ae4080c402e974747bf', 
	 15: b'8aac86b0cca7b2a46ca83886678c5e3f0573fc5', 
	
	
	 
	
	16: b'40dcdcd94da3c48bb7caa293c02adb45adda935',
	
	
	
	
	 
	17: b'4f656884b4639b1c6095074ed3e1713e6b0e498',
	 
	
	18: b'8b31e2849d3e64db39725c5a047f6d1ad768d80',19: b'bc0def6837262d17924fce0c04baa6c65db22f4',
	
	  
	
	 
	
	20: b'bf9005fd4cb754de7423f2579df72dc11596e29',
	 
	
	
	21: b'39add51f6cfb2fc41d5c9884b2d581b7dcf90de',  
	
	
	 
	
	
	
	22: b'097c45532d9a46462c5483f3bee9a9af0411fed',
	
	
	
	23: b'f65adb401a7cb7f2da1634a78698e66e60025dc',
	
	
	 24: b'0b1e3e0aa220d3f04bb6b7bdf36dedcaa315b47',
	
	
	
	 25: b'76ef804d943a34ff78fd062c664096bd49bc8ae',  26: b'9a4f49af362cd311f41600e8ded4bdcbb40cbb5', 
	 27: b'477240ccba75e7593ab221c7adc00a6208e5772',28: b'd6d802c2691976a131b2a53ba8894801350dd75',
	
	
	 
	
	 
	 29: b'bbcc0b73e98fabf9c8c5cf42e14c1c048deedd5',
	
	  
	
	
	
	30: b'cc06d940dc9e9d74bd8ee1c2bb6f4c7072b9415',
	     
	31: b'5a443c69a1251450526b70a612f7140d4da1970', 32: b'e0a7e84464e9f11b70f1f4540fd8fac743c9656', 33: b'c3160271efd156b67f830cea3fba9948369c560', 
	
	 34: b'd5250d46dc781b551fa06dddd63ee04e7f62dc5',
	
	
	 
	
	 
	 35: b'38cb7388ae7e43c6f4b507f8bfc6539294e1729',36: b'8e2a7e63f2e8966bf7b424210a851daa3a81da2',
	
	
	
	 
	   37: b'960ae1d4f28ae50763cc1e552ac9facddbf277f',
	 
	
	
	
	 
	38: b'4e2856f787a74f417e6e69d684c308d6c187eb4',
	  
	
	 39: b'2090ec2a84ccbb7d64afcc2b3b57caf39cdb6ba',
	    
	
	 40: b'5cb4711d7325b3ec4881ff0da8eafa597005165',   
	 
	  
	41: b'b1927babbab0e4a33492605e33852b92bee3c2e', 
	 
	  
	
	
	 42: b'15bc5b1386b7d416a92ae69c2fa7baa88b33e6f', 
	
	  
	 
	43: b'5b8f11c3f5fc5fc289de8548d2f71453e9300d8',
	 
	
	
	
	44: b'e53e100707258d161bd70abf65cba9dc1e1782d',
	   45: b'43899c33a045c30c1c406b57361899a4f7dcbcd',
	 46: b'95745f710a6a9de9d969c38faa310c93a188aed',
	
	       
	47: b'acf7c18f5c30bf8cd8f87cb56d4d029a33e004d',
	
	 
	
	
	    48: b'a7139e92193d5606c3e65d895a5b0b0f62f8e6a',  49: b'419ea93dcb66614c637b2dd66cef7139e3f00e3',
	
	    
	50: b'c4cd506883477a88b9917410171a626fded2f49', 
	   51: b'11cf063422d1a66536ae10612011782fd409b54', 52: b'1319aa1df4187cdc4c6215d3de19ed580d843b7',  
	53: b'c7c57b02698bd525f6dab4a1c82129fa64c5aba', 
	
	  
	
	54: b'095f7f227d95e04f026b69ce74ff3d9812d8bde',   55: b'6c9d3d98928163cd09f605089610f2f0ceae161',
	
	 56: b'61ec959cf63d535624653cdd46fb2ad8ff1689d', 
	 
	
	  
	57: b'08c97f34c6bb418d2854cd94b618a349a79fb75',
	 
	
	
	
	
	
	 
	58: b'f1d9070802fa74a8cf758b27d91b00df90d8d25',  
	 
	59: b'a4efbfca4996418b1ae189b1d0e118bec4557d1',60: b'adecb857594a2aa38a76bded09c23146f4920a2', 
	
	
	 61: b'fa37445a113db521a751eccfba4e4aaab3c7b12', 
	  62: b'ed92b9dcfd38fce18d1ba7b1d497178672e71df',
	
	
	 63: b'a9966862f5ffd6d4e5cda452121fa6222afe450', 
	
	64: b'5683a0b70473d4cc8c8a04978a39e542bc2ec0c',65: b'd84c34e5e0686d990faffe2abe9965aeb7feddd',
	
	 
	
	
	 
	 66: b'66f8fab8a7cb8ec141003f4530231104b326fb0',
	   67: b'e343d02d14d145f7cff942af2744c3f68fbad66',
	
	
	
	 
	68: b'ac898b0774e1dc9f08b9c9c8843e4f9d32f77ed',
	
	
	69: b'5f86dc7b8ac18e94d04b11b883c311ffd500bf7',  
	
	
	
	 70: b'dd3f6cf8e512df66e9552207c491d814df8dfcc',   
	 71: b'b632bce13136cd5aa2b7d6b85f84fe0db739433', 
	 
	  
	
	 72: b'1bc837c6fb33141d093c9b5b93f458c0c1f36e9',73: b'060b35c9e4fd7f41ca66e33c27cc889a399c534',
	74: b'ffd401c1cb533ed42c8d8bf41f779c7e2bc8ca5',   
	
	
	    75: b'c3cbe0d21d1835b2e10efff5909f27dc9517537', 76: b'73a832ef2842334b0ce7aaba9dcf1543e234e1a', 
	
	
	   
	 77: b'30cfb271633a0c6fea6071f455478d4658ed84e', 
	
	
	
	
	   78: b'2bd903b93274ecb96703a87039d8afdf13bd4aa',
	
	
	   
	 79: b'9e868b12f6148bdcf5c2f78e669464991c81b87',
	
	  
	     80: b'38736f3f722c5746a1cc31791b2464a06f7c491', 81: b'9c007166cfb7fa7da7375901069013d46b4299f',   
	82: b'ca748313da48f4d6a2995303803e6344a31fb5e',83: b'b72fb3a648d1b241b5f560d2573da7d514e4684', 
	  84: b'0736977e6d80ebc2229342bfe0bbf66522bec74',  
	  
	 
	
	 85: b'cbb5dd3a9458b39b661f8ff45d94493f59cee5d', 
	
	86: b'f6edb86b684e48b32e91978855a3709cb78a108', 
	
	  87: b'2ee7e73f918ff64ecd4f90d47390a8d9c04d559',
	
	 88: b'777db4772be325af0873482f1802e26f44947b9',
	  
	 89: b'5864c5468d90122709cde2470500d8f00231fa9',
	
	90: b'3c3b25ef5ce0b43bc08202a1fda255add8adeee',91: b'3e4ad8a33726eff8472d468b0e8255aae6aae6e',92: b'63653a70f7143cc799b02a94081b8f72a820409',
	
	   93: b'086d93b1aab34c1986b3bd479fe0ac259a081b1', 94: b'762e2e0671f55c41b8d555f34aabc949dd4a4c0',
	 
	 
	 
	
	
	95: b'4358b35a17b12a7ba18e5650cd43c9ae07efdd9',96: b'b344bbd75e8bef67528f9bac3052e24e75436a5',
	
	 
	97: b'a5bc7d5372d8de1cdcdad57446f0b5bc65533ea',
	  
	98: b'd632372acbb15400ba4ab5ae5e1e9ba046d010d',   
	 
	 
	99: b'1beefd8582c99a4ced767930f8c95663139e015', 
	 
	
	     b'bfefaaecbcccafecadfebbcffacccbaaecebeae': 44}