class ddddbcfcadedbfbadcfdaeeafedbbdfbbdbfcae:
	bfabbfdbacabecceabafedafbbceccebaedfebf={0: b'6bffebf919059002024d26628fabe0a8c3ec60f', 1: b'b9fe937b4ddf94e9178483424790ea15bb93ed4',    2: b'1882404d22c17be6e88e9791c3ea90cfede1595', 
	
	  
	  3: b'76fe67da2e1fd32939cbb0176476672999a4045', 
	  4: b'd7d9da5711105b384c0bbec0f1bf934a4fd89d8',5: b'b55d2accdf319ac565168ac62fe817f01f0e132',
	 
	   6: b'9d4f2cd569375a4956eebefa7551d8f2fd222e9',
	
	
	7: b'30859fc4e12bd9f81e4e7732afeb00269f48cfa',
	  8: b'70013f7b017c1a1eba21542e903d20ebc34dcb6', 
	9: b'bc35aac18dcfd558c9b7ea0d309c1697c129f47',10: b'c33b4e424149752eb628c225d3c1d405bbeffe0',
	
	 
	
	
	 
	 
	11: b'f029ff9e168370fe563f8098dcf030967b1cfb9',  
	
	  
	 12: b'd4e6914697ab8642f275a41afa94a3fec55522c',
	 
	 
	
	
	
	13: b'b8148c67c6b28b11fc85d4652fac18fff776cbb', 
	
	
	
	
	  
	
	14: b'ac3f1a26f848ab770b88075e25c08bdddb190db',
	
	
	
	
	
	
	15: b'3b46c72b3efa759f23137c929e51f0144d63f3b',   
	 
	
	16: b'6e8c1e0ff5aed3847e90fccc98f1fe8229d2247',   
	
	17: b'41485ff38a14847d87d07d0e967a60772e3b3f0',
	
	 18: b'd01c89a2e190fb3098cd6efab7244d529b6cc9a',  
	
	    19: b'6b4daa2eff9a59d68357707f7ad5fbdf91b7819',
	  
	20: b'bcc6288512ec1a7cd07dd66e3c9ce37ca455c27',
	
	
	
	
	21: b'a7703ad93edff5caf1a22e3e2b5f1779f0f1ce1',  
	 
	
	
	
	22: b'37a6dc2f7730ff44814f21a7c34693cf49ef592',  
	  
	
	
	23: b'c8e85425cdd4cd11de0334052a08e3540dbb84c',24: b'd5fee065e3caed7a2b2621673f88835a3ecdf19',
	
	  
	
	 
	 25: b'1da16a40fee415b5d61bd9359ca0a00a1ae27fc', 
	
	 
	 26: b'fd06ed95837cc122825bb927d30e424e486723e',
	
	
	
	
	
	
	27: b'328e18497af2061506c95eb1ec337a59cd0dff0',28: b'592fde1b9cdbfc96b62a4a98a5ec6b7351fc1ef',29: b'f0af8edb9adbe20791ac2e6dfb8af6e754c9bb1',    
	
	30: b'fa84f194bbb8ee3d5c3948c5c2a718d03718038',  
	 
	
	31: b'3a2551587d3503531b03c02b1a3be9972f2962b',
	 
	
	
	  
	 32: b'20f1b3e067b5179adfb3219bb591ea84834d98d',33: b'7cbb0e5a25c6c53faaa89ebc2863e39f2557342', 
	
	
	
	     34: b'e642281dbd1c418c287ae882d9b9e6dc7dee716',   35: b'80319b18a41352f39573dc96ad5c55cba7df367',  
	
	 
	 36: b'0c083b0cda6bd496a74df21647689ce6269d225',
	
	 
	37: b'506052970bb58e25a98935c71ae63c7b2027e7d',38: b'a5f6f0eee581aa39b3f5d310f4fef50532efcfe',39: b'69102d3379961e34465620248bd467aa12ea3bf',
	 40: b'efa4d36706e5eb67f029e5093ae0c97d6c11bc1',41: b'5aab52886dac5000b3be9431a29c387f6ad4463',
	
	 
	  
	 42: b'634e6ac1c75027d7aa111e82e36bc7d2d7d9fd9',       43: b'6f6aa5edccaf10af1b1f33da43f230f5bb59bbc', 44: b'f0e822a12f0888686feea87a744476d02f2cded', 
	 45: b'1a71408baf64cc49d69720d3d217f24c1c2eb44', 
	
	  
	  46: b'98be873d599fa9bc25a2563efc3d76cb6a75726',  
	  
	 
	 
	47: b'fec0a5cba2a976333c7531d57cf67853af3fd9a',   
	
	
	 48: b'b46c2ef4f03a3a1c749641f5cd2d6b99f5d6d36', 
	
	49: b'157fb80dae9dd6715cc7d1f2ac70287668bf6da',      
	
	 
	50: b'dacba143e41b36504a708a1d35182d20df8fbb3',
	
	  
	
	
	51: b'5ac48a6714f1680fc8bbf4b2224000e45ee41b9', 
	52: b'716012477f59f48cb92880cd75085066debbe92',
	
	 
	  
	
	 
	53: b'cd63fa6593c6b98c5aa160024377be006afda77', 
	54: b'07254cea228f4c1d333463965952c65335caa4e',
	 
	 
	55: b'81ee4fa21890f5a9576534e090799cbb6baa23b', 
	  
	
	 56: b'dd001095abb2ab0769d8c8c919b9ebe70ca4afb',
	
	  
	
	 
	
	57: b'232f292b13a499a16c074bd53f371f07394872a',58: b'293ee0cb4ba9c37005ab17f457b9851913b5e75',59: b'fb2c6f54ffb11fd85900a7c306359a4486cb6fc',60: b'0e3b69dbdc525bbb756b497026d820d859291d2',     
	61: b'76a5bb4a0eadc348d83bbfdfcc42806a0658c7d',
	  
	
	
	62: b'b4de7cde3331134c25e90a24cd6b6ec81038d92',
	
	
	  
	
	  63: b'277326c83d2abc891adf666c6cd7ad3477af7ab',
	 
	
	 
	 64: b'c5d2ad97f28de76a0d1a4c65306e2d7ac3cc860', 
	 
	
	 
	
	 65: b'6149fd020d83ab09d9313e2652cc5cb6be9555a',
	
	 
	  66: b'12295e6ecc3d3f15de7555aa421a4d690cf4df9',
	
	  
	
	 
	 67: b'db2256d36122d96fe84a11f09007a82779b8ce7', 68: b'4dbac917741affc3b5ee3e2a563bf01fa2cc417',
	 
	69: b'c15a92fdb149d9739cad765993f1179c489d662',
	 
	
	 
	  
	70: b'c7aada899016b24b8715833f1befbd5587a9a19',
	
	
	 71: b'66a60f5f8faeab67f353e4fdb97d41301f6b28c',
	
	  
	 72: b'd878e23cb621c06b351d2bfb52733ab06b585f1',73: b'25e193ae476ce9e2f3db21b55c8bbbc5347d548',
	
	
	  
	
	
	
	
	74: b'77a327d1607cc8ccd3c9915d79225d9509229e8',   
	   
	
	75: b'dcb4715697a56b646d99fb9fd7ca2537439baa7',
	
	  76: b'e46c30fbebe103c7e8ec3d7c90629ac46725ca8',
	
	   77: b'f0e79855d15a8906c71313c6be37e029317ef25',
	
	 
	 
	78: b'baae4c173631959a94ba2510551e38104de6dce', 
	    79: b'7782ad751a3885bcf86d3247ac6912311d1bd2a',
	 80: b'7bf6236e162f42f1b23792d88267ecece7fed96',
	 81: b'35a304e55a18872e582f20e978415e0a8b5e8f8', 
	
	
	
	
	  
	
	82: b'7c6078ed0faf9ea303b1a7c373c3a7c70e31144',  
	 83: b'848fd37d8b0e0b3d897e46bd1047109ed8a1d7c', 
	
	
	
	
	 
	  84: b'b46a1958c8734c7ccdb8c5bb9c69668cb6a7c12',
	 
	85: b'096ad1e3cec2bd5703523faeb45b3a8353d45fb',  
	86: b'807405c3f4b14888387c474e6e81d877de31e25',  
	 
	 87: b'fc7f45ccb00b6f5b262c6a3e6d5ea6bdc6bbe82',
	 
	 88: b'b5ceefe05b6405a2ee8fe98190aec963c03c090',
	
	
	 89: b'454d95e705d900ee68e2586a8f6ecdee46d775a',    
	
	
	
	  90: b'21ee5b7bead79994f487b21f816e816388dbe49',  
	    
	
	91: b'f8dc7a1c8c8bed29c714240faa889e8f7c3b18d',
	
	
	 
	92: b'1ea92cf64e9f47e8880cbed6223ca48bdca450f',
	
	93: b'cc674afb1bc54e4df62bf9e3570d7afcedce501',  
	94: b'8572061dd41d806915a30334fb606cde130e44b', 95: b'3deec6b2c83267ac700b25b8da0d620b3768dc3',
	
	 
	 
	
	96: b'1541ec3676fcc528fee5b72c62b7d3a8ab9870a',
	 
	97: b'4f37fc8548ca2dcc9932e757adb67038497823f', 98: b'47621b99963fb1bfb3c57f3fdf896f1e0e8edef',  
	
	99: b'a4ce5d3d42aee2ea40ce254b8e77d4eb35beb49',b'fbffedceaabbbccfcffecaecefbaecdbecfdefb': 5}