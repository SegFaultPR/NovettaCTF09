class edbbecedbabbacceedaccbbdacbddbffdaabbca:
	bafdddaffdddadfccddffcefcdfabdcdabbbacf={0: b'4f387bc04ce6b6f62de04c0973921972d04f4e6',
	
	   
	
	 1: b'7c4a9ec202b62d5ba723cbfe21f24f87a4b1716', 
	
	
	
	
	
	
	 2: b'59261937439ff809cf7a74c4f311ce2bd6f9757',3: b'b480a8172e05fbbde39cf516ef72ad979659900',4: b'b17909ad2dd7ed6105d4c0858d98d00efffc612',
	   
	
	5: b'eadc4413143d73fff5cbfee2dee8d3138e32b6a', 
	
	  
	 
	6: b'cc216d173a5bbcd80ea0fb46294526b1d733a99',7: b'e83c1bedccb33d769d4f2b15cae47a52b68ceec', 
	
	8: b'886620a76eed6f25ba8f7c3745d5c4981e0fb55', 
	
	
	 
	 9: b'96653f80160f0565ddff83fedc6dc1dac6f7788',
	
	   
	
	   10: b'95dbe40cf0be7f761fcad91a4230f9d2e265867', 
	
	
	
	
	
	
	11: b'9b9d0c219de2724c52a327b2ac0e48bad2e5161',  
	
	12: b'ea5bfa03ed976e0cdf0d41dfbb31f2a3c24b5e1',
	 
	
	
	
	   13: b'ac9436d1c6975e7c16a4d08d928f2ab48d30c92', 
	14: b'083e62bff16cd2adec6e3ba262b9e7d8d1d33c2',  
	
	
	
	 
	15: b'a0803f1762875627d01122bd916229bd4f859d7',
	
	   
	   16: b'0429a16e65ed71b7fce8694ca0b468a8136fbc9',
	17: b'0d9f12d5d6b7e38fe1883c6c6147b173d6e6e3b', 
	
	
	  18: b'7cde96e19dd12e35bf286bb993b1583ba322d41', 
	
	    19: b'484cd4e695fd650008e800d3500aa0b41543721',
	
	 
	20: b'4c9ce33d7ae8ec062bc7058e2f5c2917623333c',
	
	    
	 21: b'27bdc77dd72b4561e82a73533b1d1a183899c11',
	 
	   
	22: b'55bb41043fa5f2093fa9731255aaa1da302af97', 23: b'268977793fbf129a781c904ff75e3cdc16794d9',
	 
	24: b'e7ecb15db071a17d2fbd9f4a382bbd83a8c68ff', 
	
	25: b'12db10b2e6376fbb85d70a5ac5af01fdd32154e',
	26: b'7743ef4f54e7e7959fb53519fe66d8242da1730',
	
	 
	
	27: b'759d1501a4037f749de9866a8a4ae5646cebf7f',   28: b'bffc6139a1d3c0f14531e4339b5d9e4e86a0e62',  
	
	29: b'd90b10226345c7dbb7af54f917ac00b7edc4855',
	    
	 
	
	
	30: b'931cae4550bea45a045f7e4f25d7071bc4ef049',
	31: b'49358ff7e151077f603ad28911e598a9f46c7b1',
	   
	32: b'1d73f19254a41359cf8cdae84bf5881471718ea',   
	  
	 
	33: b'834112262d499bc6c6eba944d6dcd8994162ca4',
	 
	   34: b'9301ba607f5101ff46f38c528b58477ee919fe6',35: b'4824e7e4705b2600376418c8c4d71428c513cd5', 
	
	
	   36: b'44de0a5cb0c842e7d463b77fd05574421c0a609',
	
	 37: b'586226c522a18f3b3371e6dafe2a397646af264',
	
	
	 
	
	  
	38: b'9ef2954a02172bddf132922c73f6ebed4bf6224',
	 
	 39: b'47481b1ee4a4e17447ae2fc1aa707eb85ab171a',   
	 
	40: b'fbb7b4aa45a8980fef07a1150df415a6c6e0389',  
	
	
	
	
	
	 41: b'ff4e2ee8fab19ceb45b8a533ba0f9af686444b5',
	
	  42: b'f3ed85aca8c5ed7ef25a98ff7ba56c2a4abd878',     43: b'f8cffe1803ca7f274e72fd21744adeeab74b6e7',
	 
	44: b'8b2c40546d5819c98682584d17085db3fd8c77c',
	
	  
	  45: b'5ad82ccd715fb11c247e4fec1a092187778ddfa',  
	
	 
	
	  
	46: b'ee622f57f2469d28acfb20e20018cf8f3dab407',
	
	     
	47: b'e7a36767f1aee542fb85ee2cd9b2cf65adb542d', 
	
	
	48: b'83a4b658fb7ef993bfb72ecfbdb9b8cd5ece246',
	    
	
	  
	49: b'a4015f582b09633e356d7382f65cf94188a9c4d',
	
	
	
	
	50: b'0a82f8942279d223e3e720d01e97e1d0ea6b185',
	
	 
	
	 51: b'357fefdd970249c65c51e7fdf4dc64c6d07e6b1', 
	52: b'834b7b22bab8cbf24671030dc830db1c1a4992c', 
	
	
	 53: b'b1db44c6f397610e70fe2ea3bcbfaaa8b27bf38',     54: b'2e3fd416bf00f907c0e1fca3fe2eda72570e205',
	 
	55: b'6685c6dde3fa4137630b355876699e61b1472e0',  
	   
	 
	56: b'79091909d85fba330bc669c10a0b90b0bd46786', 
	
	57: b'bb2e665e5ac30d77f7bfe51a5187a409014f9ec', 
	58: b'127ed5118fffc9997eec3cd474197e3a71c59c8',59: b'f3607622bd1e9c22cb3e53ee13d789efadd1d41', 
	 
	 60: b'53ef90c3c86f311cfb2f3dbe78027c76f8c5325',61: b'3f789ff4888645f4d3c7f0b8ad432e0eeb0db09', 
	   62: b'8efd49ad2769fe16e111e33400bd9817b2d9af7', 
	    63: b'28a9c24e4a8ed2d1dcd195bad4708f345bfea6d', 
	64: b'f7b4e756e70b3c70010aad04332a6bce82fb3c1',
	
	 
	65: b'00eae1ab0efd3cca62fb1b058860e3acfebcc52',
	  
	
	66: b'936f53fc152e2084763dff39c3412ebb52f2be6',  
	67: b'55ca3e8cd1bfb731b8c21efdbafe8e270dd6948',  
	  
	
	
	68: b'20458d736ed70209bd1996703d6efca03781f7e',  
	
	69: b'479f4bd83d26eb5269362a05082cf7c3d9a20c0',   
	    70: b'575539d3c568704b45324633496774e23de8aa8',
	 
	71: b'16f3352d029f3923bf3d000ae987bc8376500d7',
	72: b'7b6b78c9ff180e3f92b2e2ae20f5e4d62a56dd2',   
	 
	73: b'463907be8a9702400426cea25534a09863164e7',
	 
	 
	   
	
	74: b'c48e6bbc3808c61a962db0343f9cee768659034',
	75: b'ef7d86a24aea736b88386a61d4a6f75a491aa85',
	
	
	   
	76: b'4bb00915b99d8e82adc195a269bc0a9b0f7c831',
	  
	
	 
	
	
	 77: b'7217b49d6622e180229932204d1da1d2773c0cf',  
	
	
	
	
	  
	78: b'e07d545c4b11f77ada1ad626a573b61547d197d',
	
	
	 79: b'c6e59fecab372c546ec982e184506988ddb5a5f',
	
	 
	
	80: b'f5ac09fce0d8f6fda26804d74f253cf429b6ac9',  
	 
	
	 81: b'b146f87f0b980aca5b462522e6a920ab7750cfc',
	
	
	 82: b'e1d5e925673181599fcc76913cfbf33928dae6d', 
	   83: b'115fab1ce2d98f313aa91c1d562b2c44566d2a6',
	     
	84: b'453a9c33854abdbf63b3c399eb60860ae8d8fec',  
	85: b'0f6f95d22b272a697e025ae5d2c05abc3e159fe',
	  
	  
	
	
	 86: b'5a8c50d0357a3c754dee3c979d1e4ebd823d138',
	
	
	
	87: b'886588f3f5a18c6c3ce4dc705b789ac38532f21',
	 88: b'c135661dcf8d240748b5438272333c3a5b003d8',
	
	
	
	89: b'a2090098e1bf3a2295d8a86eb42b6435ee641c4',
	90: b'bd9c241e23bfae69726f5964b55b2a749300828',
	
	 91: b'b6c53fde572022a0e4e4cd32f1d0e891b64d6a5', 
	   92: b'16bdd0bd7aa3f59d579f6af495af2e1691490ee',
	
	
	93: b'56f24cc36a1d733345cadedd6afdd7926eb1c34', 
	 94: b'8dfd53a12d9889142fb6f5f665303354e739140', 
	
	95: b'bbf60fc26171ffee8ea935a8db2a08176a4819d',96: b'83081a2e179f6e0802031784beff4b3e0a44581',
	
	
	
	97: b'219a0ac78fefb4da4c0755ff9fa262338a6c058',  
	
	   
	
	98: b'fce5b21d0cd1c38d5f3590925dd543c9ef57fea',  
	
	 99: b'edd32d98a9f16f350b3675f6ea2c94f37819b75',
	
	b'bffcdfcdbdedceabdadedbfebecefdcccafdcef': 52}