class aeaeccbbaeaeaccbfeafbbecaeddcdefcaceecb:
	fafdbdbfabedfaccefdfbdaebaedcbdcecefedd={0: b'10f29ca8e1a0abcc68405477a48091a702d9f37', 1: b'c002ca889ac60ab57d39340f417436513fadeb3',  
	    
	 2: b'e380d676b21965a06f2f36afbab2578ef398686',3: b'9bca2257d68844bd5784ad60e66bae62617d2e8',4: b'68b0a8c483ebba842ba1fe3bd43c4bf2b42bd60',  
	
	5: b'4a1a9d76de930811fee0364dd9c6b5755fc4c97',6: b'c041e16eb0c4f1b0b1c52c8dab1cd5fbe35392b', 7: b'0952505a56034b12cb92c1c221f7bc459eb587b', 
	 
	
	
	8: b'e4be9dafa67abd7c14997d64536d75edae1f079', 9: b'8a6cd9e3f71e099618bc06dde2e7572b12dee73',
	     
	
	
	
	10: b'8760a808c761448f6959cd9a259267460e4fd06',
	11: b'9721d0e98ec563efa731d3c542adafcbe39d0a3',  
	   
	 12: b'eca19fbfda0c96c9fc3a9bd85d732d11b3e0e6f',
	
	  
	 13: b'7116e29a37649fdebd4bf302acb089e41d02ee4', 
	
	 
	 
	14: b'5a1d8d2b3db1dd1406f49d3b4a4fda8caa8e61e', 
	
	
	
	 
	 
	
	15: b'61e4660d3ea908e2c3078bd4ec44d725f290293',
	
	
	
	
	  
	16: b'6f625ff322f840d4a845f786f9356e6b6f287f4',17: b'885c21d496a2ce1f27a96a898e309752fbb856f', 
	   
	
	
	  18: b'cf599169772e3e54c789b29434f49e337fbc745',
	    19: b'4c44a32c57d2a4c81ec09a074aad365d9501b89',
	 
	   20: b'4f1684526041996d3b76144212d7575a1c37ebd',
	 
	
	
	
	
	
	 21: b'd88dfc665ddd39e704d78307d9fb83f74cc6dde',
	
	 
	  
	
	
	22: b'5677359e74e5c51116e435a0fe561bb9f52f92f',  
	 
	 
	
	
	23: b'cbc0b1eb268855e22cd8abdac300ff01856f652', 
	  
	  
	
	24: b'95236c4282291b7871224a971ee881288358b31',
	25: b'fc0042a5b43bbc969749b8c0476773066777df8',26: b'f5875ab3163f9326e88b8593aad2a5ea3edf93b',
	 
	
	
	  
	  27: b'0e7cc0029b9cfe9dcda294eb0d00966aafbde5e',
	
	
	28: b'ac80cd6769cdf46cf1ee094db5bb728e85a91d9', 
	29: b'76df967fdb59fdf9b07f6854220822b56e08dcb', 
	
	 
	 
	30: b'6afb2332ada945f6c2a31f0b251387301f903aa', 
	 
	
	 
	31: b'442acd5ce6d0562dabe5377fae4cdbcfd88c704',
	
	 
	
	
	
	 
	 32: b'2da23601c1d7dbc49ef14807ebe141c2edf7c89',
	33: b'df8a3297435789f0899716cde5bfc35b032ebbe',  
	
	  34: b'f58d876d186999a1853377d5bdde499b90da891', 35: b'620b09e8817a6b01700da3ba9bdcf6a1dde0957', 36: b'00818b91b8483d8beea6095537a1ab09b818be0',
	
	 37: b'e06b5798dc0cdd1bd655cd40f79aa48e2bf9752',
	
	  
	  
	
	
	38: b'085fb5b4cbe3ef3559711f1cb1afae781e064cc',
	39: b'79bbf38b510cfc64ad7b995cfb8f5203888689a', 
	   40: b'2501dbaadab57d9a454dc55dfe17114243884d0',41: b'96b09453bd5b9319cd7600e2d84c0e83f8ec137',
	
	42: b'627fb52ff18510a6e56ef1f9c9ea08701fb644b',
	43: b'c7d0b341bce7924894fbc95a02138ae8dec71cb',
	 
	  
	
	44: b'07258856e1190febc4c7ca62879767225fb847d',
	
	45: b'5aa97d2d31856beadd676e9c970c3600cea9c72',
	  
	 46: b'f97a915fb32d4bf4c96d88e61e0c799102d3857',
	
	
	 47: b'af145c823d87c5b3ee06aa67839551ba8901002',
	  
	    48: b'824dda49dc570dfb7e5d72bab878d4cae049cf4',
	 49: b'4b41e0114e39fd826403625a9b9aebf45155467',   
	 
	 
	
	50: b'e742f5666d96dad1240822d32824bdde941f5e0',  
	  51: b'e897a0f38eff1c362b91242326d9f7f17987140',
	  
	52: b'fa3baab6e91df2cc141a9ee89193be55a2a2afe',
	  
	
	
	
	 
	
	53: b'aea4ede3574e3d2661eec7944865f6a858501bb',
	  54: b'518383fb00473f945ac50e1f0a053a076e34026',
	55: b'e1dc6929e006a912f016168dc137eff8c26851b',  
	  56: b'be93261e90d2ee28faf18f97fe9990f42670bd1', 
	
	 57: b'd8344563e03ecacc5faa127dcc181e5800fb0c9',  
	 
	
	 
	
	 58: b'0acdde7c3ae4077fba068f021a15927c00ee940', 
	
	  
	
	 59: b'a47a3aca9a482081f6c7689eb5ba10d2112a4a3',60: b'fa04b18b40da9369ab877e4a82abe1274d49801',  61: b'62edfb3032fd334ae99597dccc0cc2ed376d836', 
	 
	
	
	
	
	
	
	62: b'ec32170f44379ce86c7ff502d8d9fdee77fe86d',   
	 63: b'e42310f66358fda9d898771b81027819621a4d8', 
	
	 
	 64: b'd769ffe18d9df2297bc890e0c58190258a11e9c',
	65: b'5cafc8149fbbf8d594acde8d74749cd774bd8fc',
	  
	
	   
	
	66: b'9840b60ecf09b7689c9aa510d8ea8fad4a99dac',
	
	
	
	 
	  
	
	67: b'0b2b6b18df69817e319c073a1f41c1ea357f765',
	
	
	 68: b'14d7c417a0300a07368e6e7db5f7fd3c4320e5f',    
	 
	
	
	 69: b'ee18ab8e5ac41afe3e99cb6c5d02b6629de9170',
	
	
	
	 
	 
	
	 70: b'72cc415ad389e3b514657a0cc7623295cd895b3',
	 
	71: b'77ebe406e4ff65d6c1c76516b50ca9c56c3596b',
	
	
	72: b'32e76b050e3ead8984f3fe0fc237edcdbb6e4dd', 
	 
	  
	  
	73: b'827691d079a03d90fd53561eadd12cdbfbfbc27',
	
	
	74: b'b14bb4b4ff22cb5b3afc761208d93c490e28dbd',    75: b'051ed4b6e28021bb32e81bbc00aaba2025d7b7b',
	
	76: b'b68f346e235fa744e890199d3791b9fff7ced04', 
	 77: b'870f1333c3fba476b10afc499f5ed9c32308447',
	
	
	
	78: b'c7c50fd030102841691c643451f4ab3f03ad2af', 
	
	 
	 
	
	 79: b'f86db7d19a32e658420e8acc4d26d8af2227269',
	
	  
	80: b'80a1ec97b9878697bd17f3ed7061930afc3aaf0',   
	
	
	
	
	  81: b'5fc20b3b98e625206d68c7db115e900b07755f8', 
	 
	
	
	
	
	
	82: b'0d43f6075214fe4d3326109fc5001ca3b425c86', 83: b'2f1d6b3f458b734f85b0f5dc11848830d08642c',
	
	
	
	
	 84: b'17ec38f8dc9ea9735c5b70b456a6de261759e62',
	 
	
	 
	85: b'294fbd04a65a179a4137dd957e06cfb75a67c4c', 
	
	
	   86: b'dfc4ded344b130df36dd4a1360bb8e875f47f6a',   
	
	
	 
	87: b'1b72099865fd3dcf5abf22a5e71761a259b7469', 
	 
	
	
	   
	88: b'b3593621f6fc9ab608d2c909beb5da9508526d8',
	89: b'c633c838d5c78b57f290b8b84a1b4b901ee441a', 
	 90: b'd8217628242aaff030057f6ee2fb57fe6afa6b6',
	
	
	
	
	  
	91: b'ae834b8464add7c3c7bed7c0b64238050508ba2',  
	 92: b'634fac9d24cf3b42a9e6489942e5efd1db56411',  
	
	 
	
	
	
	
	93: b'c96ca97ef64069ee6876fc2cb0923b398828494',
	
	
	
	  
	
	
	 94: b'0accf32eb89ce6a15209b043d881f6546ce4138',
	 
	95: b'0adc8419e52eba4426107fdadf6e599aa3b463c',
	
	96: b'80ed4a55dfe2825a723f8629f3e7ffa52a74811', 
	
	
	 
	 
	 97: b'07d70a64ec988185151e01de00c0cf1ad6e7a9b',
	
	  
	 
	98: b'ba1571a714d235bb125c6a15fc80ad0772d961b',
	99: b'9a467d3611d2181deec5832e9f15a656d9f1dc2',
	   
	 b'abdbaeadadadeedabdadbcedaabdfdbfcabfbfe': 99}