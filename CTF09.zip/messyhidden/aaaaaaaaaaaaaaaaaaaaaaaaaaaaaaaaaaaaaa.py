class ddbbdfbcaefdabdeceecadbcfeecbdbdecfebde:
	cbeafbeeaefabcddbbdeecbbcbddeaebcbabffb={0: b'fa2285ce180f498caf2c572bbe1021e3cb9a14b',  
	
	 
	1: b'70ad183888195eed3d0518de3031c02b704cd52',
	 2: b'195b66f6600648e351e8076322098bec7daeb53',
	3: b'a9b80024a8cf496bc793280e1937da9df94a6ac', 
	   
	
	
	4: b'229866d3becb1b512f300e2b8e69089b8df0934',
	
	
	 
	
	
	  5: b'55fee9061d4aef3dae679fb01c183fe1b91bb6b',
	 
	     
	6: b'fde6adc22a69bca48010544bda37c745a4e25a4',   
	 
	  
	7: b'389a12fc753bf4142ea7f0e6e6af17cd3b618b3',
	
	 
	 8: b'10e3ffb9b939fbe28788b8935b9bec3f758dfd8',
	
	  
	
	 
	
	9: b'de656dbcbf978b1dcba5cc75fd08f05eae5f2c4',  
	10: b'107e6f2276fa4d8f79d2740438ef6b810873158',    11: b'4917cc263972f6cc0a0acd47ebda64ca642595d',
	
	  
	 
	12: b'3b07eef6170a71f47dd282e98ae8c7c5bdd4cab', 
	
	
	 
	13: b'bab226f9dead6f9e498db5dab1de2c7f89bf9ce', 
	  14: b'e34664b0669b5d570b58221b7ced0ccb8b3d446',  
	 15: b'7225059b346db78389c58c23c158f1ae821ba5f',     
	
	
	16: b'7bcafb20a4bb7df26adb3a77fd7ab67672d6f98',   
	  17: b'5af8f223bbc375c34a61877224702adb6086bf8',
	 
	 
	
	  18: b'9f3b496d9aecfe4926a7ef4f0e53e79bee8c0d5',
	
	  
	 
	
	19: b'd9de769cce7fcff30aa2f38fdd4b51b61c0810e', 
	
	
	
	
	
	20: b'041337777d8301c8b0ae9a8adb1613cfe2cae6c', 
	
	
	
	 
	 21: b'00db500b940e398e40e92faba0bcf87e4678dff',22: b'b385b43fad4ed789645f1481589c418c9612eed',    23: b'f3128938d0c50c238b64ed380ce6616fcf5be34', 
	  
	 24: b'507f0deac88864c0150ddc1a04c2659af809ea6', 
	
	
	
	
	   
	25: b'5d238f48c46d06e92537a2932169d06954a9107',  26: b'c0f0754791e5d50895bc66ef6128c6cf7adf922', 27: b'd2c12be7f66326b2e5247f19fa3568b543e6fd2',
	
	 
	    
	28: b'95d49c0232131784bf49b9896fdb606eb8bb9a8',
	 
	  
	29: b'30e3fe97ae1edd5e7e6229ba38b61ab73cfb90d', 
	
	
	
	
	 
	  30: b'67b41f1bb93d4b139bb8d07be03868155175ce3',    
	31: b'053b40c8dcd89369b70d4b5231cb44d708175ea', 
	  
	 
	
	
	32: b'0355632690cbafd68a305011266343e7e2b49c3', 33: b'7f488edc8df3ba14b2a2436c30bdd89208b7ab4',
	
	   34: b'2cd3085a256c29098bdac786315d3f19276167e',
	 
	  
	  35: b'0eca9fca47056e1a387ec5030f2d94c0a113ac9', 
	
	 36: b'0417083fc7e67e0723f9d48da11230a559b9df1',
	 
	 37: b'53a939eda17e65a4ca6396dd1abe43d021cddf6', 
	  
	 38: b'8d691fa05e101bfc94f2ca7f0ae2d64219cc347',
	39: b'c7f5e6faf42a261f8e0ec37c0b87da9ec47800f',
	 
	 
	
	 
	
	
	40: b'666bca420c604cdc7b5dcde5aa2e88d871746ed', 
	 
	    
	41: b'f408bad4cc6e50fd203e5e1d313080bc2236e79', 
	 
	 
	
	42: b'a73d169b7b7d290b139f96683aa44188c6ca8c4',
	 
	
	 
	43: b'6078d7aad9a28e689708850e41cba235d485de4', 44: b'1e4cbace7cbb263461d961e67014a4816d33b2c',  
	
	 
	
	   45: b'a4b390fc2c1c2d797ba93ba9183325fa666a5c4', 
	
	
	
	
	46: b'2f77056de11c90e50eb88032cb14fc9f5def7aa', 
	  
	47: b'f52ccdbf192b993e45ab39290e415e0b9eedb48',
	48: b'd58928865a3276d50d7e26378aa7febe6548e50',
	  
	 49: b'85d259fd95c83b72cb8e5db5708c86647740a7a',
	  50: b'1bcdbd50c52ab5819eadd237f45c850dc06ba90',
	51: b'7b9960aeeca1e8567b03b50d2a04c2a75d0855c',
	  
	52: b'f8fd283d9abc0beac2c6d87bbe11448fedaff53',
	  
	53: b'8aeb29276b99e1e836cf4e0e08d7f401ee30e70', 54: b'c8352ec078d240111f6416fd6dd0f35801bc02f',
	 
	  55: b'66ac3dc6af5e6f907ba5ad1aa0cab55b2846149',
	  
	56: b'2c593c64cfeb777c8cc026a5c679e98f69df2da',57: b'c64ae39d977ea8f90a354b46bda16bdeff77ae8', 
	    
	
	
	 58: b'60d1c97bc6bfaadd7f160bbef7f75137cf20204',
	 59: b'eaeb03ce761dd65fb49d7aec8d00b8f355f817b',
	  
	 60: b'9fb7e703c193a372dfffd0f8a59bb98d3c96f82',  
	 
	61: b'3bae56cecdf286373831717c7f764b09648396c',
	
	   
	62: b'06c24941e634157972344dadf09c0b175a10267',  63: b'47dd4fd07b5d70da3fc773a9dcba6b1e37786a1',
	
	 
	64: b'8086b8fc1d5d4e822e744732d4191a012ad4dac',  
	     
	65: b'9ff35c7cdffb771be51f9e6a76fd2fa590f615a',  
	
	
	 
	 66: b'f54392863835c5ee0bc176d7f4d85e56178106d',
	 
	
	 67: b'7ad6f1390b6451467d641ba7c169ec5975e7d8f', 68: b'1b0db2d6d8fb0d3f1599e593a1609a794cbf8d4',
	
	
	
	 
	69: b'a382fe338c634be1e009b85eef50414bc14582b',
	  
	
	
	  
	
	70: b'e26e819a75778cb056472cdcb6600e24e36b4a4',
	
	
	 
	
	
	71: b'921692a284f9e6c8fa80edfe53eeed8da65bba6', 
	 
	  
	  72: b'0bb90688bcc55a9afc55ed962ac0e6cd0149b70',
	
	    
	 
	73: b'0530ba77593eb34971e1d2e3a0a5950e1141447',
	  74: b'778508be7538bc61e83c20fd3986e040f48b3ac',
	75: b'49f37e3e53bccef9b174f4f3b16e663380a92c7', 
	 
	 76: b'bf6957bc87b09d1617091d70dcb047ea0e53bf5', 
	
	 77: b'2971d51b7c26ba51277b66e448beb093f99e5f3',
	  78: b'cc60bdac46fc85247f78969ef26d0bd19fc08c0',
	
	
	 
	  
	
	79: b'958d54715d686787864e62f56af34df3e2fbef6', 
	  
	 
	
	80: b'f3ad14dea6a5d6e826310a8891ee1f163403cd9',
	 
	 
	
	
	
	
	 81: b'9532713134640bc8cd9c4a14ab22e0699100aee',  
	   
	82: b'29889a1a836264023d6bbdaa0405b04b6b24957', 
	  83: b'4e94b36c3c38e5ecdc91cc2e774f3f078304845', 84: b'bdc6dec95128d5fc1fd72d906b4fa75aeca5228',
	   
	
	 
	 85: b'73d68f488d4e7b1ad6a9675e52f2809dd0a9bfb', 
	
	 86: b'2816a06ee24b8830154dd5223b89c34f2f19788',   87: b'8ccafdc6cc275f4876460ba74dc92cb6bbee901',  88: b'd96888a514588e76897fda1574a7ffe676abc9e',89: b'513490bb1850435d549dbef2e554370e678c526',
	
	  
	 90: b'e496a9314e6913af548d1595c47b4c730b5ea51',
	
	   91: b'1f7cec9423879b90230d43a7e7274b03f1c0d02',
	  
	
	 
	92: b'5fe330ee3662121e40788527e43dc8a066a2c6b', 93: b'a75fbb5b6d9c09a05e50adaae4d830eea8bdb2c',
	
	   94: b'7f1fd025229b7d8934c6a16eb0fb21b0b343fe6', 
	
	95: b'307d2987bd07051bfc2844cc1f60715d152fea7',
	
	
	  
	
	
	96: b'728d9d9376ce29d656e79b4852194371d2dd7fc', 
	97: b'85020f570e56ea19b4cde3e8b839f5ae2f758da',
	  
	98: b'257b6b65cbe3734910ae45bde8b14079de272cd',
	
	
	
	  
	
	
	 99: b'aa7ea78ae146f78ac4d708c0ee16c3e7f9f1ef1',
	   b'dbdafffcdbdedcadafcfbdbfcaeddcbbdbddbea': 50}