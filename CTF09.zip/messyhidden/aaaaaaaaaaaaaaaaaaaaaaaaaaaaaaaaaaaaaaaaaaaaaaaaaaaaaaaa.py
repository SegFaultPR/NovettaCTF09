class cdbbbddafcebbdbacabedcfeebccffebefdcfec:
	cbbeecdefcdfbbabdeebcdcfdfdbbcefffccadc={0: b'e3fa2cc2c53ee6ec6dbcba34914b55d3c6e8016',  
	 1: b'e4023d130acaaad08e2d6a63caab0d7f7db1605',   2: b'eb06fbb2f1b99ad3469ec9c27f8b27ac4bb2845', 
	 
	
	   3: b'2f2700ae9be5dc416a4ab6123639a663f06d7ec',
	
	 
	 4: b'4af3217ef592df42087b74b593cb715de9eb450',   
	
	
	
	
	  5: b'be66b2e30ea5c2e052b28e2e3ab1b37f46008cf', 
	    
	
	  6: b'b2e1d97e5c111c3de96d9edb5f7ca130bf0b8bf',
	
	  7: b'68b0d4f77354a45ef9cdd8b271219e2c79e940c',    
	
	   8: b'e8d019effba7599da6a48b53083a6ad4463f237',
	
	
	  
	
	9: b'4ad56e3d2d2df547f9ae956278b7a5861f1b27a',
	 
	
	
	10: b'b52979b56817ef58a07d1a754274e80f0e567e4', 
	   11: b'6142f2bed4f5725bbb8a99a2fa1e0d1d373500b',
	
	  
	   
	
	12: b'4c7b6b727043dfccf2378c8fa4ba73c4ff6a553',
	
	 
	
	
	    13: b'f9b1dfd198ffb07c8357d68b4f5e331df15944e',  
	  14: b'e13e605c1514216d49f907d8bc4af3776c9c899',15: b'fc13198e06028ec7e1203b298276edcd3a687eb',
	 
	
	 
	  16: b'0f3e5aac145a6523070ab212df4caf8eb26918e', 
	
	
	 
	
	 
	 17: b'69f59827f998963e626bd2521651375e65dc712',
	 
	
	
	     18: b'29da13df711bcb9b23b7b5906dadf5edce4e050',
	  19: b'8f052c459068760d6c02120a0ca37f1cd089231',20: b'177b02f673132f03ce063a65634f5b8eefe3ad2',
	  
	  
	
	
	
	21: b'e93ba9b4eaa10eddd0d4c8e0961d14006770d09',22: b'dcb8ec2021fea7ee2545425912acd99de295cc0',
	23: b'e06d12797aada2679f0f9f2ac75c61a95650450', 
	
	  
	
	
	  24: b'bffb52a223c828c72c7a8c745a1b1b5dd44de56',
	  
	
	  
	
	
	25: b'6e68650527f6caedaa59a53414a307de5a00931',26: b'9da7f98f55be9d5359ca49c09520a1194429d3d',
	
	  27: b'0483d452840386f4b21fc7cb31208ab21ba7c88',
	
	
	28: b'2ce18412a7fccaaf1cec276cf41e9654548132a', 
	 
	 29: b'0acc28363c008875030c2cac19d8b5b095bf880',  
	30: b'48b682e7e4daad0023f3c79e380e94fe2c4182c',31: b'af0d20494e520a3a23479972c5b3ee63427f783', 
	
	32: b'6785cc7780ab8b3f58857f980491e920dd9a0dd',
	
	
	  
	
	
	 33: b'0683528db61acdac1ed3c5156cf50a2c4e2b039',
	
	
	  
	34: b'2471c1af6cec084657d97d0264c884c5f612052', 
	 
	
	 
	
	35: b'f5f8de96050bacd5bf7cdacfabe98d7bdebd814',36: b'2a2b2a84eeab16a0c2a568184d0fd618248e84a',
	
	
	 37: b'7bc76eaa00d963cddacf04f2fbe44e618ab5157',
	 
	
	38: b'f5962c0fcc453871f68b1deba13b0fd1a349cf5',
	  
	39: b'87a030a7fe8ffca87624249c32c17073b3a449a',   
	  
	 40: b'0b80c2c9d8944064b83d65a981ebac29d76a080',
	41: b'97e5d0a7656fc5fb89dec10e6e83c9a3e8c7db4',
	 
	42: b'0521db49415b4301bb7c86d3e0ed4b05defe0d1', 
	  
	  
	
	43: b'b996ec3bcd8191d64cd903eb6babfb6d3ee85e8',
	 44: b'920272388ab64081b038eca2902ec7d296afbae',  
	   
	 45: b'6d9bdbaa14e50069776838b38b3f5f8bd6ef64b',
	  
	46: b'3661004cbe939358028c338718ecae9b51b9758',    
	
	 47: b'ef80a51e10c8e284f9f4b1141a17be2a8ebd911',48: b'550a650e7129e50a523a04853d13f8df3cb06a0',
	
	 
	
	  
	 
	49: b'924017c1110d332b0c3c98551e8abb89f0479c2',
	
	50: b'b9aae7c323a9402227046bda5431606ba38dcb5',
	  
	51: b'1da0cdcd64ce85a566e2d1901c45a40615d8239',
	 
	
	
	 52: b'ff63e042f927b885cf3aa9d1cd4cdc76d9d28e7',
	 53: b'58ec2197d2d8658ecdfced81bcc3e040b7f6bea',  
	54: b'bbacbf7a15bf106a4cf289bc87c46566b9b69da',
	 
	
	 
	
	   55: b'07e77f51bd300cc08a12b198b782b14760be177', 
	
	 
	  56: b'c9a745b3c5d39d5552eb27e6f65389e60d82501',   
	 
	57: b'12721a26a32d0ac24ca6f94d0a5f406c13c2a34',  
	
	    58: b'e5b0c9e54ec9909be2670edb5b2def48deb09f6', 
	  
	59: b'1e789b8b2d148af96a0f47718056610e1770f6d', 60: b'daf98c1365d6481688f6069d98ed226bd0ee20f',  
	    
	
	61: b'1dd8e75414206c09ad91f74daf7b3aad233a4eb', 
	   
	  62: b'1f80dac86f7221426ab4c8a4659ccc6897a6ee4', 
	 
	63: b'75baafc937f239105106c60b7d0d12517109583', 
	64: b'4f3f52fc3414e8e0f232e3701c83679ba1d10c0',
	 
	
	 
	 65: b'f3ba61d0dca2a55ff10cd48dd5db5eebfd739de',  
	 
	 66: b'36d61c586448cfa9c032e48d5b1429f3851f227',
	 67: b'f090ec0262a2de604c396c41b1a7fa7ec24dccd', 
	
	 68: b'24f48fac0deeb941dee95b9370d83d6df13de2c',
	
	 
	  69: b'f6ab826973c3c9971f17d13df57f4f23dc7d05c',70: b'55ec769beea844b29dea5f20076147882c54de9',
	71: b'84d69fdabff8c89c3a4094cb17f77993edfd02b',
	
	 
	
	
	
	
	72: b'a2e2e92f2cfecc390f0030e296177231fe9cd84',73: b'626c2997ee81a0dfb49e9d55ce38aa17e013f3c',  
	 
	74: b'511e04d67fe2f2ab2a1d3c3ea14823c48d2f64c', 
	
	   
	
	 75: b'125517795a7f8cf8c8552f07fd1f406bbfacfa2',  76: b'9be8db4bd7b5d731ea507b91489ccc2e69b0bad',
	77: b'2d12aaccfaaaf4a17570ae02b41cd16e8e151ef',
	  
	78: b'82a8c406987733f8c0648919f9cdadb1850386a',
	
	
	
	  79: b'57b66967acde63fd7b70b3a6bc1f0517fee512f',   
	
	80: b'62beec7c97c3d6db47f4bdca331939d73ed8162',
	 
	
	81: b'eb13c217cff1b956b72c15cb5eb62e43d283085',
	  
	
	  82: b'8bd3aafae4e1a10237a8d93a271be79071201fa',
	 83: b'a2284ef677c2d1ee042b3be7addc08136165e92',
	
	  
	84: b'02f0de9d3e3c7fa631c596ba422127bbcfc7d62',  85: b'e9868ce8ec7361068b91764be68b872dd796e88',  
	 
	86: b'a72e53c8b7543fabd05aaa03b9d3e55799a8286',
	
	   
	 
	87: b'5ec6415380562f0ea302bddebefa928788bd014',88: b'72b8bf06de20a8d21488da41884e164443ebeba',
	 
	
	
	89: b'685cb9e4e13c21d190f4fad4894147653313576', 
	
	
	 
	90: b'6e24a2b530b07a2f28d1da6e75c19a23640995c',
	
	 
	
	
	91: b'891fce69c02f87b5e7501b3f29aaa97932c8b69',
	
	  
	 
	 92: b'b224c7b5f3aa32d01820200629fdabc5e37600e',
	
	  
	 
	   93: b'9ab1a9122e5bfa04cd3e5f2b9dbed086d4a745c', 
	 
	
	 94: b'7ff9decaee4dbaaa0d533b2e917104ec1b53202',
	
	
	95: b'9e9bad5f37d00f4cfe88fad11caf888710e100a', 96: b'db45fba05a0a50544aff682e88b9a32931792b5',  
	  
	
	 
	97: b'998700b717c4ffc648752a3a183407cc45703a4', 98: b'de900afada8c2a0d5c808824cc073a94156c44e',
	 99: b'611dae57ad766e64b7d5995e18ce36d87befb9f', 
	  
	 b'daacfcbcabfeceecbafccdfeafebcbecfacebdf': 7}