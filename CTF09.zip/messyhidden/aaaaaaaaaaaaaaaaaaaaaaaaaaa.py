class daafcfcbbddbabbceefadbfdbdcabdcbcacdccc:
	adcceeffabbdebfbadebbfeecadfadfbddbbeaf={0: b'f5efb6e93500ee4e7bd82fb68da0036d2d17c52',
	 
	 1: b'6e0f42b74395213aaa1f519baaed4759684d389', 2: b'ed11ee857190a8b833da6d1d27b6d7408e108b2',  
	
	
	  
	3: b'78f5c9fee3cb042620b6936a6f418d9a0549e1c',
	 
	  
	
	
	4: b'47cbbd11aa13a304cecdbf86e1491d31cdf461a',
	 
	
	  5: b'e92e87d50e1dd5cdd621e16d049d3ba1bb02a1b',  
	
	6: b'321158a03dcf211ff88e33cfae129cd0e1228a6',
	
	
	 
	
	 
	 7: b'e65ceb58ca6c9a5285892673f7f5a54c46fff35',
	  
	
	8: b'453d323d4c20fe30991b63f23b1bb5e2a1dc655',9: b'f14bb50974d51bb9436a52873ec9e24e9b5ce6e', 
	
	   
	
	  10: b'8b34cdec021a390ac30aac74784a01a0dc768b4',    
	   
	11: b'13e7a43027ed1ba155be469026f7941697d80d6',
	 
	
	12: b'129a731ea3d0a60df1caccb055f5f237a0f4798',
	 
	  
	 
	
	13: b'8617c7987c2e50e80c830d1d502ed4b2766bb88',  
	 14: b'c2c137173b19f93d7b078b00a2254ef10e51971',
	 
	
	15: b'dcfe85371135ef24c0b6dae64813d40de9dd900',
	  
	
	 
	16: b'76435799f0aa49500a01a79feb2753469bf6260',
	
	
	
	
	
	
	
	
	17: b'9829c649acfc271e5e8835c5cd9f4908d005733',
	18: b'36a11a60cf2f24db546d0a2f0a9afdfca66c548',
	19: b'7d7af78adae471cdef3ce674b171eb35973ff93', 20: b'55887fb454d43295a745775571d3daf55a3e68c',21: b'f4e1527401952b6e8ade0d4d39c917aefd7111d',
	 
	
	
	22: b'415a0f2702f6b6012048c48220b3d9c1acd3111',  
	
	23: b'1a99ad7e240e809e422672efa366cfde4705d38', 
	
	 
	  
	
	
	24: b'fca1d704684c8366fbf382a883e198d2100400d',
	 
	
	 
	
	
	
	 25: b'f939f8850fd0115ee99aa8d15b5adc3f9a40d3f',
	 
	     
	26: b'0e436ce673f31b6851d09610df4d42ac3b65721',
	
	27: b'efe7c7558e2d1e40627347afa142f93420e9c3a',28: b'0fc8d39f7f17f4704484f2bf6632c13c7153c8e', 
	 
	  29: b'8a1b0372e3a1b8b25b8fc9315c111fb8bded674',30: b'452ff34de2a9844f3c26cd4623f6460a80bd45a', 
	
	31: b'9345a1502994ab7721ad4ad3c07d90f54df522c',
	
	
	 
	32: b'375756672bf64b1e208cdffe4c1e126eedb40ca',  
	
	  
	33: b'd0456a40731dfbab54cd3027c54d379b4f375cc',
	34: b'eb59b7a6ad9ab9bbaf0cca90de6bb1c08adc380',
	
	  35: b'6981e839a23a42a684998ef2ce54d31c871bd10',
	
	  
	
	
	  36: b'cfaea1b5f8f4d7552b73fa49a6f24586463232d', 
	   
	 
	
	37: b'0a634617640f3c6c88babd8a4a4cb5c15de4b93',
	   38: b'3ac394e71bdee66357bb5ef19016f05c4966225', 
	 39: b'c1d3a76b952eb111aad16cad33848b7f0ffefe6', 
	 
	 
	
	40: b'9e2ce2d37526fe7f8488cb2bc6e561ff9ab132a',
	     41: b'ccc5705b58e3f3ea562e4b318192b69c4e719ae', 
	  
	
	 
	42: b'0fad3ce26b707b5230deafdb3dc8eb071671721',
	
	  
	 
	
	 43: b'da6dbabf75d6c64822fc7994406e992821da16f',   
	 
	44: b'fe7d2ee70890f05e51003b23e56879c1f9c0a48',
	
	 45: b'2c269b79667a6de55b6108ca00cf1071bb03380',
	
	46: b'be869b26b7d1ed177ff344749da7dac306fbb38',
	
	47: b'a543706b4b0c010ba94c67fe89689f2e5edd085', 
	 
	 48: b'90c474a0d1f241c84b99a2df08cfa1311caea8e',
	
	
	
	
	 
	
	49: b'71fb275b76e489ad475448ec149ffca8bf92150',  
	 50: b'd399a30ad0252c3d6366f7b99df05c1f44c9008',
	
	  
	   51: b'1bc599dc48de6908cc074c37b6d028cb0050869',  
	
	 
	   52: b'b99ea896e24fb124af1f0136311bbf27a2c31e4',
	 
	   53: b'415aa0297dedd338028cfb840f9ebe4e583036f',54: b'b4ef4c36fef86f44f6fd90a3355a0aca4149c02',55: b'a82da4f25ae36545ad1aee452cfbc1b2b68f482',56: b'ca37dd9594e7f4f49ac9950b391f5b686d176af',  
	
	
	
	 
	57: b'73281617f22c7d2db5e81b3c0f38fbfe002dc0e', 
	
	
	
	  
	 
	58: b'aad96477f6d0e7379ef9751c683be8dc378d5f7',
	 
	 
	 
	 
	59: b'0b900601ed86f9f844940aa47f33e474075d88e', 
	  60: b'906950ed2d45a5290330e19a2e990465db4ac16', 
	
	61: b'e928ad0972a9bd65ded4ad49696a7bddff83111',
	
	
	
	
	
	  62: b'5fb3d6174174e6636ac32a1d61a3a7c4ad50134',
	
	63: b'e039e20cf6732f5a165178413bc05ec0da0fd63',64: b'ac0862027254f0ea65360c3b53d865c993b9de6',65: b'4061b506b124b3943927dbb9aa1a256d421a3e6', 66: b'fa3a6d78beb6b98f3793ff7a40b2d40137262c8',
	
	 
	
	
	
	67: b'f0d6ac277a956d8a0d46e3eb4952f21592b2ca2',68: b'093d63b4c033b7777598569c662eca2598fd14e',  
	
	  
	  69: b'75f80107462bb3a3fca08532cb533508cc83116',
	 
	
	 
	
	70: b'9a540249a7af3596825939ebd9e1b672b0b27ef',71: b'1eb2e3f18edc892500a76407079adc93fa24576',
	 72: b'8224afb8cfa62ae586ec89aa3c4769c581c25c2', 
	       
	73: b'f7da20fbfe7d14107e7f96581ea1ce78112031e',74: b'293beee50c85a585476a0eccdc625ea5f856096',
	  
	75: b'8f62fba74d40673d1326c4390de9e32190d5a59',
	
	 
	  
	 76: b'ec32d806857d62ac022807f73dd0fda212eba9b', 
	 
	
	77: b'191a6a6671142189c3f2896af23d408d43d03fb',
	 78: b'1d117d17bbdfbba2a2de09c0c36339d43bced4b',
	
	
	79: b'29fbcb0add3e59d6072f78f40801bef3110408f',
	
	 
	  
	
	 
	80: b'd906f2256646d5fdc7ed1ba184ce0e42702ae35',  
	81: b'5259d9ec5ac0ea8ae40282577d2c74a65c5b4f4',
	 
	 
	    
	82: b'decbe44c44449d9511d4f73b53e088774189423',
	
	    
	
	
	 83: b'848d3bedf4c433150ebc5f952c08c8409571d8a',   
	
	 
	84: b'3573cfd32eaa62ec1a81314f406bb9d4e5c35fa',
	
	85: b'0c4f13eaeea5f5e2f114247f6320c43a0eb4a32',
	
	
	  86: b'efa424d5ec402037f7cbc5e2733bcdb0102f1f4',  
	
	  
	87: b'9621b2417d4d4584addd3eadc627014d68b43e4',  
	
	 
	88: b'38a60fc046a8e599c0c89d8e4fa91a860174266',89: b'efc43954830cf6eaf5807ebc294cfff17269d6b', 
	
	  
	  90: b'2cc9c7727058a0ac6967114404d334b1b03d9f7',   
	 
	
	91: b'113f4f6fc483defaa50e485da4d936ca9be4ca1',
	92: b'd611f01beeb6c6d5fa9a71b8559dea64580336e',
	
	
	 93: b'f7e571707c447fa26e7ef8dfa9676448d4973b7', 
	 
	  
	94: b'342a2db817feeb00548aed6c500c92af30be115',    
	
	95: b'565781190333cd04adb296e8a964d125b9dfaf4',  96: b'c70feee80d52315d1b6791f5c95a1b8b6d48998', 
	 
	  
	
	
	97: b'23fbc81aa6f56efeffbf7ac0338aca8df1fdd68', 
	 
	98: b'baaeee8d40d96e76b9017bbd79ed69c071a73e2',  
	
	    
	99: b'9e8a3ca707358cbbbf1f44633ecb318b8155fdb',  b'fbbeafcdfbfcfadcabbcecfeebfefdddfefdddd': 67}