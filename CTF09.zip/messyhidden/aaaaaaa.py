class cdffcfdbaedcecfcbfedcdeedbeddbedebcbdec:
	bcaaccedadafdfdeffaabcfbedbcbcaeebfdfde={0: b'7d126b99acb2a19c368682992972e9cb1582d39',  
	
	   1: b'9d64de10c9a51eb80fb8585e3554638bb4fc56e',
	
	
	  
	2: b'31ce720ac88f21a1e9890389f8a94f76226b870',  
	  3: b'df8cb90ad8b822c8513405b8b7ffb4af1c06a18',
	
	
	 
	
	4: b'7ed5f31f7e97c7697c3f51a91edab61668024da', 5: b'edbfd4e2efed309e666a35a3ade8163377de5e5', 
	    
	
	
	 6: b'0d70f99ca82bc8160c6d26670a91f40afcd2c67',
	
	 
	 7: b'781aacef9e528aa2929f17ab3e60572bd662552', 
	
	  
	 
	
	
	8: b'27da0edd18f4500c037a594d89b644c54552b1b',
	   
	
	   
	9: b'c4b2501d63cd073f6d12976ebc370d7d0ddb069',
	10: b'e6a7a9f3a7bcdf3a1ca20c359e1419cf04cf828',
	
	  
	11: b'8dc95f4e4b4c092e6f381911949c8d438450d05',
	
	   12: b'82c1be7f19dd7194c1b2225bea425ff0249b7d7',
	  13: b'84b1aac375a03b10abb4ad9c725f4435ced5669', 
	
	   
	 14: b'b0990a7e77f982016a9250da321f1a38bc720df',
	15: b'2b52f311eaacf6fa6b83015d02c180fa7290f58', 
	16: b'8ff16204e3231ea98770ce5622c209d4229bee7', 
	
	
	 
	
	 17: b'b65d4855a9d350e0d676a2e4289f5651c21d3c3', 
	
	  
	 18: b'6a170a57657f4b5b8212f73a6226d8af2b1900b', 19: b'825a0823f5939eaa8ac9b39ba4558d155740f01', 20: b'fc293943e7a0c61d10d5440a653578015459501',
	 21: b'94ea00eda257dadbc410f9b999910080770fc4a',
	 
	
	    
	22: b'ab998be4985cfd61e0503c858e774728f672761', 
	
	
	 23: b'9dd45927277ddb19d0b1d6b8e298c51c79cf63e',   24: b'e568d1d77f4baedcd9fb1fdb888fbc19adb9ef4', 
	 25: b'950d569a2ba1fffc9411b9e25444b8e2d02020a',
	 
	 
	 
	  
	26: b'e94db6befce0749dfed15e170bc67a5ce4c77c7',  
	 
	
	27: b'ceff8cff02bd363f1f5f299d99e2b1a5ea5ec40', 
	    
	
	 
	28: b'd957f401286fbfea87acd8362b0af573c6e3834',
	
	
	   29: b'1eca8b5aed849762dea91818b0a4363d9eccfcd', 30: b'1107ca3b1c2a3283a2c8249cd4ab6c613f1510c',  
	
	 31: b'fe239ace0926148283bc7a6c4b6beb7a5f5e042',  
	32: b'b92070eadbaae7d869612dc9eb22c6e30b0c010',
	
	
	
	 
	33: b'9beb866966d0a541879d39753ce9613c0cab043',
	  
	 34: b'76fce746372584dc2e1e75faeab0e5d9a3a31b0', 
	 35: b'102edc1f8b719d014852296fcbb8b72e651d644',
	
	36: b'968898a8cbc86580658f549a4e46f04cf3da0f6',37: b'5798d4f22502dcb3c3a11646acb6cd8c0799e7e', 
	 38: b'b0889776e8d22c464dd1baf6d2be414e803bc9e', 
	 
	 
	
	
	
	39: b'146efb799dd3a4b572902abbd138d101898139e',
	 
	
	
	
	
	
	40: b'1925d7a063fe3823cbb5961276a8e10f9bd5327',
	
	41: b'5c961888ab862ac3fffdd710015c7e32d09b729',
	
	
	  
	42: b'74682047494d5057810e170000072b494441547',43: b'56a5f85f6f09a3cd1dde88e124f8a5a7dd0e3e2',     44: b'4cbe5b0c76cd189f78ff7fa256677bccfe5fe56',
	45: b'050d9a5f150c5ca1162ebb0ee74c8d6cc607dcf',
	  
	
	
	
	46: b'fd5562c19f94606526082fbc5be2e3eec6a9eca', 
	 47: b'41bfc7a42f51f2fdd1d7c5b41e624c4c8bf09e6',
	
	
	48: b'0e9b731cf8d6eb6e817a0e07fa564fb1c4bcd0b',
	    
	
	
	
	 49: b'44043b7fbc81c61a72080b892ce6b0c88922b9d',  
	 
	  
	  50: b'68619dc35841fde5b693b0f553efaf4b9d71c0e',
	
	  
	
	   51: b'88d65e452a316931d09b9297b3af72ac9948ff3',  
	
	 
	 
	52: b'0b4ad53745872fc80618208fa4128c073aa1410', 53: b'b5f18ea9f5aba552e50c07d50d190a620dc200b',
	54: b'720744af44e286ff1fbb75e6fb3dd8d0e6fe5d8',
	
	 
	 55: b'8160bf938843151df9a4f478ba33f628d39af0d',    
	
	  
	
	56: b'9d249785b9ca3f3a6c8fb395563961c0ae9344f',
	
	 
	
	
	
	  57: b'b83b17b698f34f592cb06371275b053c73eeaab',   
	
	   
	
	58: b'8184756a02123b7859cb388e7ee194330f2ba00', 
	
	 
	 
	
	 59: b'37ae9c6071a40584a8d1d2682142ba5ea1d19cf', 
	 
	
	  
	 60: b'61603b06d32d5a0a68f999cf7c193c8cb12a6e6',61: b'3c8430e03681a3061521d11d2eec6440ac1fbc5',  
	
	62: b'b2ac4a4f7092d1ec37c64cb551cb4008fa23310', 
	  
	 63: b'02d3b483b7c4e1f1eef72012332a65f53c81f20', 
	
	 
	64: b'93c5ba10a1e01be6f0439af4f14a705d1c637d2',  
	
	  
	  65: b'767cd4a26520cd3a98d3b84ee1c8f56c93d1550',
	
	 
	
	
	
	
	
	66: b'8d44674dde0affd54d24caa5cf20c4cdc4027d2', 
	 
	
	   
	
	67: b'48c76b2c1b90b60983669f6f41579406267206e',
	
	 
	
	
	 
	 68: b'8171562020676356c81b0e780b46b1c6cb69767',
	
	   
	
	
	
	69: b'7dadc19ca17cd950b9dea57137e129863d2e84e',  
	
	  
	70: b'f65f49d9164ffebd4bb770b4ae2c5a35495d0ac', 
	
	
	
	
	71: b'ad9723800352d0ebd10dafb8c71960ab14852ca',72: b'54c98f39f419f4e8b634262d04ccbfcb32661bc', 
	 73: b'a38d7c1f9635cf228c33e77a0d55a1ad392b305',  
	
	74: b'42a2397f4b00469871a31ba294a4097a1aad0f5',
	
	 
	75: b'b3998500d0d425987c6f56dbf258479c2996658',
	  
	 
	
	76: b'c9d180cbd044377670d882fcc6f75d1d3117384',77: b'60e05be1b7e462c3bef9558febb4c2b684db698',
	  
	
	
	    78: b'96bcd653a7b15e747e41998cb92c5d5971cbb3d',
	  
	79: b'5b63506ddac0a7ce56900d6e90f1ffb9ae611f6', 
	    
	
	 
	80: b'cd0411e7f803fbedcf6140f5cf4e036bc7753d7',
	81: b'eaf1a9554c1c3096d93a9b7dfdaef75b77c0be6',
	 
	
	82: b'60549448186a584308e1012eef884515e2a2bc3',83: b'326ad37db75e75f2ecaa6805d2a12966dba57e8', 
	 
	84: b'13783261381fa294338edeb1189543387f12fca',  
	 
	 
	 85: b'529bfe6d03b5367865cf1563ace10251dc91b61',86: b'dff30f0bd3c0de80b4fd9e6c1770f64afd8a3c9',
	
	
	
	
	87: b'29256e9505d98577334763fcfe1a1a06df48807',  
	   
	 88: b'765c81779d61f7ca16daa8ce12761fd570889b8',89: b'2c9f3e72d145e0150f1e645e5505f5f389fa8a4',
	
	  
	  90: b'048593c4bbafdbce3a7302d6a2783a3e8f9b727',
	
	
	 
	 
	 
	91: b'f03cd254f2a47483ca9f2e596f620c9276473ca',     
	   92: b'133574ebdb282f38190737d7d2217ca7fa39d47',
	
	 
	
	  
	
	93: b'439348f0d3c70a4b94a1b00b0d629df3f73f7a7',  94: b'4d103e18e1e85b886d9e4b58d5462e5035db93b',    
	 95: b'2936570e65cab7bde3f39f42a53a1f7a413e4d7', 
	 96: b'993a4d61c77a8fcc35e0b4f754a182c15cab61e',   
	
	
	 
	
	
	97: b'8c7b46f2975db0391c7ecf0a1a07050e2847d57',
	
	
	98: b'608b0601d55deb1646fd7e47f16b304a1acf3ad',  
	
	99: b'c8c5b14c278c2c53a281e1ea799390f5cd3fe4a', 
	
	 
	 
	b'bdccbaebcdfbcfccabedfbccfdbbcdadeefabfd': 42}