class eccedeeecaffdccdabccfeddcebfdceccefecdd:
	fbfcdefffedcecacbfdcddedcadabefbadccfbf={0: b'040fd41b9d456e43077ae57b343a11ccc67eb1f', 
	 1: b'2a24c27281626ac1eb0edf77206703e1d9301b1',
	    
	 
	
	2: b'627c8dbb68ff205d7f3d04a0c489d7563122bff',
	 
	 3: b'3641ee5f7b44b03c3d29413f95f5788e286ec83',
	  
	
	
	
	  4: b'0e6fdd141d41495ea5078fedfe9aa26806aea76',   
	  
	  
	5: b'0cd290cece9bb7d59c1ab34850ec930dfe3e609',      
	 
	6: b'b0295a3528fb526ef3501e6c7f734e81d50d0ce', 
	
	
	
	
	7: b'ba8cc086824b71b95126c1df3d94c5da2f86731',
	 
	
	
	  
	
	8: b'cec106665b54406ccfcc27fdab5f40e0d3d7d96',9: b'f6f14e965849cea1db7c219f25753288380e9df',
	   
	
	  
	10: b'5db3327dd39f730a980cf8e7ff86bb287f54a7b',
	
	
	 
	  
	
	11: b'763281597f651b5cc108a7afe03a6e8d31fca06',  
	
	     12: b'1877666b078bcfd140560afe545eb892a034a81',   
	 
	13: b'7c8bf5e3d0e7e5eb4a609c4bf974dc27e158a7a', 
	      14: b'41d58646c2ec4f813abcfd1261cd0b1ff6f57e7', 
	  
	
	15: b'6f252a7d203a0bf2a67c4d5993bf4459f0d4e38',
	
	 
	
	 
	16: b'72016c22982fb25d265d79f4e1e351d0ee8718d',
	 
	
	
	
	17: b'4af1fe34c96df1a91caf2fe849cbd7636a747d3',18: b'cf1993d94139fea8f78dce072c4d5287dd5d650',
	  
	
	  19: b'76e12d18fb8338dbdf1c0eff0600eee8cef698b',
	 20: b'7bbd7d26f77f18df6ccc563db87e62722a53884',
	
	
	  
	
	 21: b'3f7b0e566a0fb10c07693609ce7fbcfbe0d52c6',
	    22: b'2367e072582f6efc53b648bb184a0af43b41501', 23: b'8a2f49a5e196d9e5e06f9d09f306d219b7f33d3',
	 
	
	
	 
	 24: b'9a21350e160b76413a9c0e06843f482b532a377',
	 
	   
	
	 
	25: b'86319b92608d15452bf3b480b9b05ec608a9c01', 
	  
	26: b'0cc6e2054513c7c6d3819902bb6b1b555741bcd',
	
	 27: b'd15f872fa6c3bb604761f4f3397715ef239b38b', 
	 28: b'ee683edf97b3e6f458bdd8b53257008f5af7171',
	  
	 
	
	 29: b'4e480984eea3bfc682af8989d675134cbef0117',
	
	 
	30: b'a4b60de284c9685db885a4355afee736443cae6',
	  
	
	  
	 31: b'd08106e9b357eeedca3996aaed08ba8218fb929',   32: b'036d76f4073b91caaebcd9d117bf6ae052c1b52',  
	 
	
	 
	 33: b'8131edeee64a0e218368fc7cb9419515eb1976d', 34: b'219c107158116e1a06088289aed5a9d8eae1ae3', 
	  
	    
	35: b'd1c95631e01d79cdd8a1f799be915748a12f29b', 
	
	   
	36: b'027a6327265050e01c64a4fc926ec8155dc3f0b',37: b'538c81155c0b19d1451b760e4e80bb947ad8b8a',
	  
	38: b'3314bbf504e953faecc868d50b9c4f7ec4c2ab0',  
	  
	
	39: b'bfa465b13920c1673b5c4b2c815ae20a97ddb8d',40: b'234ba74067d1e361b8076c705d3f53a56c34261', 
	  41: b'b68a07845d3bee7db506cb24732219ae9ea9671',
	  
	 42: b'6304d87f570e08bebfdf89cca837e9afbf7e20c', 
	  
	
	43: b'd3e5a8e28092c57a93bb7d955d4cc3386b466c2',  
	44: b'a215e9e8ccd5c372003aba8845c842ec799de49',
	
	
	
	45: b'5c7fcb15e55d94042be0bc134d766c436fbb5f4', 
	   
	46: b'b7b3c37e87887889466303d78988f9715061086',  
	
	 
	
	
	 47: b'15b5d0d0e355655d5a931c7bbef00498708d913', 
	 
	
	 
	   48: b'd55e27ffb78e7ce90ff274c405663f0b60059b9',  
	
	 
	
	
	  49: b'c239b4c33cc38d84a5f01f790e5d49cd045634e',50: b'75cbf4d42c2e4b4f2b72c35a1726c0f928aee16',
	  
	
	
	51: b'5912a1bb69fa01a1f4a4ed4ed26c0ca79a58459',
	
	
	52: b'4da21f41032a9e593ae6efd279fe4623f376b0b',
	 
	 
	
	
	  
	53: b'1ee837af3179501de54c7b0e415dc7215384a80', 
	
	54: b'6ab9029a3de18d7feed70afd22794bcc3fa0df4', 
	
	 
	55: b'01171e9fab436de2f84f948958c022bea944ed3',
	 
	 
	  56: b'70023157bc7b34de0d96a055748dec44b67819d',
	  
	
	 
	57: b'd8eca83f0235daf65eb0969e2d999da656beb1a',
	
	  
	 
	58: b'c382136d36018e1305d8bad64276acaab801991',
	 
	
	
	  
	 59: b'd53e62aea40dc5ea32a9661d36de0d1e74c0d8a', 
	 
	
	 
	60: b'96d0fb3563da493b6281f615f5f500a18a62b97',
	
	 
	61: b'9ce9f13fa92487b54c31d6805131846dd616bf4',
	  
	
	   62: b'a68ed3c4b95cc75e3edf60d3980284640e9972e', 
	
	 
	
	
	63: b'c6bdebe73ad85699570b88b5f9a63a81be4be19',64: b'ca488fc86fa66e7207a4013097847782959194c',
	
	   65: b'da1ea7b029867ec53cbd1a6aa997d4caddbfcbf',   
	
	  
	66: b'941ef73a2cb727cf2ee3837ae7f243e4f37084e', 
	   
	
	 67: b'61e87c641a96422ffd3095f69497aed24b53aca',
	  
	68: b'a2c208ab644cb5a0992edd658ee0f03c53fea35',
	
	    69: b'55a1eb3b153527cf8009a1111f38ed68eb697b0',    70: b'a0933822603ec1651e25c340bb7cc61a41b84ce',   71: b'1999de4bfbef775d2475ce9c32080c39f2c1bc6', 72: b'3a34f3dda284c83f7bb5c7ae06799872e906d65', 
	
	
	
	
	
	 73: b'968afbe032d99d432185d31b9b81ef13fd5b3b2', 74: b'd3b3667a10039c1d49be5cf8406df97cf514c28', 
	
	75: b'c7806aa9f8fb2818e688af87edf3dc9502068e0',
	 76: b'3a268771e0b63427144f097de1938f12899c1df',
	    77: b'82bcbd245bdde3d94962ceecec3fb30ea3be427',78: b'14f8e4e8967a1fc7e5fbed3a1dc68c31edd6df7',
	    
	
	 
	79: b'a2a710287efa4613fa70de9903c7370eb888dc3',
	  
	
	80: b'188661e7ceaaf6f5afd2a568cada18ad3421309',
	
	  
	
	 
	81: b'861df74db0b05169f9e18ba7c56df666c9ee0be', 
	
	
	82: b'8a8b3e805298d5e9c2dcbb5ff6fc6a118330aa5',
	 
	83: b'4b9f3f4891d88ed9d4fe7091b74fb6aeac1e770',
	
	    84: b'c4b06484d495b58b44d9c14ad92aa777809e7d6',   
	
	
	 
	
	85: b'fefd9859e94e1e75f951db7478e78e7d193857f',
	
	 86: b'a9df91e505ed83d76ee27abc87b24bb13910054',
	
	  
	
	87: b'1b7893c0a956365f28449c9dba507b717044a21',
	 
	    
	88: b'61aa472040a0bfb9fea05e6ad8793fa9d9c020b',
	
	 
	 
	 89: b'25a2b074c5e327edb594acfee4d08df120c5c0f',
	
	
	
	90: b'2540f1ca8b2ae793e018392cd1796829fadc29d',
	
	 91: b'415d92d4238f356f5f787f2f7925d4e09907772',
	  
	
	  
	
	
	92: b'6aee0ecd4016ecd31bcea64e8d749234c606c15',  93: b'f72c9d367cdc7c78aa26aa7ce2c8aaded2db365', 
	94: b'0c799039384f14033014882699ebdba9da27bb5', 
	95: b'cb3728fcc2ee97460f73173b37d055897b7949d', 
	
	  
	 
	96: b'6b63a3f82611d1814a04513abd52639cc08f926',   
	 
	
	
	 97: b'd698f83d083ccc3a641c9120c36d7514b92cfc1',  
	
	
	 98: b'd4af52ad619c8cf1c08badf998ad18e3931f9e0',99: b'7d9f7316dc048ee96c463d5812b9ef7462c8f1a',
	 
	 b'ecbaaaccabcdedbfeedeffedbbaddbcbfdfcacf': 74}